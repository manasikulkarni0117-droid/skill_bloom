import datetime
from sqlalchemy import Column, Integer, String, Float, Boolean, DateTime, ForeignKey, Text
from sqlalchemy.orm import relationship
from app.database import Base

class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    email = Column(String(255), unique=True, index=True, nullable=False)
    password_hash = Column(String(255), nullable=False)
    full_name = Column(String(255), nullable=False)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)

    profile = relationship("StudentProfile", back_populates="user", uselist=False, cascade="all, delete-orphan")
    skills_taught = relationship("StudentSkill", back_populates="user", cascade="all, delete-orphan")
    learning_goals = relationship("LearningGoal", back_populates="user", cascade="all, delete-orphan")
    portfolio_items = relationship("CertificateProject", back_populates="user", cascade="all, delete-orphan")
    assessments = relationship("SkillAssessment", back_populates="user", cascade="all, delete-orphan")
    badges = relationship("Badge", back_populates="user", cascade="all, delete-orphan")
    notifications = relationship("Notification", back_populates="user", cascade="all, delete-orphan")


class StudentProfile(Base):
    __tablename__ = "student_profiles"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), unique=True, nullable=False)
    avatar_id = Column(String(50), default="avatar-owl")
    college = Column(String(255), nullable=False, default="State Institute of Technology")
    course = Column(String(255), nullable=False, default="B.Tech Computer Science")
    semester = Column(Integer, nullable=False, default=4)
    preferred_language = Column(String(100), nullable=False, default="English")
    availability = Column(String(255), default="Weekday evenings (6 - 9 PM), Weekend mornings")
    bio = Column(Text, default="Passionate peer learner and coder.")
    rating_avg = Column(Float, default=5.0)
    total_reviews = Column(Integer, default=0)
    completed_sessions_count = Column(Integer, default=0)
    documents_privacy = Column(String(50), default="connections_only") # connections_only, public, private
    created_at = Column(DateTime, default=datetime.datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.datetime.utcnow, onupdate=datetime.datetime.utcnow)

    user = relationship("User", back_populates="profile")


class Subject(Base):
    __tablename__ = "subjects"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(150), unique=True, index=True, nullable=False)
    code = Column(String(50), nullable=True)
    category = Column(String(100), nullable=False) # Computer Science, Mathematics, Electronics, etc.
    semester_recommended = Column(Integer, default=3)
    description = Column(Text, nullable=True)
    is_custom = Column(Boolean, default=False)
    created_by_user_id = Column(Integer, ForeignKey("users.id"), nullable=True)

    skills = relationship("StudentSkill", back_populates="subject", cascade="all, delete-orphan")
    learning_goals = relationship("LearningGoal", back_populates="subject", cascade="all, delete-orphan")


class StudentSkill(Base):
    __tablename__ = "student_skills"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    subject_id = Column(Integer, ForeignKey("subjects.id"), nullable=False)
    proficiency_level = Column(String(50), nullable=False) # Beginner, Intermediate, Advanced
    experience_note = Column(Text, nullable=True)
    # Distinct verification labels
    verification_status = Column(String(50), default="Unverified") # Unverified, Certificate Uploaded, Assessment Passed, Project Reviewed, Institution Verified
    assessment_score = Column(Integer, nullable=True)

    user = relationship("User", back_populates="skills_taught")
    subject = relationship("Subject", back_populates="skills")


class LearningGoal(Base):
    __tablename__ = "learning_goals"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    subject_id = Column(Integer, ForeignKey("subjects.id"), nullable=False)
    urgency = Column(String(50), default="Normal") # Normal, Exam Preparation, Project Deadline
    preferred_pace = Column(String(50), default="Regular")
    current_understanding = Column(String(50), default="Beginner")

    user = relationship("User", back_populates="learning_goals")
    subject = relationship("Subject", back_populates="learning_goals")


class CertificateProject(Base):
    __tablename__ = "certificates_projects"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    subject_id = Column(Integer, ForeignKey("subjects.id"), nullable=True)
    item_type = Column(String(50), default="certificate") # certificate, project
    title = Column(String(255), nullable=False)
    issuing_organization = Column(String(255), nullable=True) # or project domain
    file_path = Column(String(500), nullable=True)
    original_filename = Column(String(255), nullable=True)
    file_type = Column(String(50), nullable=True)
    file_size = Column(Integer, nullable=True)
    github_url = Column(String(500), nullable=True)
    live_url = Column(String(500), nullable=True)
    description = Column(Text, nullable=True)
    # Strict verification status
    verification_status = Column(String(50), default="Certificate Uploaded")
    created_at = Column(DateTime, default=datetime.datetime.utcnow)

    user = relationship("User", back_populates="portfolio_items")


class SkillAssessment(Base):
    __tablename__ = "skill_assessments"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    subject_id = Column(Integer, ForeignKey("subjects.id"), nullable=False)
    score = Column(Integer, nullable=False)
    max_score = Column(Integer, default=100)
    passed = Column(Boolean, default=True)
    assessment_date = Column(DateTime, default=datetime.datetime.utcnow)
    badge_label = Column(String(100), default="Assessment Passed")

    user = relationship("User", back_populates="assessments")


class ConnectionRequest(Base):
    __tablename__ = "connection_requests"

    id = Column(Integer, primary_key=True, index=True)
    sender_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    receiver_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    status = Column(String(50), default="pending") # pending, accepted, rejected, cancelled
    message = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.datetime.utcnow, onupdate=datetime.datetime.utcnow)

    sender = relationship("User", foreign_keys=[sender_id])
    receiver = relationship("User", foreign_keys=[receiver_id])


class Conversation(Base):
    __tablename__ = "conversations"

    id = Column(Integer, primary_key=True, index=True)
    user1_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    user2_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.datetime.utcnow, onupdate=datetime.datetime.utcnow)

    user1 = relationship("User", foreign_keys=[user1_id])
    user2 = relationship("User", foreign_keys=[user2_id])
    messages = relationship("Message", back_populates="conversation", cascade="all, delete-orphan")


class Message(Base):
    __tablename__ = "messages"

    id = Column(Integer, primary_key=True, index=True)
    conversation_id = Column(Integer, ForeignKey("conversations.id"), nullable=False)
    sender_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    content = Column(Text, nullable=False)
    is_read = Column(Boolean, default=False)
    read_at = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)

    conversation = relationship("Conversation", back_populates="messages")
    sender = relationship("User", foreign_keys=[sender_id])


class LearningSession(Base):
    __tablename__ = "learning_sessions"

    id = Column(Integer, primary_key=True, index=True)
    host_id = Column(Integer, ForeignKey("users.id"), nullable=False) # teacher/host
    learner_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    subject_id = Column(Integer, ForeignKey("subjects.id"), nullable=False)
    title = Column(String(255), nullable=False)
    description = Column(Text, nullable=True)
    scheduled_time = Column(DateTime, nullable=False)
    duration_minutes = Column(Integer, default=60)
    status = Column(String(50), default="scheduled") # pending, scheduled, completed, cancelled
    meeting_room_id = Column(String(100), unique=True, nullable=False)
    meeting_notes = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)

    host = relationship("User", foreign_keys=[host_id])
    learner = relationship("User", foreign_keys=[learner_id])
    subject = relationship("Subject")
    reviews = relationship("SessionReview", back_populates="session", cascade="all, delete-orphan")


class SessionReview(Base):
    __tablename__ = "session_reviews"

    id = Column(Integer, primary_key=True, index=True)
    session_id = Column(Integer, ForeignKey("learning_sessions.id"), nullable=False)
    reviewer_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    reviewee_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    rating = Column(Float, nullable=False) # 1 - 5 stars
    teaching_clarity = Column(Integer, default=5)
    helpfulness = Column(Integer, default=5)
    punctuality = Column(Integer, default=5)
    feedback = Column(Text, nullable=False)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)

    session = relationship("LearningSession", back_populates="reviews")
    reviewer = relationship("User", foreign_keys=[reviewer_id])
    reviewee = relationship("User", foreign_keys=[reviewee_id])


class Notification(Base):
    __tablename__ = "notifications"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    type = Column(String(50), nullable=False) # connection_request, session_scheduled, session_reminder, message, review, badge
    title = Column(String(255), nullable=False)
    content = Column(Text, nullable=False)
    link = Column(String(255), nullable=True)
    is_read = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)

    user = relationship("User", back_populates="notifications")


class UserBlockReport(Base):
    __tablename__ = "user_blocks_reports"

    id = Column(Integer, primary_key=True, index=True)
    reporter_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    target_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    action = Column(String(50), nullable=False) # block, report
    reason = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)


class Badge(Base):
    __tablename__ = "badges"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    badge_code = Column(String(50), nullable=False)
    badge_title = Column(String(100), nullable=False)
    badge_icon = Column(String(50), default="🌟")
    description = Column(String(255), nullable=True)
    awarded_at = Column(DateTime, default=datetime.datetime.utcnow)

    user = relationship("User", back_populates="badges")
