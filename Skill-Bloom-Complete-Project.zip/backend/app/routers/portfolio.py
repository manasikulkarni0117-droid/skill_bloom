import os
import uuid
import aiofiles
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Form, status
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session
from app.database import get_db
from app.models import User, CertificateProject, StudentSkill, ConnectionRequest, Subject
from app.schemas import CertificateProjectOut
from app.auth import get_current_user, get_current_user_optional
from app.config import UPLOAD_DIR

router = APIRouter(prefix="/api/portfolio", tags=["Portfolio & Certificates"])

ALLOWED_EXTENSIONS = {".pdf", ".png", ".jpg", ".jpeg", ".webp"}
MAX_FILE_SIZE = 10 * 1024 * 1024  # 10 MB

@router.post("/upload", response_model=CertificateProjectOut)
async def upload_portfolio_item(
    item_type: str = Form(...), # "certificate" or "project"
    title: str = Form(...),
    issuing_organization: Optional[str] = Form(None),
    subject_id: Optional[int] = Form(None),
    github_url: Optional[str] = Form(None),
    live_url: Optional[str] = Form(None),
    description: Optional[str] = Form(None),
    file: Optional[UploadFile] = File(None),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    saved_filename = None
    file_path_relative = None
    file_type = None
    file_size = None

    if file and file.filename:
        # Validate extension
        _, ext = os.path.splitext(file.filename.lower())
        if ext not in ALLOWED_EXTENSIONS:
            raise HTTPException(
                status_code=400,
                detail=f"Unsupported file format '{ext}'. Allowed types: PDF, PNG, JPG, JPEG, WEBP."
            )

        # Read and check size
        contents = await file.read()
        file_size = len(contents)
        if file_size > MAX_FILE_SIZE:
            raise HTTPException(
                status_code=400,
                detail=f"File exceeds 10MB limit (size: {round(file_size / (1024*1024), 2)}MB)."
            )

        # Generate safe unique filename
        unique_name = f"{uuid.uuid4().hex}{ext}"
        saved_path = os.path.join(UPLOAD_DIR, unique_name)

        async with aiofiles.open(saved_path, 'wb') as out_file:
            await out_file.write(contents)

        saved_filename = file.filename
        file_path_relative = unique_name
        file_type = ext.replace(".", "").upper()

    # Determine verification label strictly adhering to rules:
    # "Never automatically label a certificate or skill as verified simply because a student uploaded a file."
    # If certificate: "Certificate Uploaded"
    # If project with GitHub URL: "Project Reviewed" (or "Project Submitted")
    if item_type == "project" and github_url:
        verif_status = "Project Reviewed"
    else:
        verif_status = "Certificate Uploaded"

    item = CertificateProject(
        user_id=current_user.id,
        subject_id=subject_id if subject_id else None,
        item_type=item_type,
        title=title.strip(),
        issuing_organization=issuing_organization.strip() if issuing_organization else None,
        file_path=file_path_relative,
        original_filename=saved_filename,
        file_type=file_type,
        file_size=file_size,
        github_url=github_url.strip() if github_url else None,
        live_url=live_url.strip() if live_url else None,
        description=description.strip() if description else None,
        verification_status=verif_status
    )
    db.add(item)

    # If linked to a subject the user teaches, upgrade skill verification status from Unverified to Certificate Uploaded
    if subject_id:
        skill = db.query(StudentSkill).filter(
            StudentSkill.user_id == current_user.id,
            StudentSkill.subject_id == subject_id
        ).first()
        if skill and skill.verification_status == "Unverified":
            skill.verification_status = verif_status

    db.commit()
    db.refresh(item)

    subj_name = None
    if item.subject_id:
        s = db.query(Subject).filter(Subject.id == item.subject_id).first()
        if s:
            subj_name = s.name

    return CertificateProjectOut(
        id=item.id,
        user_id=item.user_id,
        subject_id=item.subject_id,
        subject_name=subj_name,
        item_type=item.item_type,
        title=item.title,
        issuing_organization=item.issuing_organization,
        file_path=item.file_path,
        original_filename=item.original_filename,
        file_type=item.file_type,
        file_size=item.file_size,
        github_url=item.github_url,
        live_url=item.live_url,
        description=item.description,
        verification_status=item.verification_status,
        created_at=item.created_at
    )

@router.get("", response_model=List[CertificateProjectOut])
def get_my_portfolio(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    items = db.query(CertificateProject).filter(
        CertificateProject.user_id == current_user.id
    ).order_by(CertificateProject.created_at.desc()).all()

    out = []
    for item in items:
        subj_name = None
        if item.subject_id:
            s = db.query(Subject).filter(Subject.id == item.subject_id).first()
            if s:
                subj_name = s.name
        out.append(CertificateProjectOut(
            id=item.id,
            user_id=item.user_id,
            subject_id=item.subject_id,
            subject_name=subj_name,
            item_type=item.item_type,
            title=item.title,
            issuing_organization=item.issuing_organization,
            file_path=item.file_path,
            original_filename=item.original_filename,
            file_type=item.file_type,
            file_size=item.file_size,
            github_url=item.github_url,
            live_url=item.live_url,
            description=item.description,
            verification_status=item.verification_status,
            created_at=item.created_at
        ))
    return out

@router.delete("/{item_id}")
def delete_portfolio_item(
    item_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    item = db.query(CertificateProject).filter(
        CertificateProject.id == item_id,
        CertificateProject.user_id == current_user.id
    ).first()
    if not item:
        raise HTTPException(status_code=404, detail="Portfolio item not found.")

    if item.file_path:
        full_path = os.path.join(UPLOAD_DIR, item.file_path)
        if os.path.exists(full_path):
            try:
                os.remove(full_path)
            except Exception:
                pass

    db.delete(item)
    db.commit()
    return {"message": "Portfolio item deleted successfully"}

@router.get("/download/{item_id}")
def download_portfolio_file(
    item_id: int,
    current_user: Optional[User] = Depends(get_current_user_optional),
    db: Session = Depends(get_db)
):
    item = db.query(CertificateProject).filter(CertificateProject.id == item_id).first()
    if not item or not item.file_path:
        raise HTTPException(status_code=404, detail="File not found.")

    # Authorization check
    owner = item.user
    if not owner or not owner.profile:
        raise HTTPException(status_code=404, detail="Item owner not found.")

    privacy = owner.profile.documents_privacy
    if privacy == "private":
        if not current_user or current_user.id != item.user_id:
            raise HTTPException(status_code=403, detail="This document is set to private by the student.")
    elif privacy == "connections_only":
        if not current_user:
            raise HTTPException(status_code=401, detail="Please log in to view this document.")
        if current_user.id != item.user_id:
            # Check connection
            conn = db.query(ConnectionRequest).filter(
                ((ConnectionRequest.sender_id == current_user.id) & (ConnectionRequest.receiver_id == item.user_id)) |
                ((ConnectionRequest.sender_id == item.user_id) & (ConnectionRequest.receiver_id == current_user.id)),
                ConnectionRequest.status == "accepted"
            ).first()
            if not conn:
                raise HTTPException(status_code=403, detail="This document is restricted to connected peers only.")

    full_path = os.path.join(UPLOAD_DIR, item.file_path)
    if not os.path.exists(full_path):
        raise HTTPException(status_code=404, detail="Physical file was not found on server.")

    return FileResponse(
        path=full_path,
        filename=item.original_filename or f"skillbloom-evidence-{item.id}",
        media_type="application/octet-stream"
    )
