from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from app.database import get_db
from app.models import User, StudentProfile, Badge
from app.schemas import UserRegister, UserLogin, Token, AvatarInfo
from app.auth import get_password_hash, verify_password, create_access_token, get_current_user

router = APIRouter(prefix="/api/auth", tags=["Authentication"])

AVATARS_CATALOG = [
    {"id": "avatar-owl", "label": "Wise Owl", "emoji": "🦉", "bg_gradient": "from-emerald-500 to-teal-700"},
    {"id": "avatar-fox", "label": "Clever Fox", "emoji": "🦊", "bg_gradient": "from-amber-500 to-orange-600"},
    {"id": "avatar-coder", "label": "Tech Prodigy", "emoji": "💻", "bg_gradient": "from-blue-600 to-indigo-700"},
    {"id": "avatar-astronaut", "label": "Curious Explorer", "emoji": "🚀", "bg_gradient": "from-purple-600 to-indigo-900"},
    {"id": "avatar-panda", "label": "Zen Panda", "emoji": "🐼", "bg_gradient": "from-teal-500 to-emerald-700"},
    {"id": "avatar-robot", "label": "AI Builder", "emoji": "🤖", "bg_gradient": "from-cyan-500 to-blue-600"},
    {"id": "avatar-lion", "label": "Brave Mentor", "emoji": "🦁", "bg_gradient": "from-yellow-500 to-amber-700"},
    {"id": "avatar-wizard", "label": "Math Wizard", "emoji": "🧙", "bg_gradient": "from-fuchsia-600 to-purple-800"},
    {"id": "avatar-cat", "label": "Focus Cat", "emoji": "🐱", "bg_gradient": "from-rose-400 to-pink-600"},
    {"id": "avatar-koala", "label": "Calm Learner", "emoji": "🐨", "bg_gradient": "from-slate-500 to-zinc-700"},
    {"id": "avatar-rabbit", "label": "Speed Learner", "emoji": "🐰", "bg_gradient": "from-emerald-400 to-green-600"},
    {"id": "avatar-bee", "label": "Productive Bee", "emoji": "🐝", "bg_gradient": "from-amber-400 to-yellow-600"}
]

@router.get("/avatars", response_model=list[AvatarInfo])
def get_avatars():
    return AVATARS_CATALOG

@router.post("/register", response_model=Token)
def register(user_in: UserRegister, db: Session = Depends(get_db)):
    # Check if email already registered
    existing_user = db.query(User).filter(User.email == user_in.email.lower().strip()).first()
    if existing_user:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="An account with this email address already exists."
        )

    # Create User
    new_user = User(
        email=user_in.email.lower().strip(),
        password_hash=get_password_hash(user_in.password),
        full_name=user_in.full_name.strip()
    )
    db.add(new_user)
    db.flush()

    # Create StudentProfile
    profile = StudentProfile(
        user_id=new_user.id,
        avatar_id=user_in.avatar_id or "avatar-owl",
        college=user_in.college.strip(),
        course=user_in.course.strip(),
        semester=user_in.semester,
        preferred_language=user_in.preferred_language.strip(),
        availability="Weekday evenings & Weekends",
        bio="Excited to share my knowledge and learn from fellow students on Skill Bloom!"
    )
    db.add(profile)

    # Award welcome badge
    welcome_badge = Badge(
        user_id=new_user.id,
        badge_code="welcome_peer",
        badge_title="Welcome to Skill Bloom",
        badge_icon="🌱",
        description="Joined the peer-to-peer college learning community"
    )
    db.add(welcome_badge)

    db.commit()

    token = create_access_token({"sub": str(new_user.id), "email": new_user.email})
    return Token(
        access_token=token,
        token_type="bearer",
        user_id=new_user.id,
        full_name=new_user.full_name,
        email=new_user.email
    )

@router.post("/login", response_model=Token)
def login(user_in: UserLogin, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.email == user_in.email.lower().strip()).first()
    if not user or not verify_password(user_in.password, user.password_hash):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid email or password. Please check your credentials."
        )
    if not user.is_active:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Your account has been deactivated."
        )

    token = create_access_token({"sub": str(user.id), "email": user.email})
    return Token(
        access_token=token,
        token_type="bearer",
        user_id=user.id,
        full_name=user.full_name,
        email=user.email
    )

@router.get("/me")
def get_current_user_info(current_user: User = Depends(get_current_user)):
    profile = current_user.profile
    return {
        "id": current_user.id,
        "email": current_user.email,
        "full_name": current_user.full_name,
        "avatar_id": profile.avatar_id if profile else "avatar-owl",
        "college": profile.college if profile else "",
        "course": profile.course if profile else "",
        "semester": profile.semester if profile else 1,
        "preferred_language": profile.preferred_language if profile else "English",
        "availability": profile.availability if profile else "",
        "bio": profile.bio if profile else "",
        "rating_avg": profile.rating_avg if profile else 5.0,
        "total_reviews": profile.total_reviews if profile else 0,
        "completed_sessions_count": profile.completed_sessions_count if profile else 0,
        "documents_privacy": profile.documents_privacy if profile else "connections_only"
    }

@router.post("/logout")
def logout(current_user: User = Depends(get_current_user)):
    return {"message": "Successfully logged out."}
