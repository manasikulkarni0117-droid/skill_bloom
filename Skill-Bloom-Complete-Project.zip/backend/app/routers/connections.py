from datetime import datetime
from typing import List, Dict, Any
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from app.database import get_db
from app.models import (
    User, ConnectionRequest, Conversation, Notification,
    UserBlockReport, Badge
)
from app.schemas import ConnectionRequestCreate, ConnectionRequestOut, BlockReportCreate
from app.auth import get_current_user

router = APIRouter(prefix="/api/connections", tags=["Connections"])

def get_avatar_id(user: User) -> str:
    return user.profile.avatar_id if user.profile and user.profile.avatar_id else "avatar-owl"

def get_college(user: User) -> str:
    return user.profile.college if user.profile else "College"

def get_course(user: User) -> str:
    return user.profile.course if user.profile else "Course"

@router.post("/request", response_model=ConnectionRequestOut)
def send_connection_request(
    req_in: ConnectionRequestCreate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    receiver_id = req_in.receiver_id

    if receiver_id == current_user.id:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="You cannot send a connection request to yourself."
        )

    # Check receiver exists
    receiver = db.query(User).filter(User.id == receiver_id, User.is_active == True).first()
    if not receiver:
        raise HTTPException(status_code=404, detail="Student not found.")

    # Check if blocked
    block = db.query(UserBlockReport).filter(
        ((UserBlockReport.reporter_id == current_user.id) & (UserBlockReport.target_id == receiver_id)) |
        ((UserBlockReport.reporter_id == receiver_id) & (UserBlockReport.target_id == current_user.id))
    ).first()
    if block:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Cannot connect with this user due to privacy or block restrictions."
        )

    # Check existing connection request
    existing = db.query(ConnectionRequest).filter(
        ((ConnectionRequest.sender_id == current_user.id) & (ConnectionRequest.receiver_id == receiver_id)) |
        ((ConnectionRequest.sender_id == receiver_id) & (ConnectionRequest.receiver_id == current_user.id))
    ).first()

    if existing:
        if existing.status == "accepted":
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="You are already connected with this student."
            )
        elif existing.status == "pending":
            if existing.sender_id == current_user.id:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="A connection request is already pending with this student."
                )
            else:
                # If they already sent us a request, automatically accept it!
                existing.status = "accepted"
                existing.updated_at = datetime.utcnow()
                # Create conversation
                conv = Conversation(user1_id=existing.sender_id, user2_id=existing.receiver_id)
                db.add(conv)
                # Create notification
                notif = Notification(
                    user_id=receiver_id,
                    type="connection_accepted",
                    title="Mutual Connection Established!",
                    content=f"{current_user.full_name} accepted your connection request. You can now chat and schedule sessions!",
                    link=f"/chat"
                )
                db.add(notif)
                db.commit()
                db.refresh(existing)
                return ConnectionRequestOut(
                    id=existing.id,
                    sender_id=existing.sender_id,
                    sender_name=existing.sender.full_name,
                    sender_avatar=get_avatar_id(existing.sender),
                    sender_college=get_college(existing.sender),
                    sender_course=get_course(existing.sender),
                    receiver_id=existing.receiver_id,
                    receiver_name=existing.receiver.full_name,
                    receiver_avatar=get_avatar_id(existing.receiver),
                    status=existing.status,
                    message=existing.message,
                    created_at=existing.created_at,
                    updated_at=existing.updated_at
                )
        elif existing.status == "rejected":
            # Allow re-requesting after rejection
            existing.sender_id = current_user.id
            existing.receiver_id = receiver_id
            existing.status = "pending"
            existing.message = req_in.message
            existing.updated_at = datetime.utcnow()
            db.commit()
            db.refresh(existing)

            # Notification
            notif = Notification(
                user_id=receiver_id,
                type="connection_request",
                title="New Connection Request",
                content=f"{current_user.full_name} sent you a connection request on Skill Bloom.",
                link="/connections"
            )
            db.add(notif)
            db.commit()

            return ConnectionRequestOut(
                id=existing.id,
                sender_id=current_user.id,
                sender_name=current_user.full_name,
                sender_avatar=get_avatar_id(current_user),
                sender_college=get_college(current_user),
                sender_course=get_course(current_user),
                receiver_id=receiver.id,
                receiver_name=receiver.full_name,
                receiver_avatar=get_avatar_id(receiver),
                status=existing.status,
                message=existing.message,
                created_at=existing.created_at,
                updated_at=existing.updated_at
            )

    # Create new connection request
    new_req = ConnectionRequest(
        sender_id=current_user.id,
        receiver_id=receiver_id,
        status="pending",
        message=req_in.message or "Hi! I would like to connect and learn together on Skill Bloom."
    )
    db.add(new_req)
    db.flush()

    # Create Notification
    notif = Notification(
        user_id=receiver_id,
        type="connection_request",
        title="New Connection Request",
        content=f"{current_user.full_name} sent you a connection request: \"{new_req.message}\"",
        link="/connections"
    )
    db.add(notif)
    db.commit()
    db.refresh(new_req)

    return ConnectionRequestOut(
        id=new_req.id,
        sender_id=current_user.id,
        sender_name=current_user.full_name,
        sender_avatar=get_avatar_id(current_user),
        sender_college=get_college(current_user),
        sender_course=get_course(current_user),
        receiver_id=receiver.id,
        receiver_name=receiver.full_name,
        receiver_avatar=get_avatar_id(receiver),
        status=new_req.status,
        message=new_req.message,
        created_at=new_req.created_at,
        updated_at=new_req.updated_at
    )

@router.get("", response_model=Dict[str, Any])
def get_user_connections(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    # Incoming pending
    incoming = db.query(ConnectionRequest).filter(
        ConnectionRequest.receiver_id == current_user.id,
        ConnectionRequest.status == "pending"
    ).order_by(ConnectionRequest.created_at.desc()).all()

    # Outgoing pending
    outgoing = db.query(ConnectionRequest).filter(
        ConnectionRequest.sender_id == current_user.id,
        ConnectionRequest.status == "pending"
    ).order_by(ConnectionRequest.created_at.desc()).all()

    # Accepted connections
    accepted_records = db.query(ConnectionRequest).filter(
        ((ConnectionRequest.sender_id == current_user.id) | (ConnectionRequest.receiver_id == current_user.id)),
        ConnectionRequest.status == "accepted"
    ).all()

    accepted_peers = []
    for req in accepted_records:
        peer = req.receiver if req.sender_id == current_user.id else req.sender
        if peer and peer.is_active:
            accepted_peers.append({
                "connection_id": req.id,
                "peer_id": peer.id,
                "full_name": peer.full_name,
                "avatar_id": get_avatar_id(peer),
                "college": get_college(peer),
                "course": get_course(peer),
                "semester": peer.profile.semester if peer.profile else 1,
                "rating_avg": peer.profile.rating_avg if peer.profile else 5.0,
                "connected_since": req.updated_at
            })

    def format_req(r: ConnectionRequest):
        return ConnectionRequestOut(
            id=r.id,
            sender_id=r.sender_id,
            sender_name=r.sender.full_name,
            sender_avatar=get_avatar_id(r.sender),
            sender_college=get_college(r.sender),
            sender_course=get_course(r.sender),
            receiver_id=r.receiver_id,
            receiver_name=r.receiver.full_name,
            receiver_avatar=get_avatar_id(r.receiver),
            status=r.status,
            message=r.message,
            created_at=r.created_at,
            updated_at=r.updated_at
        )

    return {
        "incoming_pending": [format_req(r) for r in incoming],
        "outgoing_pending": [format_req(r) for r in outgoing],
        "accepted_peers": accepted_peers,
        "total_connections": len(accepted_peers)
    }

@router.put("/{request_id}/accept")
def accept_connection_request(
    request_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    conn_req = db.query(ConnectionRequest).filter(
        ConnectionRequest.id == request_id,
        ConnectionRequest.receiver_id == current_user.id,
        ConnectionRequest.status == "pending"
    ).first()

    if not conn_req:
        raise HTTPException(status_code=404, detail="Pending connection request not found.")

    conn_req.status = "accepted"
    conn_req.updated_at = datetime.utcnow()

    # Ensure conversation exists
    conv = db.query(Conversation).filter(
        ((Conversation.user1_id == conn_req.sender_id) & (Conversation.user2_id == conn_req.receiver_id)) |
        ((Conversation.user1_id == conn_req.receiver_id) & (Conversation.user2_id == conn_req.sender_id))
    ).first()
    if not conv:
        conv = Conversation(user1_id=conn_req.sender_id, user2_id=conn_req.receiver_id)
        db.add(conv)

    # Award badge if first connection
    first_badge = db.query(Badge).filter(Badge.user_id == current_user.id, Badge.badge_code == "connected_peer").first()
    if not first_badge:
        db.add(Badge(
            user_id=current_user.id,
            badge_code="connected_peer",
            badge_title="Connected Peer",
            badge_icon="🤝",
            description="Established your first learning connection on Skill Bloom"
        ))

    # Sender notification
    notif = Notification(
        user_id=conn_req.sender_id,
        type="connection_accepted",
        title="Connection Accepted!",
        content=f"{current_user.full_name} accepted your connection request. Start chatting or schedule a learning session!",
        link="/chat"
    )
    db.add(notif)
    db.commit()

    return {"message": "Connection request accepted successfully"}

@router.put("/{request_id}/reject")
def reject_connection_request(
    request_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    conn_req = db.query(ConnectionRequest).filter(
        ConnectionRequest.id == request_id,
        ConnectionRequest.receiver_id == current_user.id,
        ConnectionRequest.status == "pending"
    ).first()

    if not conn_req:
        raise HTTPException(status_code=404, detail="Pending connection request not found.")

    conn_req.status = "rejected"
    conn_req.updated_at = datetime.utcnow()
    db.commit()

    return {"message": "Connection request rejected"}

@router.delete("/{request_id}/cancel")
def cancel_outgoing_request(
    request_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    conn_req = db.query(ConnectionRequest).filter(
        ConnectionRequest.id == request_id,
        ConnectionRequest.sender_id == current_user.id,
        ConnectionRequest.status == "pending"
    ).first()

    if not conn_req:
        raise HTTPException(status_code=404, detail="Outgoing pending request not found.")

    db.delete(conn_req)
    db.commit()
    return {"message": "Connection request cancelled"}

@router.delete("/disconnect/{peer_id}")
def disconnect_peer(
    peer_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    conn = db.query(ConnectionRequest).filter(
        ((ConnectionRequest.sender_id == current_user.id) & (ConnectionRequest.receiver_id == peer_id)) |
        ((ConnectionRequest.sender_id == peer_id) & (ConnectionRequest.receiver_id == current_user.id)),
        ConnectionRequest.status == "accepted"
    ).first()

    if not conn:
        raise HTTPException(status_code=404, detail="Active connection not found.")

    db.delete(conn)
    db.commit()
    return {"message": "Successfully disconnected."}

@router.post("/block-report")
def block_or_report_user(
    body: BlockReportCreate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    if body.target_id == current_user.id:
        raise HTTPException(status_code=400, detail="Cannot block or report yourself.")

    target = db.query(User).filter(User.id == body.target_id).first()
    if not target:
        raise HTTPException(status_code=404, detail="Target user not found.")

    # Record block/report
    record = UserBlockReport(
        reporter_id=current_user.id,
        target_id=body.target_id,
        action=body.action,
        reason=body.reason
    )
    db.add(record)

    # If action is block, remove any connection
    if body.action == "block":
        existing_conns = db.query(ConnectionRequest).filter(
            ((ConnectionRequest.sender_id == current_user.id) & (ConnectionRequest.receiver_id == body.target_id)) |
            ((ConnectionRequest.sender_id == body.target_id) & (ConnectionRequest.receiver_id == current_user.id))
        ).all()
        for c in existing_conns:
            db.delete(c)

    db.commit()
    return {"message": f"User successfully {body.action}ed."}
