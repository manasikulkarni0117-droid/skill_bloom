from datetime import datetime
from typing import List
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from app.database import get_db
from app.models import User, ConnectionRequest, Conversation, Message, Notification
from app.schemas import MessageCreate, MessageOut, ConversationSummary
from app.auth import get_current_user

router = APIRouter(prefix="/api/chat", tags=["Private Chat"])

def get_avatar_id(user: User) -> str:
    return user.profile.avatar_id if user.profile and user.profile.avatar_id else "avatar-owl"

def ensure_accepted_connection(db: Session, user1_id: int, user2_id: int):
    conn = db.query(ConnectionRequest).filter(
        ((ConnectionRequest.sender_id == user1_id) & (ConnectionRequest.receiver_id == user2_id)) |
        ((ConnectionRequest.sender_id == user2_id) & (ConnectionRequest.receiver_id == user1_id)),
        ConnectionRequest.status == "accepted"
    ).first()
    if not conn:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Access denied. Private chat is only permitted between mutually accepted connections."
        )

@router.get("/conversations", response_model=List[ConversationSummary])
def get_conversations(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    # Find all accepted peers
    conns = db.query(ConnectionRequest).filter(
        ((ConnectionRequest.sender_id == current_user.id) | (ConnectionRequest.receiver_id == current_user.id)),
        ConnectionRequest.status == "accepted"
    ).all()

    summaries = []
    for c in conns:
        peer = c.receiver if c.sender_id == current_user.id else c.sender
        if not peer or not peer.is_active:
            continue

        conv = db.query(Conversation).filter(
            ((Conversation.user1_id == current_user.id) & (Conversation.user2_id == peer.id)) |
            ((Conversation.user1_id == peer.id) & (Conversation.user2_id == current_user.id))
        ).first()

        if not conv:
            conv = Conversation(user1_id=current_user.id, user2_id=peer.id)
            db.add(conv)
            db.commit()
            db.refresh(conv)

        # Get latest message
        last_msg = db.query(Message).filter(Message.conversation_id == conv.id).order_by(Message.created_at.desc()).first()
        unread_count = db.query(Message).filter(
            Message.conversation_id == conv.id,
            Message.sender_id == peer.id,
            Message.is_read == False
        ).count()

        summaries.append(ConversationSummary(
            id=conv.id,
            peer_user_id=peer.id,
            peer_name=peer.full_name,
            peer_avatar=get_avatar_id(peer),
            peer_college=peer.profile.college if peer.profile else "College",
            peer_course=peer.profile.course if peer.profile else "Course",
            last_message=last_msg.content if last_msg else "No messages yet",
            last_message_time=last_msg.created_at if last_msg else conv.created_at,
            unread_count=unread_count
        ))

    summaries.sort(key=lambda s: s.last_message_time or datetime.min, reverse=True)
    return summaries

@router.get("/messages/{peer_id}", response_model=List[MessageOut])
def get_chat_history(
    peer_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    # Enforce strict backend connection verification
    ensure_accepted_connection(db, current_user.id, peer_id)

    conv = db.query(Conversation).filter(
        ((Conversation.user1_id == current_user.id) & (Conversation.user2_id == peer_id)) |
        ((Conversation.user1_id == peer_id) & (Conversation.user2_id == current_user.id))
    ).first()

    if not conv:
        conv = Conversation(user1_id=current_user.id, user2_id=peer_id)
        db.add(conv)
        db.commit()
        db.refresh(conv)

    # Mark peer's unread messages as read
    unread_msgs = db.query(Message).filter(
        Message.conversation_id == conv.id,
        Message.sender_id == peer_id,
        Message.is_read == False
    ).all()

    now = datetime.utcnow()
    for m in unread_msgs:
        m.is_read = True
        m.read_at = now
    if unread_msgs:
        db.commit()

    messages = db.query(Message).filter(Message.conversation_id == conv.id).order_by(Message.created_at.asc()).all()

    return [
        MessageOut(
            id=m.id,
            conversation_id=m.conversation_id,
            sender_id=m.sender_id,
            sender_name=m.sender.full_name if m.sender else "",
            sender_avatar=get_avatar_id(m.sender) if m.sender else "avatar-owl",
            content=m.content,
            is_read=m.is_read,
            read_at=m.read_at,
            created_at=m.created_at
        )
        for m in messages
    ]

@router.post("/send", response_model=MessageOut)
def send_chat_message(
    msg_in: MessageCreate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    receiver_id = msg_in.receiver_id
    ensure_accepted_connection(db, current_user.id, receiver_id)

    conv = db.query(Conversation).filter(
        ((Conversation.user1_id == current_user.id) & (Conversation.user2_id == receiver_id)) |
        ((Conversation.user1_id == receiver_id) & (Conversation.user2_id == current_user.id))
    ).first()

    if not conv:
        conv = Conversation(user1_id=current_user.id, user2_id=receiver_id)
        db.add(conv)
        db.commit()
        db.refresh(conv)

    new_msg = Message(
        conversation_id=conv.id,
        sender_id=current_user.id,
        content=msg_in.content.strip(),
        is_read=False
    )
    db.add(new_msg)
    conv.updated_at = datetime.utcnow()

    # Trigger notification if needed
    notif = Notification(
        user_id=receiver_id,
        type="new_message",
        title=f"Message from {current_user.full_name}",
        content=msg_in.content[:80] + ("..." if len(msg_in.content) > 80 else ""),
        link="/chat"
    )
    db.add(notif)
    db.commit()
    db.refresh(new_msg)

    return MessageOut(
        id=new_msg.id,
        conversation_id=new_msg.conversation_id,
        sender_id=new_msg.sender_id,
        sender_name=current_user.full_name,
        sender_avatar=get_avatar_id(current_user),
        content=new_msg.content,
        is_read=new_msg.is_read,
        read_at=new_msg.read_at,
        created_at=new_msg.created_at
    )
