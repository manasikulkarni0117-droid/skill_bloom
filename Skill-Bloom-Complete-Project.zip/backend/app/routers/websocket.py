import json
import logging
from typing import Dict, Set
from fastapi import APIRouter, WebSocket, WebSocketDisconnect

logger = logging.getLogger("skillbloom.websocket")

router = APIRouter(tags=["WebSockets"])

# Chat connection manager: user_id -> set of active WebSockets
class ChatConnectionManager:
    def __init__(self):
        self.active_connections: Dict[int, Set[WebSocket]] = {}

    async def connect(self, user_id: int, websocket: WebSocket):
        await websocket.accept()
        if user_id not in self.active_connections:
            self.active_connections[user_id] = set()
        self.active_connections[user_id].add(websocket)

    def disconnect(self, user_id: int, websocket: WebSocket):
        if user_id in self.active_connections:
            self.active_connections[user_id].discard(websocket)
            if not self.active_connections[user_id]:
                del self.active_connections[user_id]

    async def send_to_user(self, user_id: int, message: dict):
        if user_id in self.active_connections:
            dead_sockets = set()
            for ws in self.active_connections[user_id]:
                try:
                    await ws.send_json(message)
                except Exception:
                    dead_sockets.add(ws)
            for ws in dead_sockets:
                self.disconnect(user_id, ws)

chat_manager = ChatConnectionManager()

# WebRTC Signaling Manager: room_id -> { user_id -> WebSocket }
class SignalingManager:
    def __init__(self):
        self.rooms: Dict[str, Dict[int, WebSocket]] = {}

    async def join_room(self, room_id: str, user_id: int, websocket: WebSocket):
        await websocket.accept()
        if room_id not in self.rooms:
            self.rooms[room_id] = {}
        
        # Notify existing participants in the room
        for existing_uid, existing_ws in self.rooms[room_id].items():
            if existing_uid != user_id:
                try:
                    await existing_ws.send_json({
                        "type": "user-joined",
                        "userId": user_id,
                        "roomId": room_id
                    })
                except Exception:
                    pass

        self.rooms[room_id][user_id] = websocket

        # Inform the joining user about existing peers in the room
        existing_peers = [uid for uid in self.rooms[room_id].keys() if uid != user_id]
        await websocket.send_json({
            "type": "room-info",
            "roomId": room_id,
            "peers": existing_peers
        })

    async def leave_room(self, room_id: str, user_id: int):
        if room_id in self.rooms:
            if user_id in self.rooms[room_id]:
                del self.rooms[room_id][user_id]
            # Notify remaining peers
            for peer_ws in self.rooms[room_id].values():
                try:
                    await peer_ws.send_json({
                        "type": "user-left",
                        "userId": user_id,
                        "roomId": room_id
                    })
                except Exception:
                    pass
            if not self.rooms[room_id]:
                del self.rooms[room_id]

    async def send_signal(self, room_id: str, target_user_id: int, message: dict):
        if room_id in self.rooms and target_user_id in self.rooms[room_id]:
            try:
                await self.rooms[room_id][target_user_id].send_json(message)
            except Exception:
                pass

    async def broadcast_room(self, room_id: str, sender_id: int, message: dict):
        if room_id in self.rooms:
            for uid, ws in self.rooms[room_id].items():
                if uid != sender_id:
                    try:
                        await ws.send_json(message)
                    except Exception:
                        pass

signaling_manager = SignalingManager()


@router.websocket("/ws/chat/{user_id}")
async def websocket_chat_endpoint(websocket: WebSocket, user_id: int):
    await chat_manager.connect(user_id, websocket)
    try:
        while True:
            data = await websocket.receive_text()
            # Heartbeat / ping or client ack
            try:
                payload = json.loads(data)
                if payload.get("type") == "ping":
                    await websocket.send_json({"type": "pong"})
            except Exception:
                pass
    except WebSocketDisconnect:
        chat_manager.disconnect(user_id, websocket)
    except Exception:
        chat_manager.disconnect(user_id, websocket)


@router.websocket("/ws/signaling/{room_id}/{user_id}")
async def websocket_signaling_endpoint(websocket: WebSocket, room_id: str, user_id: int):
    await signaling_manager.join_room(room_id, user_id, websocket)
    try:
        while True:
            raw_data = await websocket.receive_text()
            data = json.loads(raw_data)
            msg_type = data.get("type")
            target_id = data.get("targetUserId")

            if msg_type in ["offer", "answer", "ice-candidate"]:
                # Forward to target peer
                if target_id is not None:
                    data["fromUserId"] = user_id
                    await signaling_manager.send_signal(room_id, int(target_id), data)
            elif msg_type == "in-call-message":
                # In-call chat message broadcasted to other participants
                data["fromUserId"] = user_id
                await signaling_manager.broadcast_room(room_id, user_id, data)
            elif msg_type == "ping":
                await websocket.send_json({"type": "pong"})
    except WebSocketDisconnect:
        await signaling_manager.leave_room(room_id, user_id)
    except Exception:
        await signaling_manager.leave_room(room_id, user_id)
