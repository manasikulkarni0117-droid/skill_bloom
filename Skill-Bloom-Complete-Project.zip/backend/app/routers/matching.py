from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from app.database import get_db
from app.models import Subject, User, LearningGoal
from app.schemas import MatchedStudentOut
from app.matching import rank_teachers_for_subject
from app.auth import get_current_user_optional, get_current_user

router = APIRouter(prefix="/api/matching", tags=["Matching & Ranking"])

@router.get("/subject/{subject_id}", response_model=List[MatchedStudentOut])
def get_ranked_mentors(
    subject_id: int,
    proficiency: Optional[str] = Query(None, description="Proficiency level filter: Beginner, Intermediate, Advanced"),
    course: Optional[str] = Query(None, description="Course filter"),
    language: Optional[str] = Query(None, description="Language filter"),
    min_rating: Optional[float] = Query(None, description="Minimum rating filter e.g. 4.0"),
    availability: Optional[str] = Query(None, description="Availability keyword filter"),
    current_user: Optional[User] = Depends(get_current_user_optional),
    db: Session = Depends(get_db)
):
    subject = db.query(Subject).filter(Subject.id == subject_id).first()
    if not subject:
        raise HTTPException(status_code=404, detail="Subject not found")

    ranked_teachers = rank_teachers_for_subject(
        db=db,
        subject_id=subject_id,
        learner_user=current_user,
        proficiency_filter=proficiency,
        course_filter=course,
        language_filter=language,
        min_rating=min_rating,
        availability_filter=availability
    )

    return ranked_teachers

@router.get("/recommendations", response_model=List[MatchedStudentOut])
def get_user_recommendations(
    limit: int = 6,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Returns top recommended peer mentors for the current user based on
    their listed learning goals.
    """
    user_goals = db.query(LearningGoal).filter(LearningGoal.user_id == current_user.id).all()
    if not user_goals:
        # If user has not added learning goals yet, recommend top mentors from popular subjects
        top_subjects = db.query(Subject).limit(3).all()
        candidate_list = []
        for s in top_subjects:
            ranked = rank_teachers_for_subject(db=db, subject_id=s.id, learner_user=current_user)
            candidate_list.extend(ranked)
        # Deduplicate by user_id
        seen = set()
        deduped = []
        for c in candidate_list:
            if c.user_id not in seen:
                seen.add(c.user_id)
                deduped.append(c)
        return deduped[:limit]

    all_recommendations = []
    seen_users = set()
    for goal in user_goals:
        ranked = rank_teachers_for_subject(db=db, subject_id=goal.subject_id, learner_user=current_user)
        for cand in ranked:
            if cand.user_id not in seen_users:
                seen_users.add(cand.user_id)
                all_recommendations.append(cand)

    all_recommendations.sort(key=lambda x: x.estimated_match_percentage, reverse=True)
    return all_recommendations[:limit]
