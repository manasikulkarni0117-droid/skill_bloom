import uuid
from datetime import datetime
from typing import List
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from sqlalchemy import func
from app.database import get_db
from app.models import (
    User, ConnectionRequest, LearningSession, SessionReview,
    Subject, Notification, Badge, StudentProfile
)
from app.schemas import (
    LearningSessionCreate, LearningSessionOut,
    SessionReviewCreate, SessionReviewOut
)
from app.auth import get_current_user

router = APIRouter(prefix="/api/sessions", tags=["Learning Sessions"])

def get_avatar_id(user: User) -> str:
    return user.profile.avatar_id if user.profile and user.profile.avatar_id else "avatar-owl"

def ensure_accepted_connection(db: Session, user1_id: int, user2_id: int):
    conn = db.query(ConnectionRequest).filter(
        ((ConnectionRequest.sender_id == user1_id) & (ConnectionRequest.receiver_id == user2_id)) |
        ((ConnectionRequest.sender_id == user2_id) & (ConnectionRequest.receiver_id == user1_id)),
        ConnectionRequest.status == "accepted"
    ).first()
    if not conn:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Learning sessions can only be scheduled between mutually connected peers."
        )

@router.post("", response_model=LearningSessionOut)
def schedule_session(
    session_in: LearningSessionCreate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    peer_id = session_in.peer_id
    if peer_id == current_user.id:
        raise HTTPException(status_code=400, detail="Cannot schedule a session with yourself.")

    ensure_accepted_connection(db, current_user.id, peer_id)

    peer = db.query(User).filter(User.id == peer_id, User.is_active == True).first()
    if not peer:
        raise HTTPException(status_code=404, detail="Peer not found.")

    subject = db.query(Subject).filter(Subject.id == session_in.subject_id).first()
    if not subject:
        raise HTTPException(status_code=404, detail="Subject not found.")

    if session_in.as_teacher:
        host_id = current_user.id
        learner_id = peer_id
    else:
        host_id = peer_id
        learner_id = current_user.id

    room_code = f"sb-{uuid.uuid4().hex[:10]}"

    new_session = LearningSession(
        host_id=host_id,
        learner_id=learner_id,
        subject_id=session_in.subject_id,
        title=session_in.title.strip(),
        description=session_in.description.strip() if session_in.description else "",
        scheduled_time=session_in.scheduled_time,
        duration_minutes=session_in.duration_minutes or 60,
        status="scheduled",
        meeting_room_id=room_code
    )
    db.add(new_session)
    db.flush()

    # Create notification for peer
    other_id = peer_id
    notif = Notification(
        user_id=other_id,
        type="session_scheduled",
        title="Learning Session Scheduled",
        content=f"{current_user.full_name} scheduled a 1-on-1 session: '{new_session.title}' on {subject.name}.",
        link=f"/sessions"
    )
    db.add(notif)
    db.commit()
    db.refresh(new_session)

    host = new_session.host
    learner = new_session.learner

    return LearningSessionOut(
        id=new_session.id,
        host_id=new_session.host_id,
        host_name=host.full_name,
        host_avatar=get_avatar_id(host),
        learner_id=new_session.learner_id,
        learner_name=learner.full_name,
        learner_avatar=get_avatar_id(learner),
        subject_id=subject.id,
        subject_name=subject.name,
        title=new_session.title,
        description=new_session.description,
        scheduled_time=new_session.scheduled_time,
        duration_minutes=new_session.duration_minutes,
        status=new_session.status,
        meeting_room_id=new_session.meeting_room_id,
        meeting_notes=new_session.meeting_notes,
        is_host=(new_session.host_id == current_user.id),
        has_reviewed=False,
        created_at=new_session.created_at
    )

@router.get("", response_model=List[LearningSessionOut])
def list_my_sessions(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    sessions = db.query(LearningSession).filter(
        (LearningSession.host_id == current_user.id) | (LearningSession.learner_id == current_user.id)
    ).order_by(LearningSession.scheduled_time.desc()).all()

    # Find which ones have reviews by current user
    reviewed_session_ids = set(
        r[0] for r in db.query(SessionReview.session_id).filter(
            SessionReview.reviewer_id == current_user.id
        ).all()
    )

    out = []
    for s in sessions:
        host = s.host
        learner = s.learner
        subj = s.subject
        out.append(LearningSessionOut(
            id=s.id,
            host_id=s.host_id,
            host_name=host.full_name if host else "Host",
            host_avatar=get_avatar_id(host) if host else "avatar-owl",
            learner_id=s.learner_id,
            learner_name=learner.full_name if learner else "Learner",
            learner_avatar=get_avatar_id(learner) if learner else "avatar-owl",
            subject_id=subj.id if subj else 0,
            subject_name=subj.name if subj else "General Subject",
            title=s.title,
            description=s.description,
            scheduled_time=s.scheduled_time,
            duration_minutes=s.duration_minutes,
            status=s.status,
            meeting_room_id=s.meeting_room_id,
            meeting_notes=s.meeting_notes,
            is_host=(s.host_id == current_user.id),
            has_reviewed=(s.id in reviewed_session_ids),
            created_at=s.created_at
        ))

    return out

@router.get("/{session_id}", response_model=LearningSessionOut)
def get_session_detail(
    session_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    s = db.query(LearningSession).filter(LearningSession.id == session_id).first()
    if not s:
        raise HTTPException(status_code=404, detail="Session not found.")

    if current_user.id not in [s.host_id, s.learner_id]:
        raise HTTPException(status_code=403, detail="Unauthorized to access this session.")

    reviewed = db.query(SessionReview).filter(
        SessionReview.session_id == s.id,
        SessionReview.reviewer_id == current_user.id
    ).first() is not None

    return LearningSessionOut(
        id=s.id,
        host_id=s.host_id,
        host_name=s.host.full_name,
        host_avatar=get_avatar_id(s.host),
        learner_id=s.learner_id,
        learner_name=s.learner.full_name,
        learner_avatar=get_avatar_id(s.learner),
        subject_id=s.subject.id,
        subject_name=s.subject.name,
        title=s.title,
        description=s.description,
        scheduled_time=s.scheduled_time,
        duration_minutes=s.duration_minutes,
        status=s.status,
        meeting_room_id=s.meeting_room_id,
        meeting_notes=s.meeting_notes,
        is_host=(s.host_id == current_user.id),
        has_reviewed=reviewed,
        created_at=s.created_at
    )

@router.put("/{session_id}/complete")
def complete_session(
    session_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    s = db.query(LearningSession).filter(LearningSession.id == session_id).first()
    if not s:
        raise HTTPException(status_code=404, detail="Session not found.")

    if current_user.id not in [s.host_id, s.learner_id]:
        raise HTTPException(status_code=403, detail="Unauthorized.")

    if s.status != "completed":
        s.status = "completed"

        # Increment completed counts
        for uid in [s.host_id, s.learner_id]:
            prof = db.query(StudentProfile).filter(StudentProfile.user_id == uid).first()
            if prof:
                prof.completed_sessions_count = (prof.completed_sessions_count or 0) + 1

                # Check milestone badges
                if prof.completed_sessions_count == 1:
                    existing = db.query(Badge).filter(Badge.user_id == uid, Badge.badge_code == "first_bloom").first()
                    if not existing:
                        db.add(Badge(
                            user_id=uid,
                            badge_code="first_bloom",
                            badge_title="First Bloom 🌸",
                            badge_icon="🌸",
                            description="Successfully completed your first peer learning session!"
                        ))
                elif prof.completed_sessions_count == 5:
                    existing = db.query(Badge).filter(Badge.user_id == uid, Badge.badge_code == "active_learner").first()
                    if not existing:
                        db.add(Badge(
                            user_id=uid,
                            badge_code="active_learner",
                            badge_title="Active Peer 🚀",
                            badge_icon="🚀",
                            description="Completed 5 peer sessions on Skill Bloom!"
                        ))

        # Notify the other participant
        other_id = s.learner_id if current_user.id == s.host_id else s.host_id
        db.add(Notification(
            user_id=other_id,
            type="review_prompt",
            title="Session Completed — Please Leave Feedback",
            content=f"Your session '{s.title}' is marked complete! Share your feedback and rating.",
            link="/sessions"
        ))
        db.commit()

    return {"message": "Session completed successfully"}

@router.put("/{session_id}/cancel")
def cancel_session(
    session_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    s = db.query(LearningSession).filter(LearningSession.id == session_id).first()
    if not s:
        raise HTTPException(status_code=404, detail="Session not found.")

    if current_user.id not in [s.host_id, s.learner_id]:
        raise HTTPException(status_code=403, detail="Unauthorized.")

    s.status = "cancelled"
    db.commit()
    return {"message": "Session cancelled"}

@router.post("/reviews", response_model=SessionReviewOut)
def submit_session_review(
    rev_in: SessionReviewCreate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    s = db.query(LearningSession).filter(LearningSession.id == rev_in.session_id).first()
    if not s:
        raise HTTPException(status_code=404, detail="Session not found.")

    if current_user.id not in [s.host_id, s.learner_id]:
        raise HTTPException(status_code=403, detail="You can only review sessions you attended.")

    # Target of review is the other participant
    reviewee_id = s.learner_id if current_user.id == s.host_id else s.host_id

    # Check for duplicate review
    existing = db.query(SessionReview).filter(
        SessionReview.session_id == s.id,
        SessionReview.reviewer_id == current_user.id
    ).first()
    if existing:
        raise HTTPException(status_code=400, detail="You have already submitted a review for this session.")

    new_rev = SessionReview(
        session_id=s.id,
        reviewer_id=current_user.id,
        reviewee_id=reviewee_id,
        rating=float(rev_in.rating),
        teaching_clarity=rev_in.teaching_clarity,
        helpfulness=rev_in.helpfulness,
        punctuality=rev_in.punctuality,
        feedback=rev_in.feedback.strip()
    )
    db.add(new_rev)
    db.flush()

    # Recalculate target student's rating_avg and total_reviews
    all_reviews = db.query(SessionReview).filter(SessionReview.reviewee_id == reviewee_id).all()
    target_profile = db.query(StudentProfile).filter(StudentProfile.user_id == reviewee_id).first()
    if target_profile and all_reviews:
        total = len(all_reviews)
        avg = sum(r.rating for r in all_reviews) / float(total)
        target_profile.rating_avg = round(avg, 2)
        target_profile.total_reviews = total

        # Award badge if 5-star mentor milestone
        if total >= 3 and avg >= 4.8:
            b_exist = db.query(Badge).filter(Badge.user_id == reviewee_id, Badge.badge_code == "five_star_mentor").first()
            if not b_exist:
                db.add(Badge(
                    user_id=reviewee_id,
                    badge_code="five_star_mentor",
                    badge_title="Five-Star Mentor ⭐",
                    badge_icon="⭐",
                    description="Maintained high-trust ratings across multiple peer learning sessions"
                ))

    # Send notification to reviewee
    db.add(Notification(
        user_id=reviewee_id,
        type="review_received",
        title="New Feedback Received",
        content=f"{current_user.full_name} gave you a {rev_in.rating}-star review: \"{rev_in.feedback[:60]}\"",
        link="/profile"
    ))

    db.commit()
    db.refresh(new_rev)

    return SessionReviewOut(
        id=new_rev.id,
        session_id=new_rev.session_id,
        reviewer_id=new_rev.reviewer_id,
        reviewer_name=current_user.full_name,
        reviewer_avatar=get_avatar_id(current_user),
        rating=new_rev.rating,
        teaching_clarity=new_rev.teaching_clarity,
        helpfulness=new_rev.helpfulness,
        punctuality=new_rev.punctuality,
        feedback=new_rev.feedback,
        created_at=new_rev.created_at
    )
