from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.orm import Session
from sqlalchemy import func
from app.database import get_db
from app.models import Subject, StudentSkill, LearningGoal, User
from app.schemas import SubjectOut, SubjectCreate
from app.auth import get_current_user

router = APIRouter(prefix="/api/subjects", tags=["Subjects"])

@router.get("/categories", response_model=List[str])
def get_categories(db: Session = Depends(get_db)):
    categories = db.query(Subject.category).distinct().all()
    return sorted([c[0] for c in categories if c[0]])

@router.get("", response_model=List[SubjectOut])
def list_subjects(
    q: Optional[str] = None,
    category: Optional[str] = None,
    semester: Optional[int] = None,
    db: Session = Depends(get_db)
):
    query = db.query(Subject)

    if q and q.strip():
        search_val = f"%{q.strip()}%"
        query = query.filter(
            (Subject.name.ilike(search_val)) |
            (Subject.code.ilike(search_val)) |
            (Subject.description.ilike(search_val))
        )

    if category and category.strip() and category != "All":
        query = query.filter(Subject.category == category.strip())

    if semester:
        query = query.filter(Subject.semester_recommended == semester)

    subjects = query.order_by(Subject.name.asc()).all()

    # Calculate counts of teachers and learners per subject
    res = []
    for s in subjects:
        teachers_count = db.query(func.count(StudentSkill.id)).filter(StudentSkill.subject_id == s.id).scalar() or 0
        learners_count = db.query(func.count(LearningGoal.id)).filter(LearningGoal.subject_id == s.id).scalar() or 0
        s_out = SubjectOut(
            id=s.id,
            name=s.name,
            code=s.code,
            category=s.category,
            semester_recommended=s.semester_recommended,
            description=s.description,
            is_custom=s.is_custom,
            created_by_user_id=s.created_by_user_id,
            teachers_count=teachers_count,
            learners_count=learners_count
        )
        res.append(s_out)
    return res

@router.get("/{subject_id}", response_model=SubjectOut)
def get_subject_detail(subject_id: int, db: Session = Depends(get_db)):
    subject = db.query(Subject).filter(Subject.id == subject_id).first()
    if not subject:
        raise HTTPException(status_code=404, detail="Subject not found")

    teachers_count = db.query(func.count(StudentSkill.id)).filter(StudentSkill.subject_id == subject.id).scalar() or 0
    learners_count = db.query(func.count(LearningGoal.id)).filter(LearningGoal.subject_id == subject.id).scalar() or 0

    return SubjectOut(
        id=subject.id,
        name=subject.name,
        code=subject.code,
        category=subject.category,
        semester_recommended=subject.semester_recommended,
        description=subject.description,
        is_custom=subject.is_custom,
        created_by_user_id=subject.created_by_user_id,
        teachers_count=teachers_count,
        learners_count=learners_count
    )

@router.post("", response_model=SubjectOut)
def create_custom_subject(
    subj_in: SubjectCreate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    # Check if subject with same name already exists
    existing = db.query(Subject).filter(Subject.name.ilike(subj_in.name.strip())).first()
    if existing:
        return SubjectOut(
            id=existing.id,
            name=existing.name,
            code=existing.code,
            category=existing.category,
            semester_recommended=existing.semester_recommended,
            description=existing.description,
            is_custom=existing.is_custom,
            created_by_user_id=existing.created_by_user_id,
            teachers_count=0,
            learners_count=0
        )

    new_subj = Subject(
        name=subj_in.name.strip(),
        code=subj_in.code.strip() if subj_in.code else None,
        category=subj_in.category.strip() if subj_in.category else "Computer Science",
        semester_recommended=subj_in.semester_recommended or 3,
        description=subj_in.description,
        is_custom=True,
        created_by_user_id=current_user.id
    )
    db.add(new_subj)
    db.commit()
    db.refresh(new_subj)

    return SubjectOut(
        id=new_subj.id,
        name=new_subj.name,
        code=new_subj.code,
        category=new_subj.category,
        semester_recommended=new_subj.semester_recommended,
        description=new_subj.description,
        is_custom=True,
        created_by_user_id=current_user.id,
        teachers_count=0,
        learners_count=0
    )
