from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from app.database import get_db
from app.models import (
    User, StudentProfile, StudentSkill, LearningGoal,
    CertificateProject, SessionReview, ConnectionRequest, Badge, Subject
)
from app.schemas import (
    StudentProfileOut, StudentProfileUpdate,
    StudentSkillCreate, StudentSkillOut,
    LearningGoalCreate, LearningGoalOut
)
from app.auth import get_current_user, get_current_user_optional

router = APIRouter(prefix="/api/profiles", tags=["Profiles"])

@router.get("/me", response_model=StudentProfileOut)
def get_my_profile(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    profile = current_user.profile
    if not profile:
        profile = StudentProfile(user_id=current_user.id)
        db.add(profile)
        db.commit()
        db.refresh(profile)

    # Format skills
    skills_out = []
    for s in current_user.skills_taught:
        skills_out.append(StudentSkillOut(
            id=s.id,
            subject_id=s.subject_id,
            subject_name=s.subject.name if s.subject else "Unknown",
            category=s.subject.category if s.subject else "General",
            proficiency_level=s.proficiency_level,
            experience_note=s.experience_note,
            verification_status=s.verification_status,
            assessment_score=s.assessment_score
        ))

    # Format goals
    goals_out = []
    for g in current_user.learning_goals:
        goals_out.append(LearningGoalOut(
            id=g.id,
            subject_id=g.subject_id,
            subject_name=g.subject.name if g.subject else "Unknown",
            category=g.subject.category if g.subject else "General",
            urgency=g.urgency,
            preferred_pace=g.preferred_pace,
            current_understanding=g.current_understanding
        ))

    # Format reviews
    reviews_out = []
    reviews = db.query(SessionReview).filter(SessionReview.reviewee_id == current_user.id).order_by(SessionReview.created_at.desc()).all()
    for r in reviews:
        reviewer_name = r.reviewer.full_name if r.reviewer else "Peer Student"
        reviewer_avatar = r.reviewer.profile.avatar_id if r.reviewer and r.reviewer.profile else "avatar-owl"
        reviews_out.append({
            "id": r.id,
            "session_id": r.session_id,
            "reviewer_id": r.reviewer_id,
            "reviewer_name": reviewer_name,
            "reviewer_avatar": reviewer_avatar,
            "rating": r.rating,
            "teaching_clarity": r.teaching_clarity,
            "helpfulness": r.helpfulness,
            "punctuality": r.punctuality,
            "feedback": r.feedback,
            "created_at": r.created_at
        })

    # Format portfolio items
    portfolio_out = []
    for p in current_user.portfolio_items:
        portfolio_out.append({
            "id": p.id,
            "user_id": p.user_id,
            "subject_id": p.subject_id,
            "subject_name": p.subject.name if hasattr(p, 'subject') and p.subject else None,
            "item_type": p.item_type,
            "title": p.title,
            "issuing_organization": p.issuing_organization,
            "file_path": p.file_path,
            "original_filename": p.original_filename,
            "file_type": p.file_type,
            "file_size": p.file_size,
            "github_url": p.github_url,
            "live_url": p.live_url,
            "description": p.description,
            "verification_status": p.verification_status,
            "created_at": p.created_at
        })

    return StudentProfileOut(
        user_id=current_user.id,
        full_name=current_user.full_name,
        email=current_user.email,
        avatar_id=profile.avatar_id,
        college=profile.college,
        course=profile.course,
        semester=profile.semester,
        preferred_language=profile.preferred_language,
        availability=profile.availability,
        bio=profile.bio,
        rating_avg=profile.rating_avg,
        total_reviews=profile.total_reviews,
        completed_sessions_count=profile.completed_sessions_count,
        documents_privacy=profile.documents_privacy,
        skills_taught=skills_out,
        learning_goals=goals_out,
        portfolio_items=portfolio_out,
        badges=current_user.badges,
        reviews=reviews_out,
        connection_status_with_viewer="self"
    )

@router.put("/me")
def update_my_profile(
    profile_in: StudentProfileUpdate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    profile = current_user.profile
    if not profile:
        profile = StudentProfile(user_id=current_user.id)
        db.add(profile)

    if profile_in.avatar_id is not None:
        profile.avatar_id = profile_in.avatar_id
    if profile_in.college is not None:
        profile.college = profile_in.college
    if profile_in.course is not None:
        profile.course = profile_in.course
    if profile_in.semester is not None:
        profile.semester = profile_in.semester
    if profile_in.preferred_language is not None:
        profile.preferred_language = profile_in.preferred_language
    if profile_in.availability is not None:
        profile.availability = profile_in.availability
    if profile_in.bio is not None:
        profile.bio = profile_in.bio
    if profile_in.documents_privacy is not None:
        profile.documents_privacy = profile_in.documents_privacy

    db.commit()
    db.refresh(profile)
    return {"message": "Profile updated successfully"}

@router.get("/{user_id}", response_model=StudentProfileOut)
def get_user_profile(
    user_id: int,
    current_user: User = Depends(get_current_user_optional),
    db: Session = Depends(get_db)
):
    target_user = db.query(User).filter(User.id == user_id, User.is_active == True).first()
    if not target_user or not target_user.profile:
        raise HTTPException(status_code=404, detail="Student profile not found")

    profile = target_user.profile

    # Determine connection status with viewer
    conn_status = "none"
    if current_user:
        if current_user.id == target_user.id:
            conn_status = "self"
        else:
            conn = db.query(ConnectionRequest).filter(
                ((ConnectionRequest.sender_id == current_user.id) & (ConnectionRequest.receiver_id == target_user.id)) |
                ((ConnectionRequest.sender_id == target_user.id) & (ConnectionRequest.receiver_id == current_user.id))
            ).first()
            if conn:
                if conn.status == "accepted":
                    conn_status = "accepted"
                elif conn.status == "pending":
                    conn_status = "pending_sent" if conn.sender_id == current_user.id else "pending_received"
                elif conn.status == "rejected":
                    conn_status = "rejected"

    # Respect privacy rules
    # If documents_privacy is 'connections_only' and not accepted connection (and not self), hide documents
    can_view_documents = (
        conn_status in ["self", "accepted"] or
        profile.documents_privacy == "public"
    )

    portfolio_out = []
    if can_view_documents and profile.documents_privacy != "private":
        for p in target_user.portfolio_items:
            portfolio_out.append({
                "id": p.id,
                "user_id": p.user_id,
                "subject_id": p.subject_id,
                "item_type": p.item_type,
                "title": p.title,
                "issuing_organization": p.issuing_organization,
                "file_path": p.file_path,
                "original_filename": p.original_filename,
                "file_type": p.file_type,
                "file_size": p.file_size,
                "github_url": p.github_url,
                "live_url": p.live_url,
                "description": p.description,
                "verification_status": p.verification_status,
                "created_at": p.created_at
            })

    skills_out = []
    for s in target_user.skills_taught:
        skills_out.append(StudentSkillOut(
            id=s.id,
            subject_id=s.subject_id,
            subject_name=s.subject.name if s.subject else "Unknown",
            category=s.subject.category if s.subject else "General",
            proficiency_level=s.proficiency_level,
            experience_note=s.experience_note,
            verification_status=s.verification_status,
            assessment_score=s.assessment_score
        ))

    goals_out = []
    for g in target_user.learning_goals:
        goals_out.append(LearningGoalOut(
            id=g.id,
            subject_id=g.subject_id,
            subject_name=g.subject.name if g.subject else "Unknown",
            category=g.subject.category if g.subject else "General",
            urgency=g.urgency,
            preferred_pace=g.preferred_pace,
            current_understanding=g.current_understanding
        ))

    reviews_out = []
    reviews = db.query(SessionReview).filter(SessionReview.reviewee_id == target_user.id).order_by(SessionReview.created_at.desc()).all()
    for r in reviews:
        reviewer_name = r.reviewer.full_name if r.reviewer else "Peer Student"
        reviewer_avatar = r.reviewer.profile.avatar_id if r.reviewer and r.reviewer.profile else "avatar-owl"
        reviews_out.append({
            "id": r.id,
            "session_id": r.session_id,
            "reviewer_id": r.reviewer_id,
            "reviewer_name": reviewer_name,
            "reviewer_avatar": reviewer_avatar,
            "rating": r.rating,
            "teaching_clarity": r.teaching_clarity,
            "helpfulness": r.helpfulness,
            "punctuality": r.punctuality,
            "feedback": r.feedback,
            "created_at": r.created_at
        })

    return StudentProfileOut(
        user_id=target_user.id,
        full_name=target_user.full_name,
        email=target_user.email if can_view_documents else "hidden@skillbloom.edu",
        avatar_id=profile.avatar_id,
        college=profile.college,
        course=profile.course,
        semester=profile.semester,
        preferred_language=profile.preferred_language,
        availability=profile.availability,
        bio=profile.bio,
        rating_avg=profile.rating_avg,
        total_reviews=profile.total_reviews,
        completed_sessions_count=profile.completed_sessions_count,
        documents_privacy=profile.documents_privacy,
        skills_taught=skills_out,
        learning_goals=goals_out,
        portfolio_items=portfolio_out,
        badges=target_user.badges,
        reviews=reviews_out,
        connection_status_with_viewer=conn_status
    )

@router.post("/skills", response_model=StudentSkillOut)
def add_teaching_skill(
    skill_in: StudentSkillCreate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    subject = db.query(Subject).filter(Subject.id == skill_in.subject_id).first()
    if not subject:
        raise HTTPException(status_code=404, detail="Subject not found")

    # Check if user already teaches this
    existing = db.query(StudentSkill).filter(
        StudentSkill.user_id == current_user.id,
        StudentSkill.subject_id == skill_in.subject_id
    ).first()
    if existing:
        existing.proficiency_level = skill_in.proficiency_level
        existing.experience_note = skill_in.experience_note
        db.commit()
        db.refresh(existing)
        return StudentSkillOut(
            id=existing.id,
            subject_id=existing.subject_id,
            subject_name=subject.name,
            category=subject.category,
            proficiency_level=existing.proficiency_level,
            experience_note=existing.experience_note,
            verification_status=existing.verification_status,
            assessment_score=existing.assessment_score
        )

    new_skill = StudentSkill(
        user_id=current_user.id,
        subject_id=skill_in.subject_id,
        proficiency_level=skill_in.proficiency_level,
        experience_note=skill_in.experience_note,
        verification_status="Unverified"
    )
    db.add(new_skill)
    db.commit()
    db.refresh(new_skill)

    return StudentSkillOut(
        id=new_skill.id,
        subject_id=new_skill.subject_id,
        subject_name=subject.name,
        category=subject.category,
        proficiency_level=new_skill.proficiency_level,
        experience_note=new_skill.experience_note,
        verification_status=new_skill.verification_status,
        assessment_score=new_skill.assessment_score
    )

@router.delete("/skills/{skill_id}")
def delete_teaching_skill(
    skill_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    skill = db.query(StudentSkill).filter(
        StudentSkill.id == skill_id,
        StudentSkill.user_id == current_user.id
    ).first()
    if not skill:
        raise HTTPException(status_code=404, detail="Skill not found")
    db.delete(skill)
    db.commit()
    return {"message": "Skill removed successfully"}

@router.post("/learning-goals", response_model=LearningGoalOut)
def add_learning_goal(
    goal_in: LearningGoalCreate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    subject = db.query(Subject).filter(Subject.id == goal_in.subject_id).first()
    if not subject:
        raise HTTPException(status_code=404, detail="Subject not found")

    existing = db.query(LearningGoal).filter(
        LearningGoal.user_id == current_user.id,
        LearningGoal.subject_id == goal_in.subject_id
    ).first()
    if existing:
        existing.urgency = goal_in.urgency or "Normal"
        existing.preferred_pace = goal_in.preferred_pace or "Regular"
        existing.current_understanding = goal_in.current_understanding or "Beginner"
        db.commit()
        db.refresh(existing)
        return LearningGoalOut(
            id=existing.id,
            subject_id=existing.subject_id,
            subject_name=subject.name,
            category=subject.category,
            urgency=existing.urgency,
            preferred_pace=existing.preferred_pace,
            current_understanding=existing.current_understanding
        )

    new_goal = LearningGoal(
        user_id=current_user.id,
        subject_id=goal_in.subject_id,
        urgency=goal_in.urgency or "Normal",
        preferred_pace=goal_in.preferred_pace or "Regular",
        current_understanding=goal_in.current_understanding or "Beginner"
    )
    db.add(new_goal)
    db.commit()
    db.refresh(new_goal)

    return LearningGoalOut(
        id=new_goal.id,
        subject_id=new_goal.subject_id,
        subject_name=subject.name,
        category=subject.category,
        urgency=new_goal.urgency,
        preferred_pace=new_goal.preferred_pace,
        current_understanding=new_goal.current_understanding
    )

@router.delete("/learning-goals/{goal_id}")
def delete_learning_goal(
    goal_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    goal = db.query(LearningGoal).filter(
        LearningGoal.id == goal_id,
        LearningGoal.user_id == current_user.id
    ).first()
    if not goal:
        raise HTTPException(status_code=404, detail="Learning goal not found")
    db.delete(goal)
    db.commit()
    return {"message": "Learning goal removed successfully"}
