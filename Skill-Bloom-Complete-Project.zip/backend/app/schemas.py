from typing import Optional, List
from datetime import datetime
from pydantic import BaseModel, EmailStr, Field

# Auth schemas
class UserRegister(BaseModel):
    email: EmailStr
    password: str = Field(..., min_length=6)
    full_name: str = Field(..., min_length=2)
    college: str
    course: str
    semester: int = Field(..., ge=1, le=10)
    preferred_language: str
    avatar_id: Optional[str] = "avatar-owl"

class UserLogin(BaseModel):
    email: EmailStr
    password: str

class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user_id: int
    full_name: str
    email: str

# Avatar schema
class AvatarInfo(BaseModel):
    id: str
    label: str
    emoji: str
    bg_gradient: str

# Subject schemas
class SubjectBase(BaseModel):
    name: str
    code: Optional[str] = None
    category: str
    semester_recommended: Optional[int] = 3
    description: Optional[str] = None

class SubjectCreate(SubjectBase):
    pass

class SubjectOut(SubjectBase):
    id: int
    is_custom: bool
    created_by_user_id: Optional[int] = None
    teachers_count: Optional[int] = 0
    learners_count: Optional[int] = 0

    class Config:
        from_attributes = True

# Student Skill schemas (teaching)
class StudentSkillCreate(BaseModel):
    subject_id: int
    proficiency_level: str # Beginner, Intermediate, Advanced
    experience_note: Optional[str] = None

class StudentSkillOut(BaseModel):
    id: int
    subject_id: int
    subject_name: Optional[str] = None
    category: Optional[str] = None
    proficiency_level: str
    experience_note: Optional[str] = None
    verification_status: str
    assessment_score: Optional[int] = None

    class Config:
        from_attributes = True

# Learning Goal schemas (learning)
class LearningGoalCreate(BaseModel):
    subject_id: int
    urgency: Optional[str] = "Normal" # Normal, Exam Preparation, Project Deadline
    preferred_pace: Optional[str] = "Regular"
    current_understanding: Optional[str] = "Beginner"

class LearningGoalOut(BaseModel):
    id: int
    subject_id: int
    subject_name: Optional[str] = None
    category: Optional[str] = None
    urgency: str
    preferred_pace: str
    current_understanding: str

    class Config:
        from_attributes = True

# Certificate & Project schemas
class CertificateProjectCreate(BaseModel):
    item_type: str # certificate, project
    title: str
    issuing_organization: Optional[str] = None
    subject_id: Optional[int] = None
    github_url: Optional[str] = None
    live_url: Optional[str] = None
    description: Optional[str] = None

class CertificateProjectOut(BaseModel):
    id: int
    user_id: int
    subject_id: Optional[int] = None
    subject_name: Optional[str] = None
    item_type: str
    title: str
    issuing_organization: Optional[str] = None
    file_path: Optional[str] = None
    original_filename: Optional[str] = None
    file_type: Optional[str] = None
    file_size: Optional[int] = None
    github_url: Optional[str] = None
    live_url: Optional[str] = None
    description: Optional[str] = None
    verification_status: str
    created_at: datetime

    class Config:
        from_attributes = True

# Profile schemas
class StudentProfileUpdate(BaseModel):
    avatar_id: Optional[str] = None
    college: Optional[str] = None
    course: Optional[str] = None
    semester: Optional[int] = None
    preferred_language: Optional[str] = None
    availability: Optional[str] = None
    bio: Optional[str] = None
    documents_privacy: Optional[str] = None # connections_only, public, private

class BadgeOut(BaseModel):
    id: int
    badge_code: str
    badge_title: str
    badge_icon: str
    description: Optional[str] = None
    awarded_at: datetime

    class Config:
        from_attributes = True

class SessionReviewOut(BaseModel):
    id: int
    session_id: int
    reviewer_id: int
    reviewer_name: Optional[str] = None
    reviewer_avatar: Optional[str] = None
    rating: float
    teaching_clarity: int
    helpfulness: int
    punctuality: int
    feedback: str
    created_at: datetime

    class Config:
        from_attributes = True

class StudentProfileOut(BaseModel):
    user_id: int
    full_name: str
    email: str
    avatar_id: str
    college: str
    course: str
    semester: int
    preferred_language: str
    availability: str
    bio: str
    rating_avg: float
    total_reviews: int
    completed_sessions_count: int
    documents_privacy: str
    skills_taught: List[StudentSkillOut] = []
    learning_goals: List[LearningGoalOut] = []
    portfolio_items: List[CertificateProjectOut] = []
    badges: List[BadgeOut] = []
    reviews: List[SessionReviewOut] = []
    connection_status_with_viewer: Optional[str] = None # none, pending, accepted, rejected, blocked

    class Config:
        from_attributes = True

# Matching and Ranking schemas
class ScoreBreakdown(BaseModel):
    proficiency_points: float
    verification_points: float
    feedback_points: float
    sessions_points: float
    language_match_points: float
    availability_match_points: float
    college_proximity_points: float
    total_raw_score: float

class MatchedStudentOut(BaseModel):
    rank: int
    user_id: int
    full_name: str
    avatar_id: str
    college: str
    course: str
    semester: int
    preferred_language: str
    availability: str
    subject_proficiency: str
    verification_status: str
    assessment_score: Optional[int] = None
    rating_avg: float
    total_reviews: int
    completed_sessions_count: int
    estimated_match_percentage: int # Clearly labelled as estimated compatibility score
    score_breakdown: ScoreBreakdown
    connection_status: str # none, pending_sent, pending_received, accepted, rejected
    portfolio_preview_count: int

# Connection schemas
class ConnectionRequestCreate(BaseModel):
    receiver_id: int
    message: Optional[str] = "Hi! I would like to connect and learn together on Skill Bloom."

class ConnectionRequestOut(BaseModel):
    id: int
    sender_id: int
    sender_name: str
    sender_avatar: str
    sender_college: str
    sender_course: str
    receiver_id: int
    receiver_name: str
    receiver_avatar: str
    status: str
    message: Optional[str]
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True

# Chat & Message schemas
class MessageCreate(BaseModel):
    receiver_id: int
    content: str

class MessageOut(BaseModel):
    id: int
    conversation_id: int
    sender_id: int
    sender_name: Optional[str] = None
    sender_avatar: Optional[str] = None
    content: str
    is_read: bool
    read_at: Optional[datetime] = None
    created_at: datetime

    class Config:
        from_attributes = True

class ConversationSummary(BaseModel):
    id: int
    peer_user_id: int
    peer_name: str
    peer_avatar: str
    peer_college: str
    peer_course: str
    last_message: Optional[str] = None
    last_message_time: Optional[datetime] = None
    unread_count: int = 0

# Learning Session schemas
class LearningSessionCreate(BaseModel):
    peer_id: int # Connected student to have session with
    as_teacher: bool = True # True if creator is teaching, False if creator is learning
    subject_id: int
    title: str
    description: Optional[str] = None
    scheduled_time: datetime
    duration_minutes: Optional[int] = 60

class LearningSessionOut(BaseModel):
    id: int
    host_id: int
    host_name: str
    host_avatar: str
    learner_id: int
    learner_name: str
    learner_avatar: str
    subject_id: int
    subject_name: str
    title: str
    description: Optional[str] = None
    scheduled_time: datetime
    duration_minutes: int
    status: str # scheduled, completed, cancelled
    meeting_room_id: str
    meeting_notes: Optional[str] = None
    is_host: bool = False
    has_reviewed: bool = False
    created_at: datetime

    class Config:
        from_attributes = True

class SessionReviewCreate(BaseModel):
    session_id: int
    rating: float = Field(..., ge=1, le=5)
    teaching_clarity: int = Field(5, ge=1, le=5)
    helpfulness: int = Field(5, ge=1, le=5)
    punctuality: int = Field(5, ge=1, le=5)
    feedback: str = Field(..., min_length=5)

# Notification schemas
class NotificationOut(BaseModel):
    id: int
    type: str
    title: str
    content: str
    link: Optional[str] = None
    is_read: bool
    created_at: datetime

    class Config:
        from_attributes = True

# Block / Report schema
class BlockReportCreate(BaseModel):
    target_id: int
    action: str # block, report
    reason: Optional[str] = None
