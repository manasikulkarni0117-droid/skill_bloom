import datetime
from sqlalchemy.orm import Session
from app.models import (
    User, StudentProfile, Subject, StudentSkill, LearningGoal,
    CertificateProject, SessionReview, LearningSession,
    ConnectionRequest, Conversation, Message, Notification, Badge
)
from app.auth import get_password_hash

SUBJECTS_DATA = [
    {"name": "Data Structures & Algorithms", "code": "CS201", "category": "Computer Science", "semester_recommended": 3, "description": "Arrays, Trees, Graphs, Sorting, Dynamic Programming, and algorithmic analysis."},
    {"name": "Python Programming", "code": "CS102", "category": "Computer Science", "semester_recommended": 2, "description": "Python core syntax, OOP, modules, pandas, and practical project development."},
    {"name": "Java Object-Oriented Programming", "code": "CS202", "category": "Computer Science", "semester_recommended": 3, "description": "Core Java, classes, inheritance, interfaces, exception handling, and collections."},
    {"name": "C & C++ Fundamentals", "code": "CS101", "category": "Computer Science", "semester_recommended": 1, "description": "Pointers, memory management, low-level architecture, and standard template library."},
    {"name": "Database Management Systems (DBMS)", "code": "CS301", "category": "Computer Science", "semester_recommended": 4, "description": "Relational models, SQL, normalization, transactions, ACID, indexing, and NoSQL."},
    {"name": "Operating Systems", "code": "CS302", "category": "Computer Science", "semester_recommended": 4, "description": "Process management, CPU scheduling, concurrency, virtual memory, and file systems."},
    {"name": "Computer Networks", "code": "CS401", "category": "Computer Science", "semester_recommended": 5, "description": "OSI & TCP/IP stack, routing protocols, sockets, DNS, and transport layer reliability."},
    {"name": "Web Development & React", "code": "CS305", "category": "Computer Science", "semester_recommended": 4, "description": "Modern frontend, HTML/CSS, JavaScript ES6+, React components, and REST integration."},
    {"name": "Software Engineering & Agile", "code": "CS402", "category": "Computer Science", "semester_recommended": 5, "description": "SDLC, Scrum practices, architecture patterns, testing, and Git version control."},
    {"name": "Linear Algebra & Discrete Math", "code": "MA201", "category": "Mathematics", "semester_recommended": 2, "description": "Matrices, eigenvalues, graph theory, propositional logic, and combinatorics."},
    {"name": "Calculus & Numerical Methods", "code": "MA101", "category": "Mathematics", "semester_recommended": 1, "description": "Differential and integral calculus, Taylor series, and numerical approximations."},
    {"name": "Probability & Statistics", "code": "MA301", "category": "Mathematics", "semester_recommended": 3, "description": "Random variables, hypothesis testing, Bayes theorem, and statistical models."},
    {"name": "Engineering Physics", "code": "PH101", "category": "Physics & Engineering", "semester_recommended": 1, "description": "Wave mechanics, quantum fundamentals, optics, and solid-state physics."},
    {"name": "Digital Logic & Microprocessors", "code": "EC201", "category": "Physics & Engineering", "semester_recommended": 3, "description": "Logic gates, flip-flops, Karnaugh maps, assembly instructions, and 8086 microprocessors."},
    {"name": "Technical Communication & English", "code": "HU101", "category": "Humanities & Skills", "semester_recommended": 1, "description": "Technical writing, presentations, interview readiness, and college academic communication."}
]

def seed_database(db: Session):
    # Check if database is already seeded
    if db.query(User).count() > 0:
        return

    print("Seeding Skill Bloom database with initial college data...")

    # 1. Insert Subjects
    subject_map = {}
    for s_info in SUBJECTS_DATA:
        subj = Subject(
            name=s_info["name"],
            code=s_info["code"],
            category=s_info["category"],
            semester_recommended=s_info["semester_recommended"],
            description=s_info["description"],
            is_custom=False
        )
        db.add(subj)
        db.flush()
        subject_map[subj.name] = subj

    # 2. Demo Users
    STUDENTS = [
        {
            "email": "test@demo.edu",
            "full_name": "Dev Test Student",
            "avatar_id": "avatar-owl",
            "college": "State Institute of Technology",
            "course": "B.Tech Computer Science",
            "semester": 4,
            "preferred_language": "English",
            "availability": "Weekday evenings (6 - 9 PM), Weekend afternoons",
            "bio": "Hi! I am testing Skill Bloom. Looking to master DSA and Web Dev while helping peers with Java.",
            "rating_avg": 5.0,
            "total_reviews": 0,
            "completed_sessions_count": 0,
            "privacy": "connections_only",
            "skills": [
                {"subj": "Java Object-Oriented Programming", "prof": "Intermediate", "note": "Comfortable with OOP principles and collections.", "verif": "Certificate Uploaded", "score": None}
            ],
            "goals": [
                {"subj": "Data Structures & Algorithms", "urgency": "Exam Preparation", "pace": "Fast", "understanding": "Intermediate"},
                {"subj": "Web Development & React", "urgency": "Project Deadline", "pace": "Regular", "understanding": "Beginner"}
            ]
        },
        {
            "email": "aarav@demo.edu",
            "full_name": "Aarav Sharma",
            "avatar_id": "avatar-coder",
            "college": "State Institute of Technology",
            "course": "B.Tech Computer Science",
            "semester": 6,
            "preferred_language": "English",
            "availability": "Mon/Wed/Fri 6-9 PM, Saturday all day",
            "bio": "Competitive programmer & TA. Solved 450+ LeetCode problems. Love teaching Trees & Dynamic Programming.",
            "rating_avg": 4.9,
            "total_reviews": 12,
            "completed_sessions_count": 14,
            "privacy": "connections_only",
            "skills": [
                {"subj": "Data Structures & Algorithms", "prof": "Advanced", "note": "Top 5% in college coding contest. Clear visual explanations.", "verif": "Institution Verified", "score": 96},
                {"subj": "Python Programming", "prof": "Advanced", "note": "3 years building data pipelines and backend apps.", "verif": "Assessment Passed", "score": 92},
                {"subj": "C & C++ Fundamentals", "prof": "Advanced", "note": "Strong pointer arithmetic and memory optimization.", "verif": "Assessment Passed", "score": 89}
            ],
            "goals": [
                {"subj": "Operating Systems", "urgency": "Normal", "pace": "Regular", "understanding": "Intermediate"}
            ]
        },
        {
            "email": "priya@demo.edu",
            "full_name": "Priya Patel",
            "avatar_id": "avatar-wizard",
            "college": "State Institute of Technology",
            "course": "B.Tech Data Science",
            "semester": 6,
            "preferred_language": "English",
            "availability": "Weekday evenings (7 - 10 PM), Sunday mornings",
            "bio": "Math enthusiast and database designer. I simplify complex linear algebra and SQL queries with real-world examples.",
            "rating_avg": 5.0,
            "total_reviews": 10,
            "completed_sessions_count": 12,
            "privacy": "connections_only",
            "skills": [
                {"subj": "Linear Algebra & Discrete Math", "prof": "Advanced", "note": "Department topper in Engineering Mathematics.", "verif": "Institution Verified", "score": 98},
                {"subj": "Database Management Systems (DBMS)", "prof": "Advanced", "note": "Built production SQL schemas and normalization guides.", "verif": "Assessment Passed", "score": 94},
                {"subj": "Probability & Statistics", "prof": "Advanced", "note": "Specialized in Bayesian inference and distributions.", "verif": "Project Reviewed", "score": 90}
            ],
            "goals": [
                {"subj": "Computer Networks", "urgency": "Normal", "pace": "Regular", "understanding": "Beginner"}
            ]
        },
        {
            "email": "rohan@demo.edu",
            "full_name": "Rohan Verma",
            "avatar_id": "avatar-astronaut",
            "college": "Delhi Technological University",
            "course": "B.Tech Software Engineering",
            "semester": 4,
            "preferred_language": "English",
            "availability": "Tuesday & Thursday 5-8 PM, Weekends",
            "bio": "Full-stack developer who loves building web applications. Let's build full projects from scratch!",
            "rating_avg": 4.85,
            "total_reviews": 8,
            "completed_sessions_count": 9,
            "privacy": "public",
            "skills": [
                {"subj": "Web Development & React", "prof": "Advanced", "note": "Built 10+ web apps in React, Tailwind, and Node.js.", "verif": "Project Reviewed", "score": 92},
                {"subj": "Software Engineering & Agile", "prof": "Intermediate", "note": "Led team capstone project with Agile sprints.", "verif": "Certificate Uploaded", "score": None}
            ],
            "goals": [
                {"subj": "Data Structures & Algorithms", "urgency": "Exam Preparation", "pace": "Fast", "understanding": "Intermediate"}
            ]
        },
        {
            "email": "ananya@demo.edu",
            "full_name": "Ananya Gupta",
            "avatar_id": "avatar-fox",
            "college": "National Institute of Technology",
            "course": "B.Tech Electronics & Comm",
            "semester": 5,
            "preferred_language": "English",
            "availability": "Mon to Fri 7 - 9:30 PM",
            "bio": "Passionate about Operating Systems, Networks, and low-level computer architecture.",
            "rating_avg": 4.95,
            "total_reviews": 14,
            "completed_sessions_count": 16,
            "privacy": "connections_only",
            "skills": [
                {"subj": "Operating Systems", "prof": "Advanced", "note": "Deep understanding of synchronization, deadlocks, and paging.", "verif": "Institution Verified", "score": 95},
                {"subj": "Computer Networks", "prof": "Advanced", "note": "Packet sniffing, socket programming, and TCP flow control.", "verif": "Assessment Passed", "score": 93},
                {"subj": "Digital Logic & Microprocessors", "prof": "Intermediate", "note": "Circuit simulation and breadboard projects.", "verif": "Certificate Uploaded", "score": None}
            ],
            "goals": [
                {"subj": "Web Development & React", "urgency": "Normal", "pace": "Regular", "understanding": "Beginner"}
            ]
        },
        {
            "email": "kabir@demo.edu",
            "full_name": "Kabir Mehta",
            "avatar_id": "avatar-robot",
            "college": "Birla Institute of Technology",
            "course": "BCA Computer Applications",
            "semester": 3,
            "preferred_language": "English",
            "availability": "Flexible on Weekends",
            "bio": "C language specialist and passionate peer helper. Happy to debug code together!",
            "rating_avg": 4.75,
            "total_reviews": 6,
            "completed_sessions_count": 7,
            "privacy": "connections_only",
            "skills": [
                {"subj": "C & C++ Fundamentals", "prof": "Intermediate", "note": "Helped 15+ juniors pass their lab practicals.", "verif": "Certificate Uploaded", "score": 85},
                {"subj": "Technical Communication & English", "prof": "Advanced", "note": "College debate president. Can help polish tech talks.", "verif": "Institution Verified", "score": 97}
            ],
            "goals": [
                {"subj": "Java Object-Oriented Programming", "urgency": "Exam Preparation", "pace": "Regular", "understanding": "Beginner"}
            ]
        }
    ]

    created_users = {}
    for st in STUDENTS:
        u = User(
            email=st["email"],
            password_hash=get_password_hash("password123"),
            full_name=st["full_name"]
        )
        db.add(u)
        db.flush()

        profile = StudentProfile(
            user_id=u.id,
            avatar_id=st["avatar_id"],
            college=st["college"],
            course=st["course"],
            semester=st["semester"],
            preferred_language=st["preferred_language"],
            availability=st["availability"],
            bio=st["bio"],
            rating_avg=st["rating_avg"],
            total_reviews=st["total_reviews"],
            completed_sessions_count=st["completed_sessions_count"],
            documents_privacy=st["privacy"]
        )
        db.add(profile)

        # Add Skills
        for sk in st["skills"]:
            subj_obj = subject_map.get(sk["subj"])
            if subj_obj:
                skill_obj = StudentSkill(
                    user_id=u.id,
                    subject_id=subj_obj.id,
                    proficiency_level=sk["prof"],
                    experience_note=sk["note"],
                    verification_status=sk["verif"],
                    assessment_score=sk["score"]
                )
                db.add(skill_obj)

        # Add Goals
        for g in st["goals"]:
            subj_obj = subject_map.get(g["subj"])
            if subj_obj:
                goal_obj = LearningGoal(
                    user_id=u.id,
                    subject_id=subj_obj.id,
                    urgency=g["urgency"],
                    preferred_pace=g["pace"],
                    current_understanding=g["understanding"]
                )
                db.add(goal_obj)

        # Add badges
        db.add(Badge(
            user_id=u.id,
            badge_code="welcome_peer",
            badge_title="Welcome to Skill Bloom",
            badge_icon="🌱",
            description="Joined the peer learning network."
        ))

        if st["completed_sessions_count"] > 0:
            db.add(Badge(
                user_id=u.id,
                badge_code="first_bloom",
                badge_title="First Bloom 🌸",
                badge_icon="🌸",
                description="Completed first peer learning session"
            ))
        if st["completed_sessions_count"] >= 5:
            db.add(Badge(
                user_id=u.id,
                badge_code="helpful_peer",
                badge_title="Helpful Peer 🌟",
                badge_icon="🌟",
                description="Conducted over 5 successful peer mentoring sessions"
            ))

        created_users[st["email"]] = u

    # 3. Add Portfolio items for Aarav, Priya, Rohan
    aarav = created_users["aarav@demo.edu"]
    dsa_subj = subject_map.get("Data Structures & Algorithms")
    db.add(CertificateProject(
        user_id=aarav.id,
        subject_id=dsa_subj.id if dsa_subj else None,
        item_type="certificate",
        title="NPTEL Advanced Algorithms & Data Structures - Elite Gold",
        issuing_organization="IIT Kharagpur / NPTEL",
        description="Scored 94% in 12-week rigorous national assessment on graph theory and algorithmic optimization.",
        verification_status="Institution Verified"
    ))
    db.add(CertificateProject(
        user_id=aarav.id,
        subject_id=dsa_subj.id if dsa_subj else None,
        item_type="project",
        title="Visual Algorithm Workbench",
        issuing_organization="Self-directed capstone",
        github_url="https://github.com/demo/algorithm-workbench",
        live_url="https://algo-workbench.demo.edu",
        description="Interactive visualizer for Dijkstra, AVL rotations, and dynamic programming state transitions.",
        verification_status="Project Reviewed"
    ))

    priya = created_users["priya@demo.edu"]
    dbms_subj = subject_map.get("Database Management Systems (DBMS)")
    db.add(CertificateProject(
        user_id=priya.id,
        subject_id=dbms_subj.id if dbms_subj else None,
        item_type="certificate",
        title="Database Systems Specialization Certificate",
        issuing_organization="Coursera / Stanford Online",
        description="Comprehensive study of ACID guarantees, query plans, B+ Trees, and transactions.",
        verification_status="Certificate Uploaded"
    ))

    rohan = created_users["rohan@demo.edu"]
    web_subj = subject_map.get("Web Development & React")
    db.add(CertificateProject(
        user_id=rohan.id,
        subject_id=web_subj.id if web_subj else None,
        item_type="project",
        title="Campus Event Tracker & Ticket Exchange",
        issuing_organization="College Tech Fest",
        github_url="https://github.com/demo/campus-tickets",
        live_url="https://campustickets.demo.edu",
        description="React and Tailwind web application used by 1200+ students during technical fest.",
        verification_status="Project Reviewed"
    ))

    # 4. Pre-establish connections and sample sessions for test user to see rich dashboard immediately
    test_u = created_users["test@demo.edu"]
    
    # Connect test_u with Aarav (Accepted)
    conn1 = ConnectionRequest(
        sender_id=aarav.id,
        receiver_id=test_u.id,
        status="accepted",
        message="Hey! Glad to connect. I saw you want to prepare for DSA exams."
    )
    db.add(conn1)

    # Conversation between test_u and Aarav
    conv1 = Conversation(user1_id=test_u.id, user2_id=aarav.id)
    db.add(conv1)
    db.flush()

    db.add(Message(
        conversation_id=conv1.id,
        sender_id=aarav.id,
        content="Hey! Welcome to Skill Bloom. Whenever you're ready, let me know which DSA topics you'd like to tackle first.",
        is_read=True
    ))
    db.add(Message(
        conversation_id=conv1.id,
        sender_id=test_u.id,
        content="Hi Aarav! Thanks for connecting. I'm struggling with Binary Search Trees and Graph Traversals.",
        is_read=True
    ))
    db.add(Message(
        conversation_id=conv1.id,
        sender_id=aarav.id,
        content="BSTs are actually very intuitive once you visualize the recursion tree! I've scheduled our practice session.",
        is_read=False
    ))

    # Incoming pending request from Priya
    conn2 = ConnectionRequest(
        sender_id=priya.id,
        receiver_id=test_u.id,
        status="pending",
        message="Hello! I can help you with Discrete Math or DBMS, and I'd love to learn from your Java experience."
    )
    db.add(conn2)

    # Outgoing pending request to Rohan
    conn3 = ConnectionRequest(
        sender_id=test_u.id,
        receiver_id=rohan.id,
        status="pending",
        message="Hi Rohan! I loved your campus web app project and would love to connect for React mentoring."
    )
    db.add(conn3)

    # Scheduled session between test_u and Aarav
    now = datetime.datetime.utcnow()
    sched_time = now + datetime.timedelta(days=1, hours=4)
    session1 = LearningSession(
        host_id=aarav.id,
        learner_id=test_u.id,
        subject_id=dsa_subj.id if dsa_subj else 1,
        title="Mastering Binary Search Trees & DFS",
        description="Visual walkthrough of BST insertions, deletions, in-order predecessor logic, and practice interview problems.",
        scheduled_time=sched_time,
        duration_minutes=60,
        status="scheduled",
        meeting_room_id="sb-dsa-demo-room"
    )
    db.add(session1)

    # Completed session with review
    past_time = now - datetime.timedelta(days=3)
    session2 = LearningSession(
        host_id=aarav.id,
        learner_id=test_u.id,
        subject_id=dsa_subj.id if dsa_subj else 1,
        title="Time & Space Complexity Fundamentals",
        description="Big-O notation, master theorem, and identifying complexity in nested loops.",
        scheduled_time=past_time,
        duration_minutes=45,
        status="completed",
        meeting_room_id="sb-complexity-room"
    )
    db.add(session2)
    db.flush()

    # Review by test_u for Aarav
    db.add(SessionReview(
        session_id=session2.id,
        reviewer_id=test_u.id,
        reviewee_id=aarav.id,
        rating=5.0,
        teaching_clarity=5,
        helpfulness=5,
        punctuality=5,
        feedback="Aarav is an incredible peer mentor! He broke down recursive tree heights so simply. Highly recommend him for DSA!"
    ))

    # Reviews for Priya from other students
    db.add(SessionReview(
        session_id=session2.id, # reference
        reviewer_id=rohan.id,
        reviewee_id=priya.id,
        rating=5.0,
        teaching_clarity=5,
        helpfulness=5,
        punctuality=5,
        feedback="Priya explained SQL 3rd Normal Form and indexing without any jargon. Saved my semester exam!"
    ))

    # Notification for test_u
    db.add(Notification(
        user_id=test_u.id,
        type="connection_request",
        title="Connection Request from Priya Patel",
        content="Priya Patel sent you a connection request. Check out her math and DBMS mentoring profile!",
        link="/connections"
    ))
    db.add(Notification(
        user_id=test_u.id,
        type="session_scheduled",
        title="Upcoming Session Tomorrow",
        content="Session 'Mastering Binary Search Trees & DFS' with Aarav Sharma is scheduled.",
        link="/sessions"
    ))

    db.commit()
    print("Database seeding completed successfully.")
