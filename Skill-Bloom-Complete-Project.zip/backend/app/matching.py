from typing import List, Optional
from sqlalchemy.orm import Session
from app.models import User, StudentProfile, StudentSkill, Subject, ConnectionRequest, UserBlockReport
from app.schemas import MatchedStudentOut, ScoreBreakdown

def compute_student_match_score(
    teacher_profile: StudentProfile,
    teacher_skill: StudentSkill,
    learner_profile: Optional[StudentProfile]
) -> tuple[float, ScoreBreakdown]:
    """
    Transparent, modular rule-based matching algorithm that estimates
    compatibility between a peer mentor/teacher and the learning student.
    Returns (match_percentage, score_breakdown).
    """
    # 1. Subject proficiency (max 30)
    prof_map = {
        "Advanced": 30.0,
        "Intermediate": 20.0,
        "Beginner": 10.0
    }
    prof_points = prof_map.get(teacher_skill.proficiency_level, 15.0)

    # 2. Verification and Skill Evidence (max 25)
    verif_map = {
        "Institution Verified": 25.0,
        "Assessment Passed": 20.0,
        "Project Reviewed": 16.0,
        "Certificate Uploaded": 10.0,
        "Unverified": 4.0
    }
    verif_points = verif_map.get(teacher_skill.verification_status, 4.0)
    if teacher_skill.assessment_score and teacher_skill.assessment_score > 0:
        bonus = min(5.0, (teacher_skill.assessment_score / 100.0) * 5.0)
        verif_points = min(25.0, verif_points + bonus)

    # 3. Teaching feedback (max 15)
    if teacher_profile.total_reviews > 0:
        feedback_points = min(15.0, (teacher_profile.rating_avg / 5.0) * 15.0)
    else:
        feedback_points = 10.0  # Fair baseline for newly registered peer mentors

    # 4. Completed sessions experience (max 10)
    sessions_points = min(10.0, float(teacher_profile.completed_sessions_count) * 2.0)

    # 5. Language compatibility (max 10)
    language_points = 5.0
    if learner_profile and learner_profile.preferred_language and teacher_profile.preferred_language:
        if learner_profile.preferred_language.strip().lower() == teacher_profile.preferred_language.strip().lower():
            language_points = 10.0
        elif "english" in learner_profile.preferred_language.lower() or "english" in teacher_profile.preferred_language.lower():
            language_points = 7.0

    # 6. Availability compatibility (max 5)
    availability_points = 3.0
    if learner_profile and learner_profile.availability and teacher_profile.availability:
        l_avail = learner_profile.availability.lower()
        t_avail = teacher_profile.availability.lower()
        shared_keywords = ["evening", "weekend", "morning", "afternoon", "weekday"]
        matches = sum(1 for kw in shared_keywords if kw in l_avail and kw in t_avail)
        if matches > 0:
            availability_points = min(5.0, 3.0 + (matches * 1.0))

    # 7. College proximity bonus (max 5)
    proximity_points = 0.0
    if learner_profile and learner_profile.college and teacher_profile.college:
        if learner_profile.college.strip().lower() == teacher_profile.college.strip().lower():
            proximity_points = 5.0

    raw_total = (
        prof_points +
        verif_points +
        feedback_points +
        sessions_points +
        language_points +
        availability_points +
        proximity_points
    )

    # Normalize to 40% - 98% range for realistic compatibility estimation
    normalized_percent = int(min(98.0, max(42.0, raw_total)))

    breakdown = ScoreBreakdown(
        proficiency_points=round(prof_points, 1),
        verification_points=round(verif_points, 1),
        feedback_points=round(feedback_points, 1),
        sessions_points=round(sessions_points, 1),
        language_match_points=round(language_points, 1),
        availability_match_points=round(availability_points, 1),
        college_proximity_points=round(proximity_points, 1),
        total_raw_score=round(raw_total, 1)
    )

    return normalized_percent, breakdown


def rank_teachers_for_subject(
    db: Session,
    subject_id: int,
    learner_user: Optional[User] = None,
    proficiency_filter: Optional[str] = None,
    course_filter: Optional[str] = None,
    language_filter: Optional[str] = None,
    min_rating: Optional[float] = None,
    availability_filter: Optional[str] = None
) -> List[MatchedStudentOut]:
    """
    Finds and ranks all students who teach the specified subject,
    incorporating filters and generating transparent match scores.
    """
    learner_profile = learner_user.profile if learner_user else None
    learner_id = learner_user.id if learner_user else -1

    # Blocked list
    blocked_ids = set()
    if learner_user:
        blocks = db.query(UserBlockReport).filter(
            (UserBlockReport.reporter_id == learner_id) | (UserBlockReport.target_id == learner_id)
        ).all()
        for b in blocks:
            if b.reporter_id == learner_id:
                blocked_ids.add(b.target_id)
            if b.target_id == learner_id:
                blocked_ids.add(b.reporter_id)

    # Query student skills for this subject
    skills_query = db.query(StudentSkill).join(User).join(StudentProfile).filter(
        StudentSkill.subject_id == subject_id,
        User.id != learner_id,
        User.is_active == True
    )

    if blocked_ids:
        skills_query = skills_query.filter(~User.id.in_(blocked_ids))

    if proficiency_filter and proficiency_filter.strip():
        skills_query = skills_query.filter(StudentSkill.proficiency_level == proficiency_filter.strip())

    teacher_skills = skills_query.all()

    # Pre-fetch existing connection requests between learner and these teachers
    conn_map = {}
    if learner_user:
        conns = db.query(ConnectionRequest).filter(
            ((ConnectionRequest.sender_id == learner_id)) |
            ((ConnectionRequest.receiver_id == learner_id))
        ).all()
        for c in conns:
            other_id = c.receiver_id if c.sender_id == learner_id else c.sender_id
            if c.status == "accepted":
                conn_map[other_id] = "accepted"
            elif c.status == "pending":
                conn_map[other_id] = "pending_sent" if c.sender_id == learner_id else "pending_received"
            elif c.status == "rejected":
                conn_map[other_id] = "rejected"

    candidate_results = []
    for skill in teacher_skills:
        teacher = skill.user
        profile = teacher.profile
        if not profile:
            continue

        # Filters
        if course_filter and course_filter.strip().lower() not in profile.course.lower():
            continue
        if language_filter and language_filter.strip().lower() not in profile.preferred_language.lower():
            continue
        if min_rating and profile.rating_avg < min_rating:
            continue
        if availability_filter and availability_filter.strip().lower() not in profile.availability.lower():
            continue

        match_pct, breakdown = compute_student_match_score(profile, skill, learner_profile)
        connection_status = conn_map.get(teacher.id, "none")

        candidate_results.append({
            "user_id": teacher.id,
            "full_name": teacher.full_name,
            "avatar_id": profile.avatar_id or "avatar-owl",
            "college": profile.college,
            "course": profile.course,
            "semester": profile.semester,
            "preferred_language": profile.preferred_language,
            "availability": profile.availability,
            "subject_proficiency": skill.proficiency_level,
            "verification_status": skill.verification_status,
            "assessment_score": skill.assessment_score,
            "rating_avg": profile.rating_avg,
            "total_reviews": profile.total_reviews,
            "completed_sessions_count": profile.completed_sessions_count,
            "estimated_match_percentage": match_pct,
            "score_breakdown": breakdown,
            "connection_status": connection_status,
            "portfolio_preview_count": len(teacher.portfolio_items)
        })

    # Sort candidates by estimated_match_percentage desc, then rating_avg desc, then completed_sessions desc
    candidate_results.sort(
        key=lambda x: (x["estimated_match_percentage"], x["rating_avg"], x["completed_sessions_count"]),
        reverse=True
    )

    # Assign ranks
    final_ranked: List[MatchedStudentOut] = []
    for index, cand in enumerate(candidate_results, start=1):
        cand["rank"] = index
        final_ranked.append(MatchedStudentOut(**cand))

    return final_ranked
