from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.database import engine, Base, SessionLocal
from app.seed_data import seed_database
from app.config import ALLOWED_ORIGINS

from app.routers import (
    auth, profiles, subjects, matching,
    connections, chat, sessions, portfolio,
    notifications, websocket
)

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup: create tables and seed demo data if empty
    Base.metadata.create_all(bind=engine)
    db = SessionLocal()
    try:
        seed_database(db)
    finally:
        db.close()
    yield
    # Shutdown logic if any

app = FastAPI(
    title="Skill Bloom — Peer-to-Peer College Learning Platform API",
    description="Backend REST and WebSocket APIs for Skill Bloom college peer learning.",
    version="1.0.0",
    lifespan=lifespan
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include Routers
app.include_router(auth.router)
app.include_router(profiles.router)
app.include_router(subjects.router)
app.include_router(matching.router)
app.include_router(connections.router)
app.include_router(chat.router)
app.include_router(sessions.router)
app.include_router(portfolio.router)
app.include_router(notifications.router)
app.include_router(websocket.router)

@app.get("/api/health")
def health_check():
    return {
        "status": "healthy",
        "app": "Skill Bloom",
        "tagline": "Share Your Skills. Grow Together."
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("app.main:app", host="127.0.0.1", port=8000, reload=True)
