import pytest
from fastapi.testclient import TestClient
from app.main import app
from app.database import Base, engine, SessionLocal
from app.seed_data import seed_database
from app.models import User, Subject, StudentSkill, ConnectionRequest

client = TestClient(app)

@pytest.fixture(scope="session", autouse=True)
def setup_db():
    Base.metadata.create_all(bind=engine)
    db = SessionLocal()
    seed_database(db)
    db.close()

def test_health_check():
    response = client.get("/api/health")
    assert response.status_code == 200
    data = response.json()
    assert data["app"] == "Skill Bloom"
    assert data["tagline"] == "Share Your Skills. Grow Together."

def test_login_demo_user():
    response = client.post("/api/auth/login", json={
        "email": "test@demo.edu",
        "password": "password123"
    })
    assert response.status_code == 200
    data = response.json()
    assert "access_token" in data
    assert data["email"] == "test@demo.edu"

def test_login_invalid_credentials():
    response = client.post("/api/auth/login", json={
        "email": "test@demo.edu",
        "password": "wrongpassword"
    })
    assert response.status_code == 401

def test_get_avatars_catalog():
    response = client.get("/api/auth/avatars")
    assert response.status_code == 200
    avatars = response.json()
    assert len(avatars) >= 10
    ids = [a["id"] for a in avatars]
    assert "avatar-owl" in ids
    assert "avatar-coder" in ids

def test_list_subjects():
    response = client.get("/api/subjects")
    assert response.status_code == 200
    subjects = response.json()
    assert len(subjects) >= 10
    names = [s["name"] for s in subjects]
    assert any("Data Structures" in n for n in names)
    assert any("Python" in n for n in names)

def test_smart_matching_and_ranking():
    # Login as test user
    login_res = client.post("/api/auth/login", json={
        "email": "test@demo.edu",
        "password": "password123"
    })
    token = login_res.json()["access_token"]
    headers = {"Authorization": f"Bearer {token}"}

    # Get subject ID for Data Structures
    subjects_res = client.get("/api/subjects?q=Data%20Structures")
    dsa_subj = subjects_res.json()[0]

    # Query ranked mentors
    rank_res = client.get(f"/api/matching/subject/{dsa_subj['id']}", headers=headers)
    assert rank_res.status_code == 200
    ranked = rank_res.json()
    assert len(ranked) >= 1

    # Aarav Sharma should be top ranked with high estimated compatibility percentage
    top_mentor = ranked[0]
    assert top_mentor["full_name"] == "Aarav Sharma"
    assert top_mentor["rank"] == 1
    assert top_mentor["estimated_match_percentage"] >= 70
    assert "score_breakdown" in top_mentor
    assert top_mentor["score_breakdown"]["proficiency_points"] > 0
    assert top_mentor["score_breakdown"]["verification_points"] > 0

def test_prevent_messaging_strangers_without_accepted_connection():
    # Login as Kabir
    kabir_res = client.post("/api/auth/login", json={
        "email": "kabir@demo.edu",
        "password": "password123"
    })
    kabir_token = kabir_res.json()["access_token"]
    kabir_headers = {"Authorization": f"Bearer {kabir_token}"}

    # Find Aarav's id
    aarav_res = client.post("/api/auth/login", json={
        "email": "aarav@demo.edu",
        "password": "password123"
    })
    aarav_id = aarav_res.json()["user_id"]

    # Kabir attempts to send private message to Aarav directly without connected status
    # Backend must return 403 Forbidden
    msg_res = client.post("/api/chat/send", json={
        "receiver_id": aarav_id,
        "content": "Hey stranger! Want to call?"
    }, headers=kabir_headers)

    assert msg_res.status_code == 403
    assert "mutually accepted connections" in msg_res.json()["detail"].lower()

def test_connection_flow_and_subsequent_chat():
    # 1. Register two new mock students to test full end-to-end connection flow
    student_a_res = client.post("/api/auth/register", json={
        "email": "studenta_test@demo.edu",
        "password": "password123",
        "full_name": "Student A",
        "college": "Test Tech",
        "course": "B.Tech CS",
        "semester": 3,
        "preferred_language": "English",
        "avatar_id": "avatar-panda"
    })
    token_a = student_a_res.json()["access_token"]
    id_a = student_a_res.json()["user_id"]
    headers_a = {"Authorization": f"Bearer {token_a}"}

    student_b_res = client.post("/api/auth/register", json={
        "email": "studentb_test@demo.edu",
        "password": "password123",
        "full_name": "Student B",
        "college": "Test Tech",
        "course": "B.Tech IT",
        "semester": 3,
        "preferred_language": "English",
        "avatar_id": "avatar-cat"
    })
    token_b = student_b_res.json()["access_token"]
    id_b = student_b_res.json()["user_id"]
    headers_b = {"Authorization": f"Bearer {token_b}"}

    # 2. Cannot send connection request to self
    self_res = client.post("/api/connections/request", json={
        "receiver_id": id_a,
        "message": "Self connect"
    }, headers=headers_a)
    assert self_res.status_code == 400

    # 3. Student A sends request to Student B
    send_req_res = client.post("/api/connections/request", json={
        "receiver_id": id_b,
        "message": "Hi Student B, let's learn together!"
    }, headers=headers_a)
    assert send_req_res.status_code == 200
    request_id = send_req_res.json()["id"]

    # 4. Duplicate request prevention
    dup_res = client.post("/api/connections/request", json={
        "receiver_id": id_b,
        "message": "Duplicate attempt"
    }, headers=headers_a)
    assert dup_res.status_code == 400

    # 5. Student B views incoming connections
    conns_b = client.get("/api/connections", headers=headers_b).json()
    assert len(conns_b["incoming_pending"]) >= 1
    assert conns_b["incoming_pending"][0]["sender_id"] == id_a

    # 6. Student B accepts connection
    accept_res = client.put(f"/api/connections/{request_id}/accept", headers=headers_b)
    assert accept_res.status_code == 200

    # 7. Now that connection is accepted, both can send private chat messages!
    msg_res = client.post("/api/chat/send", json={
        "receiver_id": id_b,
        "content": "Hello after connection accepted!"
    }, headers=headers_a)
    assert msg_res.status_code == 200
    msg_data = msg_res.json()
    assert msg_data["content"] == "Hello after connection accepted!"

    # 8. Student B reads messages
    history_res = client.get(f"/api/chat/messages/{id_a}", headers=headers_b)
    assert history_res.status_code == 200
    msgs = history_res.json()
    assert len(msgs) == 1
    assert msgs[0]["content"] == "Hello after connection accepted!"

def test_session_lifecycle_and_review():
    # Login as test@demo.edu and Aarav (already connected in seed data)
    test_res = client.post("/api/auth/login", json={"email": "test@demo.edu", "password": "password123"})
    token_test = test_res.json()["access_token"]
    test_id = test_res.json()["user_id"]
    headers_test = {"Authorization": f"Bearer {token_test}"}

    aarav_res = client.post("/api/auth/login", json={"email": "aarav@demo.edu", "password": "password123"})
    aarav_id = aarav_res.json()["user_id"]
    token_aarav = aarav_res.json()["access_token"]
    headers_aarav = {"Authorization": f"Bearer {token_aarav}"}

    # 1. Schedule session
    schedule_res = client.post("/api/sessions", json={
        "peer_id": aarav_id,
        "as_teacher": False,
        "subject_id": 1,
        "title": "Trees & Recursion Session",
        "description": "Covering binary search tree operations",
        "scheduled_time": "2026-11-01T15:00:00",
        "duration_minutes": 60
    }, headers=headers_test)
    assert schedule_res.status_code == 200
    session_id = schedule_res.json()["id"]

    # 2. Complete session
    comp_res = client.put(f"/api/sessions/{session_id}/complete", headers=headers_test)
    assert comp_res.status_code == 200

    # 3. Post review
    rev_res = client.post("/api/sessions/reviews", json={
        "session_id": session_id,
        "rating": 5.0,
        "teaching_clarity": 5,
        "helpfulness": 5,
        "punctuality": 5,
        "feedback": "Outstanding peer mentor! Very clear recursive breakdown."
    }, headers=headers_test)
    assert rev_res.status_code == 200

    # 4. Duplicate review prevented
    dup_rev = client.post("/api/sessions/reviews", json={
        "session_id": session_id,
        "rating": 5.0,
        "feedback": "Second review attempt"
    }, headers=headers_test)
    assert dup_rev.status_code == 400
