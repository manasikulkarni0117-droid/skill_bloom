@echo off
echo ========================================================
echo Starting Skill Bloom Frontend (React + Vite)
echo ========================================================
cd frontend
if not exist node_modules (
    echo Installing npm dependencies...
    call npm install
)
echo Launching Vite development server on http://localhost:5173 ...
call npm run dev
pause
