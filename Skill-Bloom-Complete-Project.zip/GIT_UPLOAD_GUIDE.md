# 🚀 GitHub वर प्रोजेक्ट अपलोड करण्याची मार्गदर्शिका (Git Upload Guide)

हा प्रोजेक्ट GitHub वर योग्य आणि सुरक्षित पद्धतीने अपलोड करण्यासाठी सर्व आवश्यक फाइल्स तयार केल्या आहेत:
1. **`.gitignore`** (ज्यामुळे `node_modules`, `venv`, `skillbloom.db` आणि खाजगी कीज GitHub वर जाणार नाहीत आणि फक्त मूळ कोड अपलोड होईल).
2. **`upload_to_github.bat`** (ऑटोमॅटिक १-क्लिक अपलोड स्क्रिप्ट).

---

## पर्याय १: ऑटोमॅटिक पद्धत (सर्वात सोपी पद्धत)

1. GitHub वर जा ([https://github.com/new](https://github.com/new)) आणि **New Repository** तयार करा:
   - Repository name द्या: `Skill-Bloom` (किंवा तुमच्या आवडीचे नाव).
   - **महत्त्वाचे:** `Add a README file`, `Add .gitignore`, किंवा `Choose a license` ला टिक **करू नका** (रिकामी Repository ठेवा).
   - **Create repository** वर क्लिक करा.
   - तयार झालेल्या रिपॉझिटरीची लिंक कॉपी करा (उदा. `https://github.com/तुमचे-नाव/Skill-Bloom.git`).

2. तुमच्या प्रोजेक्ट फोल्डरमधील **`upload_to_github.bat`** या फाईलवर **Double Click** करा (किंवा टर्मिनलमध्ये `.\upload_to_github.bat` चालवा).

3. ती स्क्रिप्ट तुमची GitHub URL मागेल, तिथे तुमची कॉपी केलेली URL पेस्ट करा आणि Enter दाबा.
4. सर्व फाइल्स आपोआप Git मध्ये Add, Commit होऊन तुमच्या GitHub वर Push होतील!

---

## पर्याय २: मॅन्युअल कमांड्स (Terminal / Command Prompt द्वारे)

जर तुम्हाला स्वतः Commands चालवून अपलोड करायचे असेल, तर PowerShell किंवा Command Prompt मध्ये खालील स्टेप्स फॉलो करा:

```bash
# १. प्रोजेक्ट फोल्डरमध्ये Git सुरू करा
git init

# २. सर्व योग्य फाइल्स स्टेज करा (.gitignore मुळे नको असलेल्या फाइल्स आपोआप वगळल्या जातील)
git add .

# ३. पहिली कमिट करा
git commit -m "Initial commit: Skill Bloom Peer-to-Peer College Learning Platform"

# ४. मुख्य ब्रँचचे नाव 'main' ठेवा
git branch -M main

# ५. तुमची GitHub रिपॉझिटरी जोडा (खालील URL मध्ये तुमचे यूजरनेम आणि रिपो नाव टाका)
git remote add origin https://github.com/YOUR_USERNAME/Skill-Bloom.git

# ६. GitHub वर कोड पुश करा
git push -u origin main
```

---

## 🔒 सुरक्षेची काळजी (.gitignore काय वगळते?)

तुमच्या प्रोजेक्टमध्ये खालील फाइल्स सुरक्षित ठेवल्या आहेत आणि त्या GitHub वर अपलोड **होणार नाहीत**:
- `backend/venv/` (ह्यामुळे रिपॉझिटरीची साईझ मोठी होत नाही)
- `frontend/node_modules/` (कोणीही क्लोन केल्यावर `npm install` करू शकतो)
- `skillbloom.db` (स्थानिक डेटाबेस)
- `.env` (सिक्रेट कीज)
- `backend/uploads/*` (विद्यार्थ्यांचे स्थानिक डॉक्युमेंट्स)

सर्व युजर्ससाठी `.env.example` आणि सेटअप स्क्रिप्ट्स आधीच तयार केलेल्या आहेत!
