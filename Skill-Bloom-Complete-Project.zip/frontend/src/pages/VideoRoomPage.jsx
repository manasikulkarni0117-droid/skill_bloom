import React, { useState, useEffect, useRef } from 'react';
import {
  Mic, MicOff, Video, VideoOff, PhoneOff, Monitor, MessageSquare,
  Copy, Check, Users, Sparkles, Shield, AlertCircle, Maximize2
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { AvatarBadge } from '../components/AvatarBadge';
import { ReviewModal } from '../components/ReviewModal';

const ICE_SERVERS = {
  iceServers: [
    { urls: 'stun:stun.l.google.com:19302' },
    { urls: 'stun:stun1.l.google.com:19302' }
  ]
};

export const VideoRoomPage = ({ session, onLeaveRoom }) => {
  const { user } = useAuth();
  const roomId = session?.meeting_room_id || 'sb-room-demo';
  const peerName = session?.is_host ? session?.learner_name : (session?.host_name || 'Peer Student');
  const peerAvatar = session?.is_host ? session?.learner_avatar : (session?.host_avatar || 'avatar-coder');

  // Media controls
  const [micActive, setMicActive] = useState(true);
  const [cameraActive, setCameraActive] = useState(true);
  const [screenSharing, setScreenSharing] = useState(false);
  const [inCallChatOpen, setInCallChatOpen] = useState(false);
  const [chatMessages, setChatMessages] = useState([]);
  const [inputChat, setInputChat] = useState('');

  // Call state
  const [callDuration, setCallDuration] = useState(0);
  const [copiedLink, setCopiedLink] = useState(false);
  const [peerConnected, setPeerConnected] = useState(false);
  const [mediaError, setMediaError] = useState(null);
  const [reviewModalOpen, setReviewModalOpen] = useState(false);

  // References
  const localVideoRef = useRef(null);
  const remoteVideoRef = useRef(null);
  const localStreamRef = useRef(null);
  const peerConnectionRef = useRef(null);
  const signalingWsRef = useRef(null);

  // Timer
  useEffect(() => {
    const timer = setInterval(() => {
      setCallDuration(prev => prev + 1);
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const formatTimer = (secs) => {
    const mins = Math.floor(secs / 60);
    const s = secs % 60;
    return `${mins.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  // Setup WebRTC and Media Stream
  useEffect(() => {
    let isMounted = true;

    async function initMediaAndSignaling() {
      try {
        // 1. Get user media (mic & camera)
        let stream;
        try {
          stream = await navigator.mediaDevices.getUserMedia({
            audio: true,
            video: { width: { ideal: 640 }, height: { ideal: 480 } }
          });
        } catch (camErr) {
          console.warn('Camera/mic access unavailable, using simulated video stream:', camErr);
          setMediaError('Camera permission was not granted or device not detected. Audio/avatar mode active.');
          // Create dummy silent audio or canvas stream if needed
        }

        if (stream && isMounted) {
          localStreamRef.current = stream;
          if (localVideoRef.current) {
            localVideoRef.current.srcObject = stream;
          }
        }

        // 2. Connect to WebSocket Signaling Server
        const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
        const wsUrl = `${protocol}//${window.location.host}/ws/signaling/${roomId}/${user?.id || 1}`;
        const ws = new WebSocket(wsUrl);
        signalingWsRef.current = ws;

        ws.onopen = () => {
          console.log('Signaling WebSocket connected to room:', roomId);
        };

        ws.onmessage = async (event) => {
          try {
            const data = JSON.parse(event.data);

            if (data.type === 'user-joined') {
              console.log('Peer joined room:', data.userId);
              setPeerConnected(true);
              // As the existing peer, create and send WebRTC offer
              await createAndSendOffer(data.userId);
            } else if (data.type === 'room-info') {
              if (data.peers && data.peers.length > 0) {
                setPeerConnected(true);
              }
            } else if (data.type === 'offer') {
              setPeerConnected(true);
              await handleReceiveOffer(data);
            } else if (data.type === 'answer') {
              await handleReceiveAnswer(data);
            } else if (data.type === 'ice-candidate') {
              if (peerConnectionRef.current && data.candidate) {
                await peerConnectionRef.current.addIceCandidate(new RTCIceCandidate(data.candidate));
              }
            } else if (data.type === 'in-call-message') {
              setChatMessages(prev => [...prev, {
                sender: peerName,
                text: data.text,
                time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
              }]);
            } else if (data.type === 'user-left') {
              setPeerConnected(false);
            }
          } catch (e) {
            console.error('Signaling message error:', e);
          }
        };

      } catch (err) {
        console.error('Failed to initialize call:', err);
      }
    }

    initMediaAndSignaling();

    return () => {
      isMounted = false;
      // Cleanup streams and peer connection
      if (localStreamRef.current) {
        localStreamRef.current.getTracks().forEach(track => track.stop());
      }
      if (peerConnectionRef.current) {
        peerConnectionRef.current.close();
      }
      if (signalingWsRef.current) {
        signalingWsRef.current.close();
      }
    };
  }, [roomId]);

  // Create PeerConnection helper
  const getOrCreatePeerConnection = (targetUserId) => {
    if (peerConnectionRef.current) return peerConnectionRef.current;

    const pc = new RTCPeerConnection(ICE_SERVERS);
    peerConnectionRef.current = pc;

    // Add local tracks to peer connection
    if (localStreamRef.current) {
      localStreamRef.current.getTracks().forEach(track => {
        pc.addTrack(track, localStreamRef.current);
      });
    }

    // Remote track arrived
    pc.ontrack = (event) => {
      console.log('Received remote track:', event.streams[0]);
      if (remoteVideoRef.current && event.streams[0]) {
        remoteVideoRef.current.srcObject = event.streams[0];
        setPeerConnected(true);
      }
    };

    // ICE candidate
    pc.onicecandidate = (event) => {
      if (event.candidate && signalingWsRef.current?.readyState === WebSocket.OPEN) {
        signalingWsRef.current.send(JSON.stringify({
          type: 'ice-candidate',
          targetUserId,
          candidate: event.candidate
        }));
      }
    };

    return pc;
  };

  const createAndSendOffer = async (targetUserId) => {
    const pc = getOrCreatePeerConnection(targetUserId);
    const offer = await pc.createOffer();
    await pc.setLocalDescription(offer);

    if (signalingWsRef.current?.readyState === WebSocket.OPEN) {
      signalingWsRef.current.send(JSON.stringify({
        type: 'offer',
        targetUserId,
        sdp: pc.localDescription
      }));
    }
  };

  const handleReceiveOffer = async (data) => {
    const pc = getOrCreatePeerConnection(data.fromUserId);
    await pc.setRemoteDescription(new RTCSessionDescription(data.sdp));
    const answer = await pc.createAnswer();
    await pc.setLocalDescription(answer);

    if (signalingWsRef.current?.readyState === WebSocket.OPEN) {
      signalingWsRef.current.send(JSON.stringify({
        type: 'answer',
        targetUserId: data.fromUserId,
        sdp: pc.localDescription
      }));
    }
  };

  const handleReceiveAnswer = async (data) => {
    if (peerConnectionRef.current) {
      await peerConnectionRef.current.setRemoteDescription(new RTCSessionDescription(data.sdp));
    }
  };

  // Toggle Microphone
  const toggleMic = () => {
    if (localStreamRef.current) {
      const audioTrack = localStreamRef.current.getAudioTracks()[0];
      if (audioTrack) {
        audioTrack.enabled = !audioTrack.enabled;
        setMicActive(audioTrack.enabled);
      }
    } else {
      setMicActive(!micActive);
    }
  };

  // Toggle Camera
  const toggleCamera = () => {
    if (localStreamRef.current) {
      const videoTrack = localStreamRef.current.getVideoTracks()[0];
      if (videoTrack) {
        videoTrack.enabled = !videoTrack.enabled;
        setCameraActive(videoTrack.enabled);
      }
    } else {
      setCameraActive(!cameraActive);
    }
  };

  // Screen Sharing
  const toggleScreenShare = async () => {
    if (!screenSharing) {
      try {
        const displayStream = await navigator.mediaDevices.getDisplayMedia({ video: true });
        const screenTrack = displayStream.getVideoTracks()[0];

        // Replace track in peer connection
        if (peerConnectionRef.current) {
          const sender = peerConnectionRef.current.getSenders().find(s => s.track?.kind === 'video');
          if (sender) {
            sender.replaceTrack(screenTrack);
          }
        }

        if (localVideoRef.current) {
          localVideoRef.current.srcObject = displayStream;
        }

        screenTrack.onended = () => {
          stopScreenShare();
        };

        setScreenSharing(true);
      } catch (err) {
        console.warn('Screen share cancelled or unsupported:', err);
      }
    } else {
      stopScreenShare();
    }
  };

  const stopScreenShare = () => {
    if (localStreamRef.current && localVideoRef.current) {
      const cameraTrack = localStreamRef.current.getVideoTracks()[0];
      if (peerConnectionRef.current) {
        const sender = peerConnectionRef.current.getSenders().find(s => s.track?.kind === 'video');
        if (sender && cameraTrack) {
          sender.replaceTrack(cameraTrack);
        }
      }
      localVideoRef.current.srcObject = localStreamRef.current;
    }
    setScreenSharing(false);
  };

  // In-call chat send
  const handleSendInCallChat = (e) => {
    e.preventDefault();
    if (!inputChat.trim()) return;

    const msgObj = {
      sender: 'You',
      text: inputChat.trim(),
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setChatMessages(prev => [...prev, msgObj]);

    if (signalingWsRef.current?.readyState === WebSocket.OPEN) {
      signalingWsRef.current.send(JSON.stringify({
        type: 'in-call-message',
        text: inputChat.trim()
      }));
    }

    setInputChat('');
  };

  const copyRoomLink = () => {
    const url = window.location.href;
    navigator.clipboard.writeText(url);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  const handleHangUp = () => {
    setReviewModalOpen(true);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950 text-white flex flex-col font-sans select-none animate-fade-in">
      {/* Top Bar (Google Meet style) */}
      <div className="h-16 px-6 flex items-center justify-between border-b border-slate-800/80 bg-slate-900/90 backdrop-blur-md">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-xl bg-brand-500/20 text-brand-400 flex items-center justify-center font-bold text-sm">
            🌱
          </div>
          <div>
            <h2 className="text-sm font-bold text-slate-100 truncate max-w-xs sm:max-w-md">
              {session?.title || 'Skill Bloom 1-on-1 Video Learning Room'}
            </h2>
            <div className="flex items-center gap-2 text-[11px] text-slate-400">
              <span className="text-brand-400 font-semibold">{formatTimer(callDuration)}</span>
              <span>•</span>
              <span className="font-mono bg-slate-800 px-1.5 py-0.5 rounded text-slate-300">
                {roomId}
              </span>
              <button
                onClick={copyRoomLink}
                className="hover:text-white transition flex items-center gap-1"
                title="Copy Room Link"
              >
                {copiedLink ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
              </button>
            </div>
          </div>
        </div>

        {/* Security badge and peer status */}
        <div className="flex items-center gap-3">
          <div className="hidden sm:flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-800/80 text-xs border border-slate-700/60">
            <Shield className="w-3.5 h-3.5 text-emerald-400" />
            <span className="text-slate-300">Peer WebRTC Encrypted</span>
          </div>

          <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-slate-800/80 text-xs">
            <span className={`w-2.5 h-2.5 rounded-full ${peerConnected ? 'bg-emerald-500 animate-pulse' : 'bg-amber-400'}`} />
            <span className="text-slate-200">
              {peerConnected ? `${peerName} in Room` : 'Waiting for Peer to Join...'}
            </span>
          </div>
        </div>
      </div>

      {/* Main Video Presentation Grid */}
      <div className="flex-1 relative flex overflow-hidden p-4 sm:p-6 gap-4">
        {/* Remote Peer Video Stage */}
        <div className="flex-1 relative bg-slate-900 rounded-3xl overflow-hidden border border-slate-800/80 flex items-center justify-center shadow-2xl">
          <video
            ref={remoteVideoRef}
            autoPlay
            playsInline
            className={`w-full h-full object-cover ${peerConnected ? 'block' : 'hidden'}`}
          />

          {/* Placeholder if peer video not connected */}
          {!peerConnected && (
            <div className="text-center space-y-4 max-w-sm p-6">
              <div className="relative inline-block">
                <AvatarBadge avatarId={peerAvatar} size="2xl" />
                <span className="absolute bottom-1 right-1 w-4 h-4 rounded-full bg-amber-400 ring-2 ring-slate-900 animate-ping" />
              </div>
              <div className="space-y-1">
                <h3 className="text-lg font-bold text-slate-100">{peerName}</h3>
                <p className="text-xs text-slate-400 leading-relaxed">
                  Waiting for peer student to connect. Share the room code or test with 2 tabs!
                </p>
              </div>

              {/* Local Test Instructions Box */}
              <div className="p-3.5 rounded-2xl bg-slate-800/60 border border-slate-700/60 text-[11px] text-slate-300 text-left space-y-1.5">
                <div className="flex items-center gap-1 text-brand-400 font-bold">
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>How to test multi-peer calling locally:</span>
                </div>
                <p className="text-slate-400">
                  Open an <strong>Incognito window</strong> or second browser, log in as <strong>{peerName}</strong>, and join this session to see active 2-way WebRTC live video & audio!
                </p>
              </div>
            </div>
          )}

          {/* Peer Overlay Tag */}
          <div className="absolute bottom-4 left-4 px-3 py-1.5 rounded-xl bg-slate-950/70 backdrop-blur-md text-xs font-semibold flex items-center gap-2 border border-slate-700/40">
            <span>{peerName}</span>
            <span className="text-[10px] text-slate-400">({peerConnected ? 'Connected' : 'Connecting'})</span>
          </div>
        </div>

        {/* Local Video Picture-in-Picture */}
        <div className="absolute bottom-24 right-8 w-44 sm:w-60 h-32 sm:h-44 rounded-2xl bg-slate-900 border-2 border-slate-700 shadow-2xl overflow-hidden z-20">
          <video
            ref={localVideoRef}
            autoPlay
            muted
            playsInline
            className={`w-full h-full object-cover -scale-x-100 ${cameraActive ? 'block' : 'hidden'}`}
          />

          {!cameraActive && (
            <div className="w-full h-full flex flex-col items-center justify-center bg-slate-800 text-center p-2">
              <AvatarBadge avatarId={user?.avatar_id} size="lg" />
              <span className="text-[10px] font-bold text-slate-400 mt-1">Camera Off</span>
            </div>
          )}

          <div className="absolute bottom-2 left-2 px-2 py-0.5 rounded-md bg-slate-950/80 text-[10px] font-semibold flex items-center gap-1.5">
            <span>You</span>
            {!micActive && <MicOff className="w-3 h-3 text-rose-400" />}
          </div>
        </div>

        {/* In-Call Chat Sidebar Drawer */}
        {inCallChatOpen && (
          <div className="w-80 rounded-3xl bg-slate-900 border border-slate-800 flex flex-col z-30 shadow-2xl animate-fade-in">
            <div className="p-4 border-b border-slate-800 flex items-center justify-between">
              <h3 className="font-bold text-xs uppercase tracking-wider text-slate-300">
                In-Call Notes & Chat
              </h3>
              <button
                onClick={() => setInCallChatOpen(false)}
                className="text-slate-400 hover:text-white text-xs font-bold"
              >
                Close
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-3 space-y-2.5 text-xs">
              {chatMessages.length === 0 ? (
                <p className="text-slate-500 text-center pt-8 italic text-[11px]">
                  Share code snippets, doubts, or notes with peers in this room.
                </p>
              ) : (
                chatMessages.map((m, idx) => (
                  <div key={idx} className="p-2.5 rounded-xl bg-slate-800 border border-slate-700/60 space-y-1">
                    <div className="flex items-center justify-between text-[10px] text-brand-400 font-bold">
                      <span>{m.sender}</span>
                      <span className="text-slate-500">{m.time}</span>
                    </div>
                    <p className="text-slate-200 whitespace-pre-wrap">{m.text}</p>
                  </div>
                ))
              )}
            </div>

            <form onSubmit={handleSendInCallChat} className="p-3 border-t border-slate-800 flex gap-2">
              <input
                type="text"
                value={inputChat}
                onChange={(e) => setInputChat(e.target.value)}
                placeholder="Type a note..."
                className="flex-1 bg-slate-800 text-xs px-3 py-2 rounded-xl border border-slate-700 focus:outline-none focus:ring-1 focus:ring-brand-500"
              />
              <button
                type="submit"
                className="px-3 py-2 rounded-xl bg-brand-600 hover:bg-brand-700 font-bold text-xs"
              >
                Send
              </button>
            </form>
          </div>
        )}
      </div>

      {/* Floating Bottom Toolbar (Google Meet style) */}
      <div className="h-20 bg-slate-900/90 border-t border-slate-800 flex items-center justify-center gap-3 sm:gap-4 px-4">
        {/* Mic Toggle */}
        <button
          onClick={toggleMic}
          className={`p-3.5 rounded-2xl transition transform active:scale-95 shadow-md ${
            micActive
              ? 'bg-slate-800 text-white hover:bg-slate-700'
              : 'bg-rose-600 text-white hover:bg-rose-700 ring-2 ring-rose-400'
          }`}
          title={micActive ? 'Mute Microphone' : 'Unmute Microphone'}
        >
          {micActive ? <Mic className="w-5 h-5" /> : <MicOff className="w-5 h-5" />}
        </button>

        {/* Camera Toggle */}
        <button
          onClick={toggleCamera}
          className={`p-3.5 rounded-2xl transition transform active:scale-95 shadow-md ${
            cameraActive
              ? 'bg-slate-800 text-white hover:bg-slate-700'
              : 'bg-rose-600 text-white hover:bg-rose-700 ring-2 ring-rose-400'
          }`}
          title={cameraActive ? 'Turn Off Video' : 'Turn On Video'}
        >
          {cameraActive ? <Video className="w-5 h-5" /> : <VideoOff className="w-5 h-5" />}
        </button>

        {/* Screen Share */}
        <button
          onClick={toggleScreenShare}
          className={`p-3.5 rounded-2xl transition transform active:scale-95 shadow-md ${
            screenSharing
              ? 'bg-brand-600 text-white ring-2 ring-brand-400'
              : 'bg-slate-800 text-white hover:bg-slate-700'
          }`}
          title={screenSharing ? 'Stop Screen Share' : 'Share Screen'}
        >
          <Monitor className="w-5 h-5" />
        </button>

        {/* In-Call Chat */}
        <button
          onClick={() => setInCallChatOpen(!inCallChatOpen)}
          className={`p-3.5 rounded-2xl transition transform active:scale-95 shadow-md ${
            inCallChatOpen
              ? 'bg-purpleBrand-600 text-white'
              : 'bg-slate-800 text-white hover:bg-slate-700'
          }`}
          title="In-Call Chat"
        >
          <MessageSquare className="w-5 h-5" />
        </button>

        {/* Leave Call (Red Hangup) */}
        <button
          onClick={handleHangUp}
          className="px-6 py-3.5 rounded-2xl bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs flex items-center gap-2 shadow-lg shadow-rose-600/30 transition transform active:scale-95"
          title="Leave Room & Review Session"
        >
          <PhoneOff className="w-5 h-5" />
          <span className="hidden sm:inline">Leave Room</span>
        </button>
      </div>

      <ReviewModal
        isOpen={reviewModalOpen}
        onClose={() => {
          setReviewModalOpen(false);
          onLeaveRoom();
        }}
        session={session}
        onSuccess={() => {
          setReviewModalOpen(false);
          onLeaveRoom();
        }}
      />
    </div>
  );
};
