import React, { useState, useEffect } from 'react';
import {
  Search, BookOpen, Plus, Filter, Users, GraduationCap,
  Sparkles, Check, ArrowRight
} from 'lucide-react';
import { subjectApi } from '../services/api';

export const ExploreSubjectsPage = ({ onSelectSubject }) => {
  const [subjects, setSubjects] = useState([]);
  const [categories, setCategories] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [selectedSemester, setSelectedSemester] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [loading, setLoading] = useState(true);

  // Custom subject modal
  const [customModalOpen, setCustomModalOpen] = useState(false);
  const [newSubjName, setNewSubjName] = useState('');
  const [newSubjCategory, setNewSubjCategory] = useState('Computer Science');
  const [newSubjCode, setNewSubjCode] = useState('');
  const [newSubjSemester, setNewSubjSemester] = useState(3);
  const [newSubjDesc, setNewSubjDesc] = useState('');
  const [customError, setCustomError] = useState(null);
  const [customSubmitting, setCustomSubmitting] = useState(false);

  const loadData = async () => {
    try {
      setLoading(true);
      const [subjList, catList] = await Promise.all([
        subjectApi.getSubjects({
          q: searchQuery,
          category: selectedCategory,
          semester: selectedSemester ? parseInt(selectedSemester) : undefined
        }),
        subjectApi.getCategories()
      ]);
      setSubjects(subjList);
      setCategories(['All', ...catList]);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, [selectedCategory, selectedSemester]);

  const handleSearchSubmit = (e) => {
    e.preventDefault();
    loadData();
  };

  const handleCreateCustom = async (e) => {
    e.preventDefault();
    setCustomSubmitting(true);
    setCustomError(null);
    try {
      const created = await subjectApi.createCustomSubject({
        name: newSubjName.trim(),
        category: newSubjCategory,
        code: newSubjCode.trim() || undefined,
        semester_recommended: parseInt(newSubjSemester),
        description: newSubjDesc.trim() || undefined
      });
      setCustomModalOpen(false);
      setNewSubjName('');
      setNewSubjDesc('');
      setNewSubjCode('');
      loadData();
      if (onSelectSubject) onSelectSubject(created);
    } catch (err) {
      setCustomError(err.message || 'Failed to add custom subject');
    } finally {
      setCustomSubmitting(false);
    }
  };

  return (
    <div className="space-y-8 pb-16 animate-fade-in max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      {/* Header Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">
            Explore College Subjects & Skills
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Browse through core engineering, science, and humanities curriculums. Connect with peer experts.
          </p>
        </div>

        <button
          onClick={() => setCustomModalOpen(true)}
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-2xl bg-brand-600 hover:bg-brand-700 text-white font-bold text-xs shadow-sm transition"
        >
          <Plus className="w-4 h-4" />
          <span>Add Custom Subject</span>
        </button>
      </div>

      {/* Search and Category Filters */}
      <div className="bg-white rounded-3xl p-5 border border-slate-100 shadow-sm space-y-4">
        <form onSubmit={handleSearchSubmit} className="flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="w-5 h-5 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Filter by name, course code or description (e.g. CS201, Algorithms, Calculus)..."
              className="w-full pl-11 pr-4 py-2.5 rounded-2xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500"
            />
          </div>
          <button
            type="submit"
            className="px-5 py-2.5 rounded-2xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold transition"
          >
            Search
          </button>
        </form>

        <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-slate-100">
          {/* Category Chips */}
          <div className="flex flex-wrap items-center gap-1.5">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition ${
                  selectedCategory === cat
                    ? 'bg-brand-600 text-white shadow-2xs'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          {/* Semester Filter */}
          <div className="flex items-center gap-2">
            <span className="text-xs font-semibold text-slate-500">Semester:</span>
            <select
              value={selectedSemester}
              onChange={(e) => setSelectedSemester(e.target.value)}
              className="text-xs p-1.5 rounded-xl border border-slate-200 bg-white focus:outline-none focus:ring-2 focus:ring-brand-500"
            >
              <option value="">All Semesters</option>
              {[1, 2, 3, 4, 5, 6, 7, 8].map(s => (
                <option key={s} value={s}>Semester {s}</option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Grid of Subjects */}
      {loading ? (
        <div className="p-12 text-center text-slate-400 text-sm">Loading college subjects...</div>
      ) : subjects.length === 0 ? (
        <div className="p-12 text-center rounded-3xl bg-white border border-slate-100 space-y-3">
          <BookOpen className="w-10 h-10 text-slate-300 mx-auto" />
          <h3 className="font-bold text-slate-700">No subjects found</h3>
          <p className="text-xs text-slate-400">Try adjusting your search query or add a custom subject.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {subjects.map((s) => (
            <div
              key={s.id}
              className="p-6 rounded-3xl bg-white border border-slate-100 shadow-2xs hover:shadow-md hover:border-brand-200 transition-all flex flex-col justify-between space-y-4 group"
            >
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold px-2.5 py-0.5 rounded-lg bg-slate-100 text-slate-700">
                    {s.code || 'COLLEGE'}
                  </span>
                  <span className="text-[11px] font-bold text-brand-600 bg-brand-50 px-2 py-0.5 rounded-lg">
                    Semester {s.semester_recommended}
                  </span>
                </div>

                <h3 className="font-bold text-base text-slate-900 group-hover:text-brand-600 transition">
                  {s.name}
                </h3>

                <p className="text-xs text-slate-500 line-clamp-3 leading-relaxed">
                  {s.description || 'Comprehensive curriculum topic covering fundamental and applied collegiate problem-solving.'}
                </p>
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
                <div className="flex items-center gap-1.5 text-xs text-slate-500">
                  <Users className="w-4 h-4 text-brand-500" />
                  <span className="font-semibold text-slate-700">{s.teachers_count || 0}</span>
                  <span>peers can teach</span>
                </div>

                <button
                  onClick={() => onSelectSubject(s)}
                  className="px-3.5 py-1.5 rounded-xl bg-brand-50 text-brand-700 hover:bg-brand-600 hover:text-white font-bold text-xs transition flex items-center gap-1"
                >
                  <span>Ranked Mentors</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Add Custom Subject Modal */}
      {customModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-sm animate-fade-in">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-100">
            <h3 className="font-bold text-slate-900 text-lg">Add Custom College Subject</h3>
            <p className="text-xs text-slate-500 mt-0.5">Contribute a specialized subject to the peer network</p>

            {customError && (
              <div className="my-3 p-3 rounded-xl bg-rose-50 text-rose-600 text-xs border border-rose-200">
                {customError}
              </div>
            )}

            <form onSubmit={handleCreateCustom} className="space-y-3.5 my-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Subject Name</label>
                <input
                  type="text"
                  required
                  value={newSubjName}
                  onChange={(e) => setNewSubjName(e.target.value)}
                  placeholder="e.g. Quantum Computing Algorithms"
                  className="w-full text-sm p-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-brand-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Category</label>
                  <select
                    value={newSubjCategory}
                    onChange={(e) => setNewSubjCategory(e.target.value)}
                    className="w-full text-sm p-2 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-brand-500"
                  >
                    <option value="Computer Science">Computer Science</option>
                    <option value="Mathematics">Mathematics</option>
                    <option value="Physics & Engineering">Physics & Engineering</option>
                    <option value="Electronics & Circuits">Electronics & Circuits</option>
                    <option value="Humanities & Skills">Humanities & Skills</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Course Code (Optional)</label>
                  <input
                    type="text"
                    value={newSubjCode}
                    onChange={(e) => setNewSubjCode(e.target.value)}
                    placeholder="e.g. CS490"
                    className="w-full text-sm p-2 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-brand-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Recommended Semester</label>
                <select
                  value={newSubjSemester}
                  onChange={(e) => setNewSubjSemester(e.target.value)}
                  className="w-full text-sm p-2 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-brand-500"
                >
                  {[1, 2, 3, 4, 5, 6, 7, 8].map(s => (
                    <option key={s} value={s}>Semester {s}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Description</label>
                <textarea
                  rows={2}
                  value={newSubjDesc}
                  onChange={(e) => setNewSubjDesc(e.target.value)}
                  placeholder="Key topics and concepts..."
                  className="w-full text-sm p-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-brand-500"
                />
              </div>

              <div className="flex justify-end gap-2.5 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setCustomModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-xs font-bold text-slate-600 hover:bg-slate-100"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={customSubmitting}
                  className="px-5 py-2 rounded-xl text-xs font-bold text-white bg-brand-600 hover:bg-brand-700 shadow-sm disabled:opacity-50"
                >
                  {customSubmitting ? 'Adding...' : 'Add Subject'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
