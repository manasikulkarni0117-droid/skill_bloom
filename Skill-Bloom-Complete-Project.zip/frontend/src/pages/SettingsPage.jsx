import React, { useState, useEffect } from 'react';
import {
  Settings as SettingsIcon, Shield, Lock, Bell, User,
  Globe, Clock, LogOut, Check, AlertCircle, Save
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { profileApi } from '../services/api';
import { AvatarBadge } from '../components/AvatarBadge';
import { AvatarPickerModal } from '../components/AvatarPickerModal';

export const SettingsPage = ({ onNavigate }) => {
  const { user, logout, refreshProfile } = useAuth();
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);

  // Form
  const [college, setCollege] = useState('');
  const [course, setCourse] = useState('');
  const [semester, setSemester] = useState(4);
  const [language, setLanguage] = useState('English');
  const [availability, setAvailability] = useState('');
  const [privacy, setPrivacy] = useState('connections_only');
  const [avatarId, setAvatarId] = useState('avatar-owl');

  const [avatarPickerOpen, setAvatarPickerOpen] = useState(false);
  const [savedSuccess, setSavedSuccess] = useState(false);

  useEffect(() => {
    async function load() {
      try {
        setLoading(true);
        const data = await profileApi.getMyProfile();
        setProfile(data);
        setCollege(data.college || '');
        setCourse(data.course || '');
        setSemester(data.semester || 4);
        setLanguage(data.preferred_language || 'English');
        setAvailability(data.availability || '');
        setPrivacy(data.documents_privacy || 'connections_only');
        setAvatarId(data.avatar_id || 'avatar-owl');
      } catch (e) {
        console.error(e);
      } finally {
        setLoading(false);
      }
    }
    load();
  }, [user]);

  const handleSave = async (e) => {
    e.preventDefault();
    try {
      await profileApi.updateMyProfile({
        college,
        course,
        semester: parseInt(semester),
        preferred_language: language,
        availability,
        documents_privacy: privacy,
        avatar_id: avatarId
      });
      await refreshProfile();
      setSavedSuccess(true);
      setTimeout(() => setSavedSuccess(false), 3000);
    } catch (err) {
      alert(err.message || 'Failed to save settings');
    }
  };

  return (
    <div className="space-y-8 pb-16 animate-fade-in max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
      {/* Header */}
      <div>
        <h1 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">
          Settings & Privacy
        </h1>
        <p className="text-xs sm:text-sm text-slate-500 mt-1">
          Configure your student account visibility, document access controls, and learning preferences.
        </p>
      </div>

      {savedSuccess && (
        <div className="p-4 rounded-2xl bg-emerald-50 text-emerald-800 text-xs font-bold border border-emerald-200 flex items-center gap-2">
          <Check className="w-4 h-4 text-emerald-600" />
          <span>Your settings and privacy preferences have been updated!</span>
        </div>
      )}

      <form onSubmit={handleSave} className="space-y-6">
        {/* Document Privacy Controls */}
        <div className="bg-white rounded-3xl p-6 border border-slate-100 shadow-sm space-y-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-purpleBrand-50 text-purpleBrand-600 flex items-center justify-center">
              <Shield className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-sm text-slate-800">Document Privacy Controls</h3>
              <p className="text-xs text-slate-500">Protect your personal transcripts and certificates</p>
            </div>
          </div>

          <div className="space-y-2 pt-2">
            {[
              {
                id: 'connections_only',
                title: 'Mutually Connected Peers Only (Recommended)',
                desc: 'Only students whose connection requests you have accepted can view or download certificates and portfolio links.'
              },
              {
                id: 'public',
                title: 'Public to Verified Students',
                desc: 'Any registered student can view and inspect your skill evidence before sending a connection request.'
              },
              {
                id: 'private',
                title: 'Strictly Private (Only You)',
                desc: 'Hide all certificates and project links from other students entirely.'
              }
            ].map((opt) => (
              <label
                key={opt.id}
                className={`flex items-start gap-3 p-3.5 rounded-2xl border transition cursor-pointer ${
                  privacy === opt.id
                    ? 'border-brand-500 bg-brand-50/50'
                    : 'border-slate-200 hover:bg-slate-50'
                }`}
              >
                <input
                  type="radio"
                  name="doc_privacy"
                  checked={privacy === opt.id}
                  onChange={() => setPrivacy(opt.id)}
                  className="mt-1 accent-brand-600"
                />
                <div className="space-y-0.5">
                  <span className="text-xs font-bold text-slate-800 block">{opt.title}</span>
                  <span className="text-[11px] text-slate-500 block leading-relaxed">{opt.desc}</span>
                </div>
              </label>
            ))}
          </div>
        </div>

        {/* Student Profile & Academic Details */}
        <div className="bg-white rounded-3xl p-6 border border-slate-100 shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <AvatarBadge avatarId={avatarId} size="md" />
              <div>
                <h3 className="font-bold text-sm text-slate-800">Student Profile Avatar</h3>
                <p className="text-xs text-slate-500">Illustrated emoji badge</p>
              </div>
            </div>
            <button
              type="button"
              onClick={() => setAvatarPickerOpen(true)}
              className="px-4 py-2 rounded-xl border border-slate-200 text-xs font-bold text-slate-700 hover:border-brand-500 hover:text-brand-600 transition"
            >
              Choose Avatar
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-4 border-t border-slate-100">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">College / University</label>
              <input
                type="text"
                required
                value={college}
                onChange={(e) => setCollege(e.target.value)}
                className="w-full text-xs sm:text-sm p-2.5 rounded-xl border border-slate-200"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Course / Major</label>
              <input
                type="text"
                required
                value={course}
                onChange={(e) => setCourse(e.target.value)}
                className="w-full text-xs sm:text-sm p-2.5 rounded-xl border border-slate-200"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Current Semester</label>
              <select
                value={semester}
                onChange={(e) => setSemester(e.target.value)}
                className="w-full text-xs sm:text-sm p-2.5 rounded-xl border border-slate-200"
              >
                {[1, 2, 3, 4, 5, 6, 7, 8].map(s => (
                  <option key={s} value={s}>Semester {s}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Preferred Learning Language</label>
              <input
                type="text"
                value={language}
                onChange={(e) => setLanguage(e.target.value)}
                className="w-full text-xs sm:text-sm p-2.5 rounded-xl border border-slate-200"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Study Availability</label>
            <input
              type="text"
              value={availability}
              onChange={(e) => setAvailability(e.target.value)}
              placeholder="e.g. Weekday evenings (6 - 9 PM), Weekend mornings"
              className="w-full text-xs sm:text-sm p-2.5 rounded-xl border border-slate-200"
            />
          </div>
        </div>

        {/* Save Bar */}
        <div className="flex items-center justify-between pt-2">
          <button
            type="button"
            onClick={() => {
              logout();
              onNavigate('landing');
            }}
            className="px-4 py-2.5 rounded-xl text-xs font-bold text-rose-600 hover:bg-rose-50 transition flex items-center gap-1.5"
          >
            <LogOut className="w-4 h-4" />
            <span>Sign Out Account</span>
          </button>

          <button
            type="submit"
            className="px-6 py-2.5 rounded-xl bg-brand-600 hover:bg-brand-700 text-white font-bold text-xs shadow-sm transition flex items-center gap-1.5"
          >
            <Save className="w-4 h-4" />
            <span>Save Preferences</span>
          </button>
        </div>
      </form>

      <AvatarPickerModal
        isOpen={avatarPickerOpen}
        onClose={() => setAvatarPickerOpen(false)}
        selectedAvatar={avatarId}
        onSelect={(id) => {
          setAvatarId(id);
          setAvatarPickerOpen(false);
        }}
      />
    </div>
  );
};
