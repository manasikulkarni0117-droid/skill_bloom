import React, { useState, useEffect } from 'react';
import {
  Sparkles, BookOpen, Users, Video, ShieldCheck, ArrowRight,
  Award, CheckCircle, GraduationCap, HeartHandshake, Compass,
  Laptop, Code, Atom
} from 'lucide-react';
import { useAuth, DEMO_USERS } from '../context/AuthContext';
import { AvatarBadge } from '../components/AvatarBadge';
import { subjectApi } from '../services/api';

export const LandingPage = ({ onStartLearning, onExploreSubjects, onSelectSubject }) => {
  const { switchAccount } = useAuth();
  const [popularSubjects, setPopularSubjects] = useState([]);

  useEffect(() => {
    subjectApi.getSubjects()
      .then(data => setPopularSubjects(data.slice(0, 8)))
      .catch(e => console.error(e));
  }, []);

  return (
    <div className="space-y-20 pb-20">
      {/* Hero Section */}
      <section className="relative overflow-hidden pt-12 pb-16 lg:pt-20 lg:pb-24">
        {/* Soft decorative background circles */}
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-gradient-to-br from-brand-100/60 via-purpleBrand-100/40 to-transparent rounded-full blur-3xl -z-10 pointer-events-none" />

        <div className="max-w-5xl mx-auto px-4 text-center space-y-6">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-brand-50 border border-brand-200/80 text-brand-800 text-xs font-bold tracking-wide shadow-2xs animate-fade-in">
            <span className="text-base">🌱</span>
            <span>Peer-to-Peer College Learning Platform</span>
          </div>

          <h1 className="text-4xl sm:text-6xl font-black text-slate-900 tracking-tight leading-tight sm:leading-none">
            Share Your Skills.{' '}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-brand-600 via-emerald-500 to-purpleBrand-600">
              Grow Together.
            </span>
          </h1>

          <p className="max-w-2xl mx-auto text-base sm:text-lg text-slate-600 leading-relaxed">
            Skill Bloom is an exclusive student-driven knowledge exchange. Teach subjects you master, get 1-on-1 mentorship from fellow peers on subjects you find difficult — with zero tuition fees.
          </p>

          <div className="flex flex-wrap items-center justify-center gap-3.5 pt-2">
            <button
              onClick={onStartLearning}
              className="px-7 py-3.5 rounded-2xl bg-brand-600 hover:bg-brand-700 text-white font-bold text-sm sm:text-base shadow-lg shadow-brand-600/25 transition-all transform hover:-translate-y-0.5 flex items-center gap-2"
            >
              <span>Start Learning Now</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <button
              onClick={onExploreSubjects}
              className="px-7 py-3.5 rounded-2xl bg-white hover:bg-slate-50 text-slate-700 font-bold text-sm sm:text-base border border-slate-200 shadow-sm transition-all"
            >
              Explore College Subjects
            </button>
          </div>

          {/* Quick Demo Pilot Accounts */}
          <div className="pt-8">
            <p className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3">
              Fast Evaluation • Try as any student:
            </p>
            <div className="flex flex-wrap justify-center gap-2 max-w-xl mx-auto">
              {DEMO_USERS.map((demo) => (
                <button
                  key={demo.email}
                  onClick={() => switchAccount(demo.email)}
                  className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-white border border-slate-200/80 shadow-2xs hover:border-brand-500 hover:bg-brand-50/50 transition-all text-xs text-left"
                >
                  <AvatarBadge avatarId={demo.avatar} size="xs" />
                  <div>
                    <span className="font-bold text-slate-800">{demo.name}</span>
                    <span className="block text-[10px] text-slate-500">{demo.role}</span>
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Core Mission Banner: NOT a tutor directory */}
      <section className="max-w-6xl mx-auto px-4">
        <div className="p-8 sm:p-10 rounded-3xl bg-gradient-to-br from-slate-900 to-slate-800 text-white shadow-xl relative overflow-hidden">
          <div className="absolute -right-10 -bottom-10 opacity-10 text-9xl">🎓</div>
          <div className="max-w-3xl space-y-3 relative z-10">
            <div className="inline-block px-3 py-1 rounded-lg bg-emerald-500/20 text-emerald-300 text-xs font-bold uppercase tracking-wider">
              Student-to-Student Mutual Collaboration
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
              A True Peer Learning Network, Not a Paid Tutor Directory
            </h2>
            <p className="text-slate-300 text-sm sm:text-base leading-relaxed">
              Every student possesses strong mastery in some areas (like DSA, Calculus, or Web Dev) while finding others challenging (like Operating Systems or Probability). Skill Bloom enables students to trade mastery, build genuine connections, and review each other after 1-on-1 collaborative sessions.
            </p>
          </div>
        </div>
      </section>

      {/* 4 Key Pillars */}
      <section className="max-w-6xl mx-auto px-4 space-y-8">
        <div className="text-center space-y-2">
          <h2 className="text-2xl sm:text-3xl font-black text-slate-900">
            How Skill Bloom Works
          </h2>
          <p className="text-sm text-slate-500 max-w-lg mx-auto">
            Structured, safe, and verifiable peer learning tailored for university curriculums.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <div className="p-6 rounded-3xl bg-white border border-slate-100 shadow-sm space-y-3 hover:shadow-md transition">
            <div className="w-12 h-12 rounded-2xl bg-brand-50 text-brand-600 flex items-center justify-center font-bold text-xl">
              1
            </div>
            <h3 className="font-bold text-slate-800 text-base">Select Subject to Learn</h3>
            <p className="text-xs text-slate-500 leading-relaxed">
              Pick what you need help with — from Data Structures and DBMS to Engineering Physics and Discrete Math.
            </p>
          </div>

          <div className="p-6 rounded-3xl bg-white border border-slate-100 shadow-sm space-y-3 hover:shadow-md transition">
            <div className="w-12 h-12 rounded-2xl bg-purpleBrand-50 text-purpleBrand-600 flex items-center justify-center font-bold text-xl">
              2
            </div>
            <h3 className="font-bold text-slate-800 text-base">Smart Compatibility Matching</h3>
            <p className="text-xs text-slate-500 leading-relaxed">
              Transparent algorithm ranks peer mentors based on verified assessments, feedback ratings, language, and schedule.
            </p>
          </div>

          <div className="p-6 rounded-3xl bg-white border border-slate-100 shadow-sm space-y-3 hover:shadow-md transition">
            <div className="w-12 h-12 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center font-bold text-xl">
              3
            </div>
            <h3 className="font-bold text-slate-800 text-base">Mutual Safe Connection</h3>
            <p className="text-xs text-slate-500 leading-relaxed">
              Zero unsolicited spam. Video calls and private chat unlock strictly after both students accept each other's connection.
            </p>
          </div>

          <div className="p-6 rounded-3xl bg-white border border-slate-100 shadow-sm space-y-3 hover:shadow-md transition">
            <div className="w-12 h-12 rounded-2xl bg-amber-50 text-amber-600 flex items-center justify-center font-bold text-xl">
              4
            </div>
            <h3 className="font-bold text-slate-800 text-base">Google Meet-Style Sessions</h3>
            <p className="text-xs text-slate-500 leading-relaxed">
              1-on-1 integrated video learning room with camera/mic toggles, screen sharing, real-time reviews, and badges.
            </p>
          </div>
        </div>
      </section>

      {/* Popular Subjects Showcase */}
      <section className="max-w-6xl mx-auto px-4 space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-black text-slate-900">Popular College Subjects</h2>
            <p className="text-xs text-slate-500">Jump right into ranked mentor discovery</p>
          </div>
          <button
            onClick={onExploreSubjects}
            className="text-xs font-bold text-brand-600 hover:text-brand-700 flex items-center gap-1"
          >
            <span>View All Subjects</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {popularSubjects.map((s) => (
            <button
              key={s.id}
              onClick={() => onSelectSubject(s)}
              className="p-5 rounded-3xl bg-white border border-slate-100 shadow-2xs hover:shadow-md hover:border-brand-300 text-left transition group space-y-2"
            >
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold px-2 py-0.5 rounded-lg bg-slate-100 text-slate-600">
                  {s.code || 'CORE'}
                </span>
                <span className="text-[11px] font-semibold text-brand-600">
                  Sem {s.semester_recommended}
                </span>
              </div>
              <h4 className="font-bold text-sm text-slate-800 group-hover:text-brand-600 transition">
                {s.name}
              </h4>
              <p className="text-[11px] text-slate-400 line-clamp-2">
                {s.description}
              </p>
              <div className="pt-2 flex items-center justify-between text-[11px] text-slate-500 border-t border-slate-50">
                <span>{s.teachers_count || 1} Peer Mentors</span>
                <span className="text-brand-600 font-bold group-hover:translate-x-0.5 transition-transform">Match →</span>
              </div>
            </button>
          ))}
        </div>
      </section>

      {/* Verification Transparency Callout */}
      <section className="max-w-4xl mx-auto px-4 text-center p-8 rounded-3xl bg-brand-50/60 border border-brand-200/60 space-y-3">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white text-emerald-800 text-xs font-bold shadow-2xs">
          <ShieldCheck className="w-4 h-4 text-emerald-600" />
          <span>Honest & Transparent Verification</span>
        </div>
        <h3 className="text-xl font-bold text-slate-800">
          Distinct Proof Labels You Can Trust
        </h3>
        <p className="text-xs sm:text-sm text-slate-600 max-w-xl mx-auto leading-relaxed">
          We strictly separate "Certificate Uploaded" from "Institution Verified". Files uploaded by students are never automatically stamped as university certified, preserving genuine academic integrity.
        </p>
      </section>
    </div>
  );
};
