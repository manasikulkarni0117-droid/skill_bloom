import React, { useState, useEffect } from 'react';
import {
  Users, UserCheck, Clock, Check, X, Shield, MessageSquare,
  Calendar, Ban, Flag, Trash2, ArrowRight, UserX
} from 'lucide-react';
import { connectionApi } from '../services/api';
import { AvatarBadge } from '../components/AvatarBadge';
import { ScheduleModal } from '../components/ScheduleModal';
import { ReportModal } from '../components/ReportModal';

export const ConnectionsPage = ({ onNavigate, onViewProfile }) => {
  const [activeTab, setActiveTab] = useState('incoming'); // incoming, outgoing, accepted
  const [data, setData] = useState({
    incoming_pending: [],
    outgoing_pending: [],
    accepted_peers: [],
    total_connections: 0
  });
  const [loading, setLoading] = useState(true);

  // Modals
  const [scheduleModalOpen, setScheduleModalOpen] = useState(false);
  const [reportModalOpen, setReportModalOpen] = useState(false);
  const [selectedPeer, setSelectedPeer] = useState(null);

  const loadConnections = async () => {
    try {
      setLoading(true);
      const res = await connectionApi.getConnections();
      setData(res);
      // Auto select tab if incoming has items
      if (res.incoming_pending?.length > 0) {
        setActiveTab('incoming');
      } else if (res.accepted_peers?.length > 0) {
        setActiveTab('accepted');
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadConnections();
  }, []);

  const handleAccept = async (id) => {
    try {
      await connectionApi.acceptRequest(id);
      loadConnections();
    } catch (e) {
      alert(e.message);
    }
  };

  const handleReject = async (id) => {
    try {
      await connectionApi.rejectRequest(id);
      loadConnections();
    } catch (e) {
      alert(e.message);
    }
  };

  const handleCancelOutgoing = async (id) => {
    try {
      await connectionApi.cancelRequest(id);
      loadConnections();
    } catch (e) {
      alert(e.message);
    }
  };

  const handleDisconnect = async (peerId) => {
    if (!confirm('Are you sure you want to disconnect from this student?')) return;
    try {
      await connectionApi.disconnect(peerId);
      loadConnections();
    } catch (e) {
      alert(e.message);
    }
  };

  return (
    <div className="space-y-8 pb-16 animate-fade-in max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      {/* Header */}
      <div>
        <h1 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">
          Student Connection Requests & Peers
        </h1>
        <p className="text-xs sm:text-sm text-slate-500 mt-1">
          Manage your peer study network. Video learning rooms and private chat unlock only with mutual acceptance.
        </p>
      </div>

      {/* Safety Policy Notice */}
      <div className="p-4 rounded-3xl bg-brand-50/70 border border-brand-200/80 flex items-start gap-3 text-xs text-brand-900">
        <Shield className="w-5 h-5 text-brand-600 shrink-0 mt-0.5" />
        <div>
          <span className="font-bold">Zero-Spam College Community Rule:</span>
          <p className="text-brand-800 text-[11px] leading-relaxed mt-0.5">
            Students cannot directly message or call strangers. Only after an incoming request is accepted by both peers are private chat channels and video classrooms enabled.
          </p>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="flex border-b border-slate-200 gap-2 sm:gap-6 overflow-x-auto pb-1">
        <button
          onClick={() => setActiveTab('incoming')}
          className={`pb-3 text-xs sm:text-sm font-bold flex items-center gap-2 border-b-2 transition whitespace-nowrap ${
            activeTab === 'incoming'
              ? 'border-brand-600 text-brand-600'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <span>Incoming Requests</span>
          {data.incoming_pending.length > 0 && (
            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-brand-600 text-white">
              {data.incoming_pending.length}
            </span>
          )}
        </button>

        <button
          onClick={() => setActiveTab('outgoing')}
          className={`pb-3 text-xs sm:text-sm font-bold flex items-center gap-2 border-b-2 transition whitespace-nowrap ${
            activeTab === 'outgoing'
              ? 'border-brand-600 text-brand-600'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <span>Outgoing Pending</span>
          {data.outgoing_pending.length > 0 && (
            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-slate-200 text-slate-700">
              {data.outgoing_pending.length}
            </span>
          )}
        </button>

        <button
          onClick={() => setActiveTab('accepted')}
          className={`pb-3 text-xs sm:text-sm font-bold flex items-center gap-2 border-b-2 transition whitespace-nowrap ${
            activeTab === 'accepted'
              ? 'border-brand-600 text-brand-600'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <span>Connected Peers</span>
          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-purpleBrand-100 text-purpleBrand-700">
            {data.accepted_peers.length}
          </span>
        </button>
      </div>

      {/* Tab Panels */}
      {loading ? (
        <div className="p-16 text-center text-slate-400 text-sm">Loading connections...</div>
      ) : activeTab === 'incoming' ? (
        data.incoming_pending.length === 0 ? (
          <div className="p-16 text-center rounded-3xl bg-white border border-slate-100 space-y-2">
            <Users className="w-10 h-10 text-slate-300 mx-auto" />
            <p className="text-sm font-bold text-slate-700">No incoming connection requests</p>
            <p className="text-xs text-slate-400">When other students request to learn with you, they will appear here.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {data.incoming_pending.map((req) => (
              <div
                key={req.id}
                className="p-5 rounded-3xl bg-white border border-slate-100 shadow-sm flex flex-col justify-between space-y-4"
              >
                <div className="space-y-3">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-center gap-3">
                      <AvatarBadge avatarId={req.sender_avatar} size="md" />
                      <div>
                        <button
                          onClick={() => onViewProfile(req.sender_id)}
                          className="font-bold text-sm text-slate-800 hover:text-brand-600 transition text-left"
                        >
                          {req.sender_name}
                        </button>
                        <span className="block text-xs text-slate-500">{req.sender_college}</span>
                        <span className="block text-[11px] text-slate-400">{req.sender_course}</span>
                      </div>
                    </div>
                  </div>

                  <div className="p-3 bg-slate-50 rounded-2xl border border-slate-100 text-xs text-slate-700 italic">
                    "{req.message}"
                  </div>
                </div>

                <div className="flex items-center justify-end gap-2.5 pt-2 border-t border-slate-100">
                  <button
                    onClick={() => handleReject(req.id)}
                    className="px-4 py-2 rounded-xl text-xs font-bold text-slate-600 hover:bg-slate-100 transition"
                  >
                    Decline
                  </button>
                  <button
                    onClick={() => handleAccept(req.id)}
                    className="px-5 py-2 rounded-xl text-xs font-bold text-white bg-brand-600 hover:bg-brand-700 shadow-sm transition"
                  >
                    Accept & Connect
                  </button>
                </div>
              </div>
            ))}
          </div>
        )
      ) : activeTab === 'outgoing' ? (
        data.outgoing_pending.length === 0 ? (
          <div className="p-16 text-center rounded-3xl bg-white border border-slate-100 space-y-2">
            <Clock className="w-10 h-10 text-slate-300 mx-auto" />
            <p className="text-sm font-bold text-slate-700">No outgoing requests pending</p>
            <p className="text-xs text-slate-400">Explore subjects to find peers and send connection requests!</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {data.outgoing_pending.map((req) => (
              <div
                key={req.id}
                className="p-5 rounded-3xl bg-white border border-slate-100 shadow-sm flex items-center justify-between gap-4"
              >
                <div className="flex items-center gap-3">
                  <AvatarBadge avatarId={req.receiver_avatar} size="md" />
                  <div>
                    <button
                      onClick={() => onViewProfile(req.receiver_id)}
                      className="font-bold text-sm text-slate-800 hover:text-brand-600 transition text-left"
                    >
                      {req.receiver_name}
                    </button>
                    <span className="block text-xs text-slate-400">Request sent • Pending response</span>
                    <p className="text-[11px] text-slate-500 italic mt-0.5 line-clamp-1">"{req.message}"</p>
                  </div>
                </div>

                <button
                  onClick={() => handleCancelOutgoing(req.id)}
                  className="px-3.5 py-1.5 rounded-xl border border-slate-200 text-xs font-bold text-slate-600 hover:bg-rose-50 hover:text-rose-600 hover:border-rose-200 transition"
                >
                  Cancel
                </button>
              </div>
            ))}
          </div>
        )
      ) : (
        /* Connected Peers Tab */
        data.accepted_peers.length === 0 ? (
          <div className="p-16 text-center rounded-3xl bg-white border border-slate-100 space-y-2">
            <UserCheck className="w-10 h-10 text-slate-300 mx-auto" />
            <p className="text-sm font-bold text-slate-700">No connected peers yet</p>
            <p className="text-xs text-slate-400">Accept incoming requests or explore subjects to connect with fellow students!</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {data.accepted_peers.map((peer) => (
              <div
                key={peer.peer_id}
                className="p-5 rounded-3xl bg-white border border-slate-100 shadow-sm hover:shadow-md transition space-y-4 flex flex-col justify-between"
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <AvatarBadge avatarId={peer.avatar_id} size="md" />
                    <div>
                      <button
                        onClick={() => onViewProfile(peer.peer_id)}
                        className="font-bold text-sm text-slate-800 hover:text-brand-600 transition text-left"
                      >
                        {peer.full_name}
                      </button>
                      <span className="block text-xs text-slate-500 truncate max-w-[160px]">{peer.college}</span>
                      <span className="block text-[11px] text-slate-400">{peer.course} (Sem {peer.semester})</span>
                    </div>
                  </div>

                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200">
                    Connected
                  </span>
                </div>

                <div className="pt-3 border-t border-slate-100 space-y-2">
                  <div className="flex items-center justify-between gap-2">
                    <button
                      onClick={() => onNavigate('chat')}
                      className="flex-1 py-2 rounded-xl bg-brand-50 text-brand-700 hover:bg-brand-100 text-xs font-bold transition flex items-center justify-center gap-1.5"
                    >
                      <MessageSquare className="w-3.5 h-3.5" />
                      <span>Chat</span>
                    </button>

                    <button
                      onClick={() => {
                        setSelectedPeer(peer);
                        setScheduleModalOpen(true);
                      }}
                      className="flex-1 py-2 rounded-xl bg-purpleBrand-50 text-purpleBrand-700 hover:bg-purpleBrand-100 text-xs font-bold transition flex items-center justify-center gap-1.5"
                    >
                      <Calendar className="w-3.5 h-3.5" />
                      <span>Schedule</span>
                    </button>
                  </div>

                  <div className="flex items-center justify-between pt-1 text-[11px]">
                    <button
                      onClick={() => handleDisconnect(peer.peer_id)}
                      className="text-slate-400 hover:text-rose-600 transition"
                    >
                      Disconnect
                    </button>
                    <button
                      onClick={() => {
                        setSelectedPeer(peer);
                        setReportModalOpen(true);
                      }}
                      className="text-slate-400 hover:text-amber-600 transition"
                    >
                      Report / Block
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )
      )}

      <ScheduleModal
        isOpen={scheduleModalOpen}
        onClose={() => setScheduleModalOpen(false)}
        peer={selectedPeer}
        onSuccess={() => onNavigate('sessions')}
      />

      <ReportModal
        isOpen={reportModalOpen}
        onClose={() => setReportModalOpen(false)}
        targetUser={selectedPeer}
        onSuccess={() => loadConnections()}
      />
    </div>
  );
};
