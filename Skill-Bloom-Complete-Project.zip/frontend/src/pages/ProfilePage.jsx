import React, { useState, useEffect } from 'react';
import {
  Edit3, Star, ShieldCheck, Plus, Trash2, Calendar, Award,
  BookOpen, Clock, Globe, GraduationCap, Lock, ExternalLink,
  MessageSquare, UserPlus, CheckCircle, AlertTriangle
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { AvatarBadge } from '../components/AvatarBadge';
import { VerificationBadge } from '../components/VerificationBadge';
import { AvatarPickerModal } from '../components/AvatarPickerModal';
import { ConnectModal } from '../components/ConnectModal';
import { ReportModal } from '../components/ReportModal';
import {
  profileApi, subjectApi, portfolioApi, connectionApi
} from '../services/api';

export const ProfilePage = ({
  targetUserId,
  onNavigate,
  onBack
}) => {
  const { user: currentUser, refreshProfile } = useAuth();
  const [profile, setProfile] = useState(null);
  const [allSubjects, setAllSubjects] = useState([]);
  const [loading, setLoading] = useState(true);
  const [isSelf, setIsSelf] = useState(false);

  // Edit profile state
  const [editModalOpen, setEditModalOpen] = useState(false);
  const [avatarPickerOpen, setAvatarPickerOpen] = useState(false);
  const [editBio, setEditBio] = useState('');
  const [editAvailability, setEditAvailability] = useState('');
  const [editLanguage, setEditLanguage] = useState('');
  const [editCollege, setEditCollege] = useState('');
  const [editCourse, setEditCourse] = useState('');
  const [editSemester, setEditSemester] = useState(4);
  const [editPrivacy, setEditPrivacy] = useState('connections_only');
  const [editAvatar, setEditAvatar] = useState('avatar-owl');

  // Add Skill / Goal state
  const [skillModalOpen, setSkillModalOpen] = useState(false);
  const [selectedSubjForSkill, setSelectedSubjForSkill] = useState('');
  const [skillProficiency, setSkillProficiency] = useState('Intermediate');
  const [skillNote, setSkillNote] = useState('');

  const [goalModalOpen, setGoalModalOpen] = useState(false);
  const [selectedSubjForGoal, setSelectedSubjForGoal] = useState('');
  const [goalUrgency, setGoalUrgency] = useState('Normal');

  // Modals for connecting or reporting
  const [connectModalOpen, setConnectModalOpen] = useState(false);
  const [reportModalOpen, setReportModalOpen] = useState(false);

  const loadProfile = async () => {
    try {
      setLoading(true);
      const isViewingSelf = !targetUserId || targetUserId === currentUser?.id;
      setIsSelf(isViewingSelf);

      const [data, subjects] = await Promise.all([
        isViewingSelf ? profileApi.getMyProfile() : profileApi.getUserProfile(targetUserId),
        subjectApi.getSubjects()
      ]);

      setProfile(data);
      setAllSubjects(subjects);

      if (isViewingSelf) {
        setEditBio(data.bio || '');
        setEditAvailability(data.availability || '');
        setEditLanguage(data.preferred_language || 'English');
        setEditCollege(data.college || '');
        setEditCourse(data.course || '');
        setEditSemester(data.semester || 4);
        setEditPrivacy(data.documents_privacy || 'connections_only');
        setEditAvatar(data.avatar_id || 'avatar-owl');
      }

      if (subjects.length > 0) {
        setSelectedSubjForSkill(subjects[0].id);
        setSelectedSubjForGoal(subjects[0].id);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadProfile();
  }, [targetUserId, currentUser]);

  const handleSaveProfile = async (e) => {
    e.preventDefault();
    try {
      await profileApi.updateMyProfile({
        avatar_id: editAvatar,
        bio: editBio,
        availability: editAvailability,
        preferred_language: editLanguage,
        college: editCollege,
        course: editCourse,
        semester: parseInt(editSemester),
        documents_privacy: editPrivacy
      });
      setEditModalOpen(false);
      await refreshProfile();
      loadProfile();
    } catch (e) {
      alert(e.message);
    }
  };

  const handleAddSkill = async (e) => {
    e.preventDefault();
    try {
      await profileApi.addTeachingSkill({
        subject_id: parseInt(selectedSubjForSkill),
        proficiency_level: skillProficiency,
        experience_note: skillNote.trim()
      });
      setSkillModalOpen(false);
      setSkillNote('');
      loadProfile();
    } catch (e) {
      alert(e.message);
    }
  };

  const handleRemoveSkill = async (id) => {
    if (!confirm('Remove this subject from your teaching list?')) return;
    try {
      await profileApi.removeTeachingSkill(id);
      loadProfile();
    } catch (e) {
      alert(e.message);
    }
  };

  const handleAddGoal = async (e) => {
    e.preventDefault();
    try {
      await profileApi.addLearningGoal({
        subject_id: parseInt(selectedSubjForGoal),
        urgency: goalUrgency
      });
      setGoalModalOpen(false);
      loadProfile();
    } catch (e) {
      alert(e.message);
    }
  };

  const handleRemoveGoal = async (id) => {
    if (!confirm('Remove this subject from your learning goals?')) return;
    try {
      await profileApi.removeLearningGoal(id);
      loadProfile();
    } catch (e) {
      alert(e.message);
    }
  };

  if (loading) {
    return <div className="p-16 text-center text-slate-400">Loading student profile...</div>;
  }

  if (!profile) {
    return <div className="p-16 text-center text-rose-500 font-bold">Profile not found.</div>;
  }

  return (
    <div className="space-y-8 pb-16 animate-fade-in max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      {/* Back button if viewing another student */}
      {!isSelf && onBack && (
        <button
          onClick={onBack}
          className="text-xs font-bold text-slate-500 hover:text-slate-800 transition"
        >
          ← Back
        </button>
      )}

      {/* Hero Profile Card */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-100 shadow-md relative overflow-hidden">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 relative z-10">
          <div className="flex flex-col sm:flex-row sm:items-center gap-5">
            <div className="relative">
              <AvatarBadge avatarId={profile.avatar_id} size="2xl" />
              {isSelf && (
                <button
                  onClick={() => setAvatarPickerOpen(true)}
                  className="absolute bottom-0 right-0 p-1.5 rounded-xl bg-white border border-slate-200 shadow-md text-slate-700 hover:text-brand-600 transition"
                  title="Change Avatar"
                >
                  <Edit3 className="w-4 h-4" />
                </button>
              )}
            </div>

            <div className="space-y-1.5">
              <div className="flex flex-wrap items-center gap-2">
                <h1 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">
                  {profile.full_name}
                </h1>
                {isSelf && (
                  <span className="text-[11px] font-bold px-2.5 py-0.5 rounded-full bg-brand-50 text-brand-700 border border-brand-200">
                    Your Profile
                  </span>
                )}
              </div>

              <p className="text-xs sm:text-sm font-semibold text-slate-600 flex items-center gap-1.5">
                <GraduationCap className="w-4 h-4 text-brand-600" />
                <span>{profile.college}</span>
              </p>

              <p className="text-xs text-slate-500">
                {profile.course} • Semester {profile.semester} • Learning in <strong>{profile.preferred_language}</strong>
              </p>

              <div className="flex flex-wrap items-center gap-3 pt-2 text-xs">
                <div className="flex items-center gap-1 font-bold text-slate-800">
                  <Star className="w-4 h-4 fill-amber-400 text-amber-400" />
                  <span>{profile.rating_avg}</span>
                  <span className="text-slate-400 font-normal">({profile.total_reviews} reviews)</span>
                </div>
                <span className="text-slate-300">•</span>
                <span className="text-slate-600 font-medium">
                  <strong>{profile.completed_sessions_count}</strong> sessions completed
                </span>
                <span className="text-slate-300">•</span>
                <span className="text-slate-500">
                  Privacy: {profile.documents_privacy === 'connections_only' ? 'Connected Peers Only' : profile.documents_privacy}
                </span>
              </div>
            </div>
          </div>

          {/* Action buttons */}
          <div className="flex flex-wrap items-center gap-2.5">
            {isSelf ? (
              <button
                onClick={() => setEditModalOpen(true)}
                className="px-5 py-2.5 rounded-2xl bg-brand-600 hover:bg-brand-700 text-white font-bold text-xs shadow-sm transition flex items-center gap-2"
              >
                <Edit3 className="w-4 h-4" />
                <span>Edit Profile</span>
              </button>
            ) : (
              <>
                {profile.connection_status_with_viewer === 'accepted' ? (
                  <button
                    onClick={() => onNavigate('chat')}
                    className="px-4 py-2.5 rounded-2xl bg-purpleBrand-50 text-purpleBrand-700 hover:bg-purpleBrand-100 font-bold text-xs transition flex items-center gap-2"
                  >
                    <MessageSquare className="w-4 h-4" />
                    <span>Private Chat</span>
                  </button>
                ) : profile.connection_status_with_viewer === 'pending_sent' ? (
                  <span className="px-4 py-2.5 rounded-2xl bg-amber-50 text-amber-700 font-bold text-xs border border-amber-200">
                    Connection Request Pending
                  </span>
                ) : (
                  <button
                    onClick={() => setConnectModalOpen(true)}
                    className="px-4 py-2.5 rounded-2xl bg-brand-600 hover:bg-brand-700 text-white font-bold text-xs shadow-sm transition flex items-center gap-2"
                  >
                    <UserPlus className="w-4 h-4" />
                    <span>Connect to Learn</span>
                  </button>
                )}

                <button
                  onClick={() => setReportModalOpen(true)}
                  className="p-2.5 rounded-2xl bg-slate-50 text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition border border-slate-200/60"
                  title="Report or Block"
                >
                  <AlertTriangle className="w-4 h-4" />
                </button>
              </>
            )}
          </div>
        </div>

        {/* Bio and Availability Section */}
        <div className="mt-6 pt-6 border-t border-slate-100 grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
          <div>
            <span className="font-bold text-slate-700 uppercase tracking-wider block mb-1">About Me</span>
            <p className="text-slate-600 leading-relaxed">{profile.bio || 'No bio provided yet.'}</p>
          </div>
          <div>
            <span className="font-bold text-slate-700 uppercase tracking-wider block mb-1">Study Availability</span>
            <p className="text-slate-600 leading-relaxed flex items-center gap-1.5">
              <Clock className="w-3.5 h-3.5 text-slate-400 shrink-0" />
              <span>{profile.availability || 'Flexible on weekends'}</span>
            </p>
          </div>
        </div>
      </div>

      {/* 2-Column Section: Skills Teaching & Goals Learning */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Subjects Can Teach */}
        <div className="bg-white rounded-3xl p-6 border border-slate-100 shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-base font-black text-slate-900 flex items-center gap-2">
              <GraduationCap className="w-5 h-5 text-brand-600" />
              <span>Subjects I Can Teach</span>
            </h2>
            {isSelf && (
              <button
                onClick={() => setSkillModalOpen(true)}
                className="text-xs font-bold text-brand-600 hover:underline flex items-center gap-1"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add Skill</span>
              </button>
            )}
          </div>

          {profile.skills_taught?.length === 0 ? (
            <p className="text-xs text-slate-400 italic py-4 text-center">No teaching skills listed yet.</p>
          ) : (
            <div className="space-y-3">
              {profile.skills_taught?.map((s) => (
                <div
                  key={s.id}
                  className="p-3.5 rounded-2xl bg-slate-50 border border-slate-100 flex items-start justify-between gap-3"
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-xs text-slate-800">{s.subject_name}</span>
                      <span className="text-[10px] font-semibold px-2 py-0.5 rounded-md bg-brand-50 text-brand-700">
                        {s.proficiency_level}
                      </span>
                    </div>
                    {s.experience_note && (
                      <p className="text-[11px] text-slate-500 italic">{s.experience_note}</p>
                    )}
                    <div className="pt-1">
                      <VerificationBadge status={s.verification_status} size="xs" />
                    </div>
                  </div>

                  {isSelf && (
                    <button
                      onClick={() => handleRemoveSkill(s.id)}
                      className="p-1 text-slate-400 hover:text-rose-600 transition"
                      title="Remove skill"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Subjects Want to Learn */}
        <div className="bg-white rounded-3xl p-6 border border-slate-100 shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-base font-black text-slate-900 flex items-center gap-2">
              <BookOpen className="w-5 h-5 text-purpleBrand-600" />
              <span>Subjects I Want to Learn</span>
            </h2>
            {isSelf && (
              <button
                onClick={() => setGoalModalOpen(true)}
                className="text-xs font-bold text-purpleBrand-600 hover:underline flex items-center gap-1"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add Goal</span>
              </button>
            )}
          </div>

          {profile.learning_goals?.length === 0 ? (
            <p className="text-xs text-slate-400 italic py-4 text-center">No learning goals listed yet.</p>
          ) : (
            <div className="space-y-3">
              {profile.learning_goals?.map((g) => (
                <div
                  key={g.id}
                  className="p-3.5 rounded-2xl bg-purpleBrand-50/50 border border-purpleBrand-100 flex items-start justify-between gap-3"
                >
                  <div>
                    <span className="font-bold text-xs text-slate-800">{g.subject_name}</span>
                    <span className="block text-[11px] text-purpleBrand-700 font-medium">
                      Urgency: {g.urgency} • Pace: {g.preferred_pace}
                    </span>
                  </div>

                  {isSelf && (
                    <button
                      onClick={() => handleRemoveGoal(g.id)}
                      className="p-1 text-slate-400 hover:text-rose-600 transition"
                      title="Remove goal"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Verified Certificates & Portfolio Items */}
      <div className="bg-white rounded-3xl p-6 border border-slate-100 shadow-sm space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-base font-black text-slate-900 flex items-center gap-2">
              <Award className="w-5 h-5 text-amber-500" />
              <span>Certificates & Project Evidence</span>
            </h2>
            <p className="text-xs text-slate-400">Verifiable academic proof and capstone code repositories</p>
          </div>
          {isSelf && (
            <button
              onClick={() => onNavigate('portfolio')}
              className="text-xs font-bold text-brand-600 hover:underline"
            >
              Manage Portfolio →
            </button>
          )}
        </div>

        {profile.portfolio_items?.length === 0 ? (
          <div className="p-8 text-center bg-slate-50 rounded-2xl text-slate-400 text-xs">
            {profile.documents_privacy === 'connections_only' && !isSelf
              ? 'Document evidence is restricted to connected students.'
              : 'No certificates or projects uploaded yet.'}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {profile.portfolio_items?.map((item) => (
              <div
                key={item.id}
                className="p-4 rounded-2xl border border-slate-100 bg-slate-50 space-y-2 flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                      {item.item_type}
                    </span>
                    <VerificationBadge status={item.verification_status} size="xs" />
                  </div>
                  <h4 className="font-bold text-xs text-slate-800 mt-1">{item.title}</h4>
                  <p className="text-[11px] text-slate-500">{item.issuing_organization}</p>
                  {item.description && (
                    <p className="text-[11px] text-slate-600 italic mt-1 line-clamp-2">{item.description}</p>
                  )}
                </div>

                <div className="pt-2 flex items-center gap-3 text-xs font-semibold">
                  {item.github_url && (
                    <a
                      href={item.github_url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-purpleBrand-600 hover:underline flex items-center gap-1"
                    >
                      <ExternalLink className="w-3 h-3" />
                      <span>GitHub</span>
                    </a>
                  )}
                  {item.file_path && (
                    <a
                      href={portfolioApi.getDownloadUrl(item.id)}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-brand-600 hover:underline flex items-center gap-1"
                    >
                      <span>View File</span>
                    </a>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Peer Reviews & Ratings Showcase */}
      <div className="bg-white rounded-3xl p-6 border border-slate-100 shadow-sm space-y-4">
        <h2 className="text-base font-black text-slate-900 flex items-center gap-2">
          <Star className="w-5 h-5 fill-amber-400 text-amber-400" />
          <span>Student Feedback ({profile.reviews?.length || 0})</span>
        </h2>

        {profile.reviews?.length === 0 ? (
          <p className="text-xs text-slate-400 italic py-4 text-center">No peer reviews received yet.</p>
        ) : (
          <div className="space-y-3">
            {profile.reviews?.map((r) => (
              <div key={r.id} className="p-4 rounded-2xl bg-slate-50 border border-slate-100 space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <AvatarBadge avatarId={r.reviewer_avatar} size="xs" />
                    <span className="font-bold text-xs text-slate-800">{r.reviewer_name}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    {[1, 2, 3, 4, 5].map((st) => (
                      <Star
                        key={st}
                        className={`w-3.5 h-3.5 ${st <= r.rating ? 'fill-amber-400 text-amber-400' : 'text-slate-200'}`}
                      />
                    ))}
                  </div>
                </div>

                <p className="text-xs text-slate-700 leading-relaxed">{r.feedback}</p>

                <div className="flex items-center gap-3 text-[10px] text-slate-400 pt-1">
                  <span>Teaching Clarity: <strong>{r.teaching_clarity}/5</strong></span>
                  <span>•</span>
                  <span>Helpfulness: <strong>{r.helpfulness}/5</strong></span>
                  <span>•</span>
                  <span>Punctuality: <strong>{r.punctuality}/5</strong></span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Edit Profile Modal */}
      {editModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-sm animate-fade-in">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-slate-100 max-h-[90vh] overflow-y-auto">
            <h3 className="font-bold text-slate-900 text-lg">Edit Student Profile</h3>

            <form onSubmit={handleSaveProfile} className="space-y-3.5 my-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">College</label>
                <input
                  type="text"
                  required
                  value={editCollege}
                  onChange={(e) => setEditCollege(e.target.value)}
                  className="w-full text-sm p-2 rounded-xl border border-slate-200"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Course</label>
                  <input
                    type="text"
                    required
                    value={editCourse}
                    onChange={(e) => setEditCourse(e.target.value)}
                    className="w-full text-sm p-2 rounded-xl border border-slate-200"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Semester</label>
                  <select
                    value={editSemester}
                    onChange={(e) => setEditSemester(e.target.value)}
                    className="w-full text-sm p-2 rounded-xl border border-slate-200"
                  >
                    {[1, 2, 3, 4, 5, 6, 7, 8].map(s => (
                      <option key={s} value={s}>Semester {s}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Learning Language</label>
                <input
                  type="text"
                  value={editLanguage}
                  onChange={(e) => setEditLanguage(e.target.value)}
                  className="w-full text-sm p-2 rounded-xl border border-slate-200"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Weekly Availability</label>
                <input
                  type="text"
                  value={editAvailability}
                  onChange={(e) => setEditAvailability(e.target.value)}
                  placeholder="e.g. Weekday evenings, Saturday mornings"
                  className="w-full text-sm p-2 rounded-xl border border-slate-200"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Bio / Student Intro</label>
                <textarea
                  rows={3}
                  value={editBio}
                  onChange={(e) => setEditBio(e.target.value)}
                  className="w-full text-sm p-2 rounded-xl border border-slate-200"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Document Privacy Setting</label>
                <select
                  value={editPrivacy}
                  onChange={(e) => setEditPrivacy(e.target.value)}
                  className="w-full text-sm p-2 rounded-xl border border-slate-200"
                >
                  <option value="connections_only">Connected Peers Only (Recommended)</option>
                  <option value="public">Public (All verified students)</option>
                  <option value="private">Private (Only me)</option>
                </select>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setEditModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-xs font-bold text-slate-600 hover:bg-slate-100"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl text-xs font-bold text-white bg-brand-600 hover:bg-brand-700 shadow-sm"
                >
                  Save Profile
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Add Teaching Skill Modal */}
      {skillModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-sm animate-fade-in">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-100">
            <h3 className="font-bold text-slate-900 text-lg">Add Subject I Can Teach</h3>

            <form onSubmit={handleAddSkill} className="space-y-3.5 my-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Subject</label>
                <select
                  value={selectedSubjForSkill}
                  onChange={(e) => setSelectedSubjForSkill(e.target.value)}
                  className="w-full text-sm p-2 rounded-xl border border-slate-200"
                >
                  {allSubjects.map(s => (
                    <option key={s.id} value={s.id}>{s.name} ({s.category})</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Proficiency Level</label>
                <select
                  value={skillProficiency}
                  onChange={(e) => setSkillProficiency(e.target.value)}
                  className="w-full text-sm p-2 rounded-xl border border-slate-200"
                >
                  <option value="Beginner">Beginner (Can explain basics)</option>
                  <option value="Intermediate">Intermediate (Comfortable with lab & theory)</option>
                  <option value="Advanced">Advanced (Top grades & project experience)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Experience Note</label>
                <input
                  type="text"
                  value={skillNote}
                  onChange={(e) => setSkillNote(e.target.value)}
                  placeholder="e.g. Scored 90%+ in semester exam; built capstone project"
                  className="w-full text-sm p-2 rounded-xl border border-slate-200"
                />
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setSkillModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-xs font-bold text-slate-600 hover:bg-slate-100"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl text-xs font-bold text-white bg-brand-600 hover:bg-brand-700"
                >
                  Save Skill
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Add Learning Goal Modal */}
      {goalModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-sm animate-fade-in">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-100">
            <h3 className="font-bold text-slate-900 text-lg">Add Subject I Want to Learn</h3>

            <form onSubmit={handleAddGoal} className="space-y-3.5 my-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Subject</label>
                <select
                  value={selectedSubjForGoal}
                  onChange={(e) => setSelectedSubjForGoal(e.target.value)}
                  className="w-full text-sm p-2 rounded-xl border border-slate-200"
                >
                  {allSubjects.map(s => (
                    <option key={s.id} value={s.id}>{s.name} ({s.category})</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Urgency</label>
                <select
                  value={goalUrgency}
                  onChange={(e) => setGoalUrgency(e.target.value)}
                  className="w-full text-sm p-2 rounded-xl border border-slate-200"
                >
                  <option value="Normal">Normal Pace</option>
                  <option value="Exam Preparation">Exam Preparation</option>
                  <option value="Project Deadline">Project Deadline</option>
                </select>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setGoalModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-xs font-bold text-slate-600 hover:bg-slate-100"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl text-xs font-bold text-white bg-purpleBrand-600 hover:bg-purpleBrand-700"
                >
                  Save Goal
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      <AvatarPickerModal
        isOpen={avatarPickerOpen}
        onClose={() => setAvatarPickerOpen(false)}
        selectedAvatar={profile.avatar_id}
        onSelect={async (id) => {
          setEditAvatar(id);
          await profileApi.updateMyProfile({ avatar_id: id });
          await refreshProfile();
          loadProfile();
          setAvatarPickerOpen(false);
        }}
      />

      <ConnectModal
        isOpen={connectModalOpen}
        onClose={() => setConnectModalOpen(false)}
        targetUser={profile}
        onSuccess={() => loadProfile()}
      />

      <ReportModal
        isOpen={reportModalOpen}
        onClose={() => setReportModalOpen(false)}
        targetUser={profile}
        onSuccess={() => {
          alert('Report submitted.');
          if (onBack) onBack();
        }}
      />
    </div>
  );
};
