import React, { useState, useEffect } from 'react';
import {
  ArrowLeft, Filter, Star, ShieldCheck, CheckCircle2,
  Calendar, Clock, UserPlus, MessageSquare, Award,
  Info, Sparkles, BookOpen, ChevronRight, SlidersHorizontal
} from 'lucide-react';
import { matchingApi } from '../services/api';
import { AvatarBadge } from '../components/AvatarBadge';
import { VerificationBadge } from '../components/VerificationBadge';
import { MatchScoreCard } from '../components/MatchScoreCard';
import { ConnectModal } from '../components/ConnectModal';

export const RankedResultsPage = ({
  subject,
  onBack,
  onViewPeerProfile,
  onNavigate
}) => {
  const [rankedMentors, setRankedMentors] = useState([]);
  const [loading, setLoading] = useState(true);

  // Filters
  const [proficiencyFilter, setProficiencyFilter] = useState('All');
  const [courseFilter, setCourseFilter] = useState('');
  const [languageFilter, setLanguageFilter] = useState('');
  const [minRatingFilter, setMinRatingFilter] = useState('');
  const [availabilityFilter, setAvailabilityFilter] = useState('');
  const [showFilterDrawer, setShowFilterDrawer] = useState(false);

  // Connect modal
  const [connectModalOpen, setConnectModalOpen] = useState(false);
  const [selectedPeer, setSelectedPeer] = useState(null);

  const fetchRanked = async () => {
    if (!subject) return;
    try {
      setLoading(true);
      const data = await matchingApi.getRankedMentors(subject.id, {
        proficiency: proficiencyFilter,
        course: courseFilter,
        language: languageFilter,
        minRating: minRatingFilter ? parseFloat(minRatingFilter) : undefined,
        availability: availabilityFilter
      });
      setRankedMentors(data || []);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchRanked();
  }, [subject, proficiencyFilter, courseFilter, languageFilter, minRatingFilter, availabilityFilter]);

  if (!subject) {
    return (
      <div className="p-12 text-center">
        <p className="text-slate-500">No subject selected.</p>
        <button onClick={onBack} className="mt-2 text-brand-600 font-bold text-sm">
          ← Back to Explore Subjects
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-8 pb-16 animate-fade-in max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      {/* Top Breadcrumb & Subject Banner */}
      <div>
        <button
          onClick={onBack}
          className="inline-flex items-center gap-1.5 text-xs font-bold text-slate-500 hover:text-slate-800 transition mb-3"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Subjects</span>
        </button>

        <div className="p-6 sm:p-8 rounded-3xl bg-gradient-to-r from-slate-900 to-slate-800 text-white shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-1.5">
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-md bg-white/20 text-[11px] font-bold">
                {subject.code || 'COLLEGE'}
              </span>
              <span className="px-2.5 py-0.5 rounded-md bg-brand-500/30 text-brand-300 text-[11px] font-bold">
                {subject.category}
              </span>
              <span className="text-slate-400 text-xs">
                Semester {subject.semester_recommended}
              </span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-black tracking-tight">
              Peer Mentors for {subject.name}
            </h1>
            <p className="text-xs sm:text-sm text-slate-300 max-w-2xl leading-relaxed">
              {subject.description || 'Explore college peers ready to share their problem-solving techniques and study roadmaps.'}
            </p>
          </div>

          <div className="bg-white/10 p-4 rounded-2xl border border-white/10 shrink-0 text-center">
            <span className="block text-2xl font-black text-brand-400">{rankedMentors.length}</span>
            <span className="block text-[11px] font-semibold text-slate-300 uppercase tracking-wider">
              Available Peer Mentors
            </span>
          </div>
        </div>
      </div>

      {/* Main Layout: Filters & Ranked Mentors List */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        {/* Filters Sidebar */}
        <div className="lg:col-span-1 space-y-5">
          <div className="bg-white p-5 rounded-3xl border border-slate-100 shadow-sm space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
                <SlidersHorizontal className="w-3.5 h-3.5 text-brand-600" />
                <span>Filters & Ranking</span>
              </h3>
              {(proficiencyFilter !== 'All' || courseFilter || languageFilter || minRatingFilter || availabilityFilter) && (
                <button
                  onClick={() => {
                    setProficiencyFilter('All');
                    setCourseFilter('');
                    setLanguageFilter('');
                    setMinRatingFilter('');
                    setAvailabilityFilter('');
                  }}
                  className="text-[11px] text-brand-600 font-bold hover:underline"
                >
                  Reset
                </button>
              )}
            </div>

            {/* Proficiency Level */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                Subject Proficiency Level
              </label>
              <div className="space-y-1">
                {['All', 'Advanced', 'Intermediate', 'Beginner'].map((level) => (
                  <label
                    key={level}
                    className={`flex items-center justify-between p-2 rounded-xl text-xs font-medium cursor-pointer transition ${
                      proficiencyFilter === level
                        ? 'bg-brand-50 text-brand-700 font-bold'
                        : 'text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    <span>{level === 'All' ? 'Any Proficiency' : level}</span>
                    <input
                      type="radio"
                      name="proficiency"
                      checked={proficiencyFilter === level}
                      onChange={() => setProficiencyFilter(level)}
                      className="accent-brand-600"
                    />
                  </label>
                ))}
              </div>
            </div>

            {/* Minimum Rating */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Minimum Peer Rating
              </label>
              <select
                value={minRatingFilter}
                onChange={(e) => setMinRatingFilter(e.target.value)}
                className="w-full text-xs p-2.5 rounded-xl border border-slate-200 bg-white focus:outline-none focus:ring-2 focus:ring-brand-500"
              >
                <option value="">Any Rating</option>
                <option value="4.5">4.5+ Stars</option>
                <option value="4.8">4.8+ Stars (Top Rated)</option>
              </select>
            </div>

            {/* Course Filter */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Course / Major
              </label>
              <input
                type="text"
                value={courseFilter}
                onChange={(e) => setCourseFilter(e.target.value)}
                placeholder="e.g. Computer Science, BCA"
                className="w-full text-xs p-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-brand-500"
              />
            </div>

            {/* Preferred Language */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Preferred Language
              </label>
              <input
                type="text"
                value={languageFilter}
                onChange={(e) => setLanguageFilter(e.target.value)}
                placeholder="e.g. English, Hindi"
                className="w-full text-xs p-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-brand-500"
              />
            </div>

            {/* Availability */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Availability Keyword
              </label>
              <input
                type="text"
                value={availabilityFilter}
                onChange={(e) => setAvailabilityFilter(e.target.value)}
                placeholder="e.g. Weekend, Evening"
                className="w-full text-xs p-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-brand-500"
              />
            </div>
          </div>

          {/* Transparent Algorithm Note */}
          <div className="p-4 rounded-3xl bg-slate-50 border border-slate-200/70 text-xs space-y-2">
            <div className="flex items-center gap-1.5 font-bold text-slate-800">
              <Sparkles className="w-4 h-4 text-brand-600" />
              <span>Smart Ranking Principles</span>
            </div>
            <p className="text-[11px] text-slate-500 leading-relaxed">
              Mentors are ranked using a multi-factor score: verified assessments, student review ratings, completed sessions, course synergy, and availability. Ratings alone do not dictate rank.
            </p>
          </div>
        </div>

        {/* Results List */}
        <div className="lg:col-span-3 space-y-4">
          {loading ? (
            <div className="p-12 text-center text-slate-400 text-sm">
              Calculating compatibility scores & rankings...
            </div>
          ) : rankedMentors.length === 0 ? (
            <div className="p-12 text-center rounded-3xl bg-white border border-slate-100 space-y-3">
              <Award className="w-10 h-10 text-slate-300 mx-auto" />
              <h3 className="font-bold text-slate-700">No mentors match your current filter criteria</h3>
              <p className="text-xs text-slate-400">Try resetting filters or adjusting search parameters.</p>
            </div>
          ) : (
            rankedMentors.map((cand) => (
              <div
                key={cand.user_id}
                className="p-6 rounded-3xl bg-white border border-slate-100 shadow-2xs hover:shadow-md hover:border-slate-200 transition space-y-5"
              >
                <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
                  {/* Student Info */}
                  <div className="flex items-start gap-4">
                    <AvatarBadge avatarId={cand.avatar_id} size="lg" />
                    <div className="space-y-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <button
                          onClick={() => onViewPeerProfile(cand.user_id)}
                          className="text-base font-black text-slate-900 hover:text-brand-600 transition"
                        >
                          {cand.full_name}
                        </button>
                        <VerificationBadge status={cand.verification_status} size="sm" />
                        <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-slate-100 text-slate-700">
                          {cand.subject_proficiency}
                        </span>
                      </div>

                      <p className="text-xs text-slate-500">
                        {cand.college} • {cand.course} (Sem {cand.semester})
                      </p>

                      <div className="flex flex-wrap items-center gap-3 pt-1 text-xs">
                        <div className="flex items-center gap-1 font-bold text-slate-700">
                          <Star className="w-4 h-4 fill-amber-400 text-amber-400" />
                          <span>{cand.rating_avg}</span>
                          <span className="text-slate-400 font-normal">({cand.total_reviews} reviews)</span>
                        </div>
                        <span className="text-slate-300">•</span>
                        <span className="text-slate-600 font-medium">
                          {cand.completed_sessions_count} sessions taught
                        </span>
                        <span className="text-slate-300">•</span>
                        <span className="text-slate-600 font-medium">
                          Speaks: {cand.preferred_language}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Compatibility Score Card */}
                  <div className="sm:w-64">
                    <MatchScoreCard
                      percentage={cand.estimated_match_percentage}
                      rank={cand.rank}
                      breakdown={cand.score_breakdown}
                    />
                  </div>
                </div>

                {/* Footer Action Bar */}
                <div className="pt-4 border-t border-slate-100 flex flex-wrap items-center justify-between gap-3">
                  <div className="text-xs text-slate-500 flex items-center gap-2">
                    <Clock className="w-4 h-4 text-slate-400" />
                    <span><strong>Availability:</strong> {cand.availability}</span>
                  </div>

                  <div className="flex items-center gap-2.5">
                    <button
                      onClick={() => onViewPeerProfile(cand.user_id)}
                      className="px-4 py-2 rounded-xl text-xs font-bold text-slate-700 hover:bg-slate-100 transition border border-slate-200"
                    >
                      View Profile & Proof
                    </button>

                    {cand.connection_status === 'accepted' ? (
                      <button
                        onClick={() => onNavigate('chat')}
                        className="px-4 py-2 rounded-xl bg-purpleBrand-50 text-purpleBrand-700 font-bold text-xs hover:bg-purpleBrand-100 transition flex items-center gap-1.5"
                      >
                        <MessageSquare className="w-3.5 h-3.5" />
                        <span>Chat & Learn</span>
                      </button>
                    ) : cand.connection_status === 'pending_sent' ? (
                      <span className="px-4 py-2 rounded-xl bg-amber-50 text-amber-700 font-bold text-xs border border-amber-200">
                        Request Pending
                      </span>
                    ) : (
                      <button
                        onClick={() => {
                          setSelectedPeer(cand);
                          setConnectModalOpen(true);
                        }}
                        className="px-4 py-2 rounded-xl bg-brand-600 hover:bg-brand-700 text-white font-bold text-xs shadow-sm transition flex items-center gap-1.5"
                      >
                        <UserPlus className="w-3.5 h-3.5" />
                        <span>Connect to Learn</span>
                      </button>
                    )}
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>

      <ConnectModal
        isOpen={connectModalOpen}
        onClose={() => setConnectModalOpen(false)}
        targetUser={selectedPeer}
        onSuccess={() => fetchRanked()}
      />
    </div>
  );
};
