import React, { useState, useEffect, useRef } from 'react';
import {
  Send, MessageSquare, Calendar, Video, Shield,
  Clock, Check, CheckCheck, Smile, ArrowLeft
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { chatApi, connectionApi } from '../services/api';
import { AvatarBadge } from '../components/AvatarBadge';
import { ScheduleModal } from '../components/ScheduleModal';

export const ChatPage = ({ onStartVideoCall, onNavigate }) => {
  const { user } = useAuth();
  const [conversations, setConversations] = useState([]);
  const [selectedPeerId, setSelectedPeerId] = useState(null);
  const [selectedConversation, setSelectedConversation] = useState(null);
  const [messages, setMessages] = useState([]);
  const [newMessage, setNewMessage] = useState('');
  const [loadingConvs, setLoadingConvs] = useState(true);
  const [loadingMessages, setLoadingMessages] = useState(false);
  const [scheduleModalOpen, setScheduleModalOpen] = useState(false);

  const messagesEndRef = useRef(null);
  const socketRef = useRef(null);

  // Load conversations
  const loadConversations = async (autoSelectFirst = true) => {
    try {
      setLoadingConvs(true);
      const convList = await chatApi.getConversations();
      setConversations(convList || []);

      if (convList && convList.length > 0 && autoSelectFirst && !selectedPeerId) {
        setSelectedPeerId(convList[0].peer_user_id);
        setSelectedConversation(convList[0]);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoadingConvs(false);
    }
  };

  // Load messages for selected peer
  const loadMessages = async (peerId) => {
    if (!peerId) return;
    try {
      setLoadingMessages(true);
      const msgs = await chatApi.getMessages(peerId);
      setMessages(msgs || []);
    } catch (e) {
      console.error(e);
    } finally {
      setLoadingMessages(false);
    }
  };

  useEffect(() => {
    loadConversations();
  }, [user]);

  useEffect(() => {
    if (selectedPeerId) {
      const conv = conversations.find(c => c.peer_user_id === selectedPeerId);
      setSelectedConversation(conv);
      loadMessages(selectedPeerId);
    }
  }, [selectedPeerId]);

  // Scroll to bottom on new messages
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // WebSocket for real-time messages
  useEffect(() => {
    if (!user) return;
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const wsUrl = `${protocol}//${window.location.host}/ws/chat/${user.id}`;
    const ws = new WebSocket(wsUrl);
    socketRef.current = ws;

    ws.onmessage = (event) => {
      try {
        const payload = JSON.parse(event.data);
        if (payload.type === 'new_message' && payload.message) {
          if (payload.message.sender_id === selectedPeerId || payload.message.receiver_id === selectedPeerId) {
            setMessages(prev => [...prev, payload.message]);
          }
          loadConversations(false);
        }
      } catch (e) {
        // ignore
      }
    };

    return () => {
      ws.close();
    };
  }, [user, selectedPeerId]);

  const handleSendMessage = async (e) => {
    e.preventDefault();
    if (!newMessage.trim() || !selectedPeerId) return;

    const content = newMessage.trim();
    setNewMessage('');

    try {
      const sentMsg = await chatApi.sendMessage(selectedPeerId, content);
      setMessages(prev => [...prev, sentMsg]);
      loadConversations(false);
    } catch (err) {
      alert(err.message || 'Failed to send message');
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-12 animate-fade-in">
      <div className="bg-white rounded-3xl border border-slate-100 shadow-md overflow-hidden grid grid-cols-1 md:grid-cols-3 h-[750px] max-h-[85vh]">
        {/* Left Sidebar: Conversations */}
        <div className={`md:col-span-1 border-r border-slate-100 flex flex-col h-full bg-slate-50/50 ${selectedPeerId ? 'hidden md:flex' : 'flex'}`}>
          <div className="p-4 border-b border-slate-100 bg-white">
            <h2 className="text-base font-black text-slate-800 flex items-center justify-between">
              <span>Connected Chats</span>
              <span className="text-[11px] font-bold px-2 py-0.5 rounded-full bg-brand-50 text-brand-700">
                {conversations.length} Active
              </span>
            </h2>
            <p className="text-[11px] text-slate-400 mt-0.5">Direct chat unlocked with connected peers</p>
          </div>

          <div className="flex-1 overflow-y-auto divide-y divide-slate-100/60 p-2 space-y-1">
            {loadingConvs ? (
              <div className="p-8 text-center text-slate-400 text-xs">Loading conversations...</div>
            ) : conversations.length === 0 ? (
              <div className="p-8 text-center space-y-2">
                <MessageSquare className="w-8 h-8 text-slate-300 mx-auto" />
                <p className="text-xs font-bold text-slate-600">No active chats</p>
                <p className="text-[11px] text-slate-400">Accept student connection requests to unlock private chat!</p>
                <button
                  onClick={() => onNavigate('connections')}
                  className="mt-2 text-xs font-bold text-brand-600 hover:underline"
                >
                  View Connections →
                </button>
              </div>
            ) : (
              conversations.map((c) => {
                const isSelected = c.peer_user_id === selectedPeerId;
                return (
                  <button
                    key={c.id}
                    onClick={() => setSelectedPeerId(c.peer_user_id)}
                    className={`w-full p-3 rounded-2xl flex items-center gap-3 text-left transition ${
                      isSelected
                        ? 'bg-white shadow-sm ring-1 ring-slate-200'
                        : 'hover:bg-white/80'
                    }`}
                  >
                    <AvatarBadge avatarId={c.peer_avatar} size="sm" />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-xs text-slate-800 truncate">{c.peer_name}</span>
                        {c.unread_count > 0 && (
                          <span className="w-4 h-4 rounded-full bg-brand-600 text-white text-[10px] font-bold flex items-center justify-center">
                            {c.unread_count}
                          </span>
                        )}
                      </div>
                      <p className="text-[11px] text-slate-500 truncate mt-0.5">{c.last_message}</p>
                    </div>
                  </button>
                );
              })
            )}
          </div>
        </div>

        {/* Right Panel: Active Chat Room */}
        <div className={`md:col-span-2 flex flex-col h-full bg-white ${!selectedPeerId ? 'hidden md:flex' : 'flex'}`}>
          {selectedConversation ? (
            <>
              {/* Header */}
              <div className="p-4 border-b border-slate-100 flex items-center justify-between bg-white z-10 shadow-2xs">
                <div className="flex items-center gap-3">
                  <button
                    onClick={() => setSelectedPeerId(null)}
                    className="md:hidden p-1.5 rounded-lg text-slate-500 hover:bg-slate-100"
                  >
                    <ArrowLeft className="w-5 h-5" />
                  </button>
                  <AvatarBadge avatarId={selectedConversation.peer_avatar} size="sm" />
                  <div>
                    <h3 className="font-bold text-sm text-slate-900">{selectedConversation.peer_name}</h3>
                    <p className="text-[11px] text-slate-400">
                      {selectedConversation.peer_college} • {selectedConversation.peer_course}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setScheduleModalOpen(true)}
                    className="px-3.5 py-1.5 rounded-xl bg-purpleBrand-50 text-purpleBrand-700 hover:bg-purpleBrand-100 font-bold text-xs flex items-center gap-1.5 transition"
                  >
                    <Calendar className="w-3.5 h-3.5" />
                    <span className="hidden sm:inline">Schedule Session</span>
                  </button>

                  <button
                    onClick={() => onStartVideoCall({
                      meeting_room_id: `sb-direct-${Math.min(user.id, selectedPeerId)}-${Math.max(user.id, selectedPeerId)}`,
                      title: `Video Call with ${selectedConversation.peer_name}`,
                      host_name: user.full_name,
                      learner_name: selectedConversation.peer_name,
                      is_host: true
                    })}
                    className="px-3.5 py-1.5 rounded-xl bg-brand-600 hover:bg-brand-700 text-white font-bold text-xs flex items-center gap-1.5 shadow-sm transition"
                  >
                    <Video className="w-3.5 h-3.5" />
                    <span className="hidden sm:inline">Video Call</span>
                  </button>
                </div>
              </div>

              {/* Message History */}
              <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-3 bg-slate-50/30">
                <div className="text-center my-2">
                  <span className="inline-flex items-center gap-1.5 text-[11px] text-slate-400 bg-white px-3 py-1 rounded-full border border-slate-100 shadow-2xs">
                    <Shield className="w-3 h-3 text-emerald-600" />
                    <span>End-to-end verified peer student conversation</span>
                  </span>
                </div>

                {loadingMessages ? (
                  <div className="p-8 text-center text-slate-400 text-xs">Loading message history...</div>
                ) : messages.length === 0 ? (
                  <div className="p-12 text-center text-slate-400 text-xs">
                    No messages exchanged yet. Say hello and introduce what you'd like to learn!
                  </div>
                ) : (
                  messages.map((m) => {
                    const isMe = m.sender_id === user.id;
                    const timeStr = new Date(m.created_at).toLocaleTimeString([], {
                      hour: '2-digit',
                      minute: '2-digit'
                    });

                    return (
                      <div
                        key={m.id}
                        className={`flex items-end gap-2 ${isMe ? 'justify-end' : 'justify-start'}`}
                      >
                        {!isMe && <AvatarBadge avatarId={m.sender_avatar} size="xs" />}
                        <div
                          className={`max-w-[75%] sm:max-w-[65%] rounded-2xl px-4 py-2.5 text-xs shadow-2xs space-y-1 ${
                            isMe
                              ? 'bg-brand-600 text-white rounded-br-none'
                              : 'bg-white text-slate-800 border border-slate-100 rounded-bl-none'
                          }`}
                        >
                          <p className="leading-relaxed whitespace-pre-wrap">{m.content}</p>
                          <div className={`flex items-center justify-end gap-1 text-[10px] ${isMe ? 'text-brand-200' : 'text-slate-400'}`}>
                            <span>{timeStr}</span>
                            {isMe && <CheckCheck className="w-3 h-3" />}
                          </div>
                        </div>
                      </div>
                    );
                  })
                )}
                <div ref={messagesEndRef} />
              </div>

              {/* Chat Input Bar */}
              <form onSubmit={handleSendMessage} className="p-3.5 border-t border-slate-100 bg-white flex items-center gap-2">
                <input
                  type="text"
                  value={newMessage}
                  onChange={(e) => setNewMessage(e.target.value)}
                  placeholder="Type a message or discuss study doubts..."
                  className="flex-1 text-xs sm:text-sm px-4 py-2.5 rounded-2xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-brand-500"
                />
                <button
                  type="submit"
                  disabled={!newMessage.trim()}
                  className="p-2.5 rounded-2xl bg-brand-600 hover:bg-brand-700 text-white disabled:opacity-40 transition shadow-sm"
                >
                  <Send className="w-4 h-4" />
                </button>
              </form>
            </>
          ) : (
            <div className="flex-1 flex flex-col items-center justify-center p-8 text-center space-y-3">
              <div className="w-16 h-16 rounded-3xl bg-slate-50 flex items-center justify-center text-3xl">
                💬
              </div>
              <h3 className="font-bold text-slate-700">Select a Conversation</h3>
              <p className="text-xs text-slate-400 max-w-sm">
                Choose a connected peer from the left panel to review questions or schedule collaborative study sessions.
              </p>
            </div>
          )}
        </div>
      </div>

      <ScheduleModal
        isOpen={scheduleModalOpen}
        onClose={() => setScheduleModalOpen(false)}
        peer={selectedConversation}
        onSuccess={() => onNavigate('sessions')}
      />
    </div>
  );
};
