import React, { useState, useEffect } from 'react';
import {
  Calendar as CalendarIcon, Clock, Video, CheckCircle2,
  XCircle, Plus, Star, Users, ArrowRight, ShieldCheck
} from 'lucide-react';
import { sessionApi, connectionApi } from '../services/api';
import { AvatarBadge } from '../components/AvatarBadge';
import { ScheduleModal } from '../components/ScheduleModal';
import { ReviewModal } from '../components/ReviewModal';

export const CalendarSessionsPage = ({ onStartVideoCall, onNavigate }) => {
  const [sessions, setSessions] = useState([]);
  const [activeTab, setActiveTab] = useState('scheduled'); // scheduled, completed, cancelled
  const [loading, setLoading] = useState(true);

  // Modals
  const [scheduleModalOpen, setScheduleModalOpen] = useState(false);
  const [reviewModalOpen, setReviewModalOpen] = useState(false);
  const [selectedSessionForReview, setSelectedSessionForReview] = useState(null);
  const [connectedPeers, setConnectedPeers] = useState([]);
  const [selectedPeerToSchedule, setSelectedPeerToSchedule] = useState(null);

  const loadSessions = async () => {
    try {
      setLoading(true);
      const [list, conns] = await Promise.all([
        sessionApi.getSessions(),
        connectionApi.getConnections()
      ]);
      setSessions(list || []);
      setConnectedPeers(conns.accepted_peers || []);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadSessions();
  }, []);

  const handleCompleteSession = async (sessionId) => {
    try {
      await sessionApi.completeSession(sessionId);
      loadSessions();
    } catch (e) {
      alert(e.message);
    }
  };

  const handleCancelSession = async (sessionId) => {
    if (!confirm('Are you sure you want to cancel this scheduled session?')) return;
    try {
      await sessionApi.cancelSession(sessionId);
      loadSessions();
    } catch (e) {
      alert(e.message);
    }
  };

  const filteredSessions = sessions.filter(s => s.status === activeTab);

  return (
    <div className="space-y-8 pb-16 animate-fade-in max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">
            Peer Learning Sessions & Calendar
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Schedule 1-on-1 collaborative study rooms, join live calls, and exchange verified feedback.
          </p>
        </div>

        <button
          onClick={() => {
            if (connectedPeers.length === 0) {
              alert('You must have at least one connected peer to schedule a 1-on-1 session.');
              onNavigate('connections');
              return;
            }
            setSelectedPeerToSchedule(connectedPeers[0]);
            setScheduleModalOpen(true);
          }}
          className="inline-flex items-center gap-2 px-5 py-2.5 rounded-2xl bg-brand-600 hover:bg-brand-700 text-white font-bold text-xs shadow-sm transition"
        >
          <Plus className="w-4 h-4" />
          <span>Schedule New Session</span>
        </button>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-slate-200 gap-6">
        {[
          { id: 'scheduled', label: 'Upcoming & Scheduled' },
          { id: 'completed', label: 'Completed History' },
          { id: 'cancelled', label: 'Cancelled' },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`pb-3 text-xs sm:text-sm font-bold border-b-2 transition ${
              activeTab === tab.id
                ? 'border-brand-600 text-brand-600'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <span>{tab.label}</span>
          </button>
        ))}
      </div>

      {/* Sessions Grid */}
      {loading ? (
        <div className="p-16 text-center text-slate-400 text-sm">Loading sessions...</div>
      ) : filteredSessions.length === 0 ? (
        <div className="p-16 text-center rounded-3xl bg-white border border-slate-100 space-y-3">
          <CalendarIcon className="w-10 h-10 text-slate-300 mx-auto" />
          <h3 className="font-bold text-slate-700">No {activeTab} sessions</h3>
          <p className="text-xs text-slate-400">
            {activeTab === 'scheduled'
              ? 'Connect with peer mentors to schedule your next 1-on-1 study room!'
              : 'Past sessions will show here with their feedback review scores.'}
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {filteredSessions.map((s) => {
            const peerName = s.is_host ? s.learner_name : s.host_name;
            const peerAvatar = s.is_host ? s.learner_avatar : s.host_avatar;
            const roleBadge = s.is_host ? 'You are Teaching' : 'You are Learning';
            const dateStr = new Date(s.scheduled_time).toLocaleString([], {
              dateStyle: 'full',
              timeStyle: 'short'
            });

            return (
              <div
                key={s.id}
                className="p-6 rounded-3xl bg-white border border-slate-100 shadow-2xs hover:shadow-md transition space-y-4 flex flex-col justify-between"
              >
                <div className="space-y-3">
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-xs font-bold px-2.5 py-0.5 rounded-lg bg-brand-50 text-brand-700 border border-brand-100">
                      {s.subject_name}
                    </span>
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded-md ${
                      s.is_host ? 'bg-purpleBrand-50 text-purpleBrand-700' : 'bg-blue-50 text-blue-700'
                    }`}>
                      {roleBadge}
                    </span>
                  </div>

                  <h3 className="font-bold text-base text-slate-900 leading-snug">
                    {s.title}
                  </h3>

                  <div className="flex items-center gap-3">
                    <AvatarBadge avatarId={peerAvatar} size="sm" />
                    <div>
                      <span className="text-xs font-bold text-slate-800">With {peerName}</span>
                      <span className="block text-[11px] text-slate-400">
                        {s.duration_minutes} Minutes Duration
                      </span>
                    </div>
                  </div>

                  <div className="p-3 bg-slate-50 rounded-2xl border border-slate-100 text-xs text-slate-600 space-y-1">
                    <div className="flex items-center gap-1.5 text-slate-700 font-semibold">
                      <Clock className="w-3.5 h-3.5 text-brand-600" />
                      <span>{dateStr}</span>
                    </div>
                    {s.description && (
                      <p className="text-[11px] text-slate-500 italic mt-1 line-clamp-2">
                        "{s.description}"
                      </p>
                    )}
                  </div>
                </div>

                {/* Card Actions */}
                <div className="pt-3 border-t border-slate-100 flex flex-wrap items-center justify-between gap-2">
                  <span className="text-[10px] font-mono text-slate-400">
                    Room: {s.meeting_room_id}
                  </span>

                  <div className="flex items-center gap-2">
                    {s.status === 'scheduled' && (
                      <>
                        <button
                          onClick={() => handleCancelSession(s.id)}
                          className="px-3 py-1.5 rounded-xl border border-slate-200 text-slate-500 hover:text-rose-600 text-xs font-bold transition"
                        >
                          Cancel
                        </button>
                        <button
                          onClick={() => handleCompleteSession(s.id)}
                          className="px-3 py-1.5 rounded-xl border border-emerald-200 text-emerald-700 hover:bg-emerald-50 text-xs font-bold transition"
                        >
                          Mark Complete
                        </button>
                        <button
                          onClick={() => onStartVideoCall(s)}
                          className="px-4 py-2 rounded-xl bg-brand-600 hover:bg-brand-700 text-white font-bold text-xs flex items-center gap-1.5 shadow-sm transition"
                        >
                          <Video className="w-3.5 h-3.5" />
                          <span>Join Call</span>
                        </button>
                      </>
                    )}

                    {s.status === 'completed' && !s.has_reviewed && (
                      <button
                        onClick={() => {
                          setSelectedSessionForReview(s);
                          setReviewModalOpen(true);
                        }}
                        className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-600 text-white font-bold text-xs flex items-center gap-1.5 shadow-sm transition"
                      >
                        <Star className="w-3.5 h-3.5 fill-white" />
                        <span>Leave Review</span>
                      </button>
                    )}

                    {s.status === 'completed' && s.has_reviewed && (
                      <span className="text-xs font-bold text-emerald-600 flex items-center gap-1">
                        <CheckCircle2 className="w-4 h-4" />
                        <span>Reviewed</span>
                      </span>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      <ScheduleModal
        isOpen={scheduleModalOpen}
        onClose={() => setScheduleModalOpen(false)}
        peer={selectedPeerToSchedule}
        onSuccess={() => loadSessions()}
      />

      <ReviewModal
        isOpen={reviewModalOpen}
        onClose={() => setReviewModalOpen(false)}
        session={selectedSessionForReview}
        onSuccess={() => loadSessions()}
      />
    </div>
  );
};
