import React, { useState, useEffect } from 'react';
import {
  Bell, CheckCheck, Sparkles, Calendar, MessageSquare,
  Award, UserPlus, ArrowRight, ShieldCheck
} from 'lucide-react';
import { notificationApi } from '../services/api';

export const NotificationsPage = ({ onNavigate }) => {
  const [notifications, setNotifications] = useState([]);
  const [loading, setLoading] = useState(true);

  const loadNotifications = async () => {
    try {
      setLoading(true);
      const list = await notificationApi.getNotifications();
      setNotifications(list || []);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadNotifications();
  }, []);

  const handleMarkAllRead = async () => {
    try {
      await notificationApi.markAllRead();
      loadNotifications();
    } catch (e) {
      alert(e.message);
    }
  };

  const handleItemClick = async (notif) => {
    if (!notif.is_read) {
      await notificationApi.markRead(notif.id);
    }
    if (notif.link) {
      const route = notif.link.replace('/', '');
      if (route) onNavigate(route);
    }
  };

  const getIcon = (type) => {
    switch (type) {
      case 'connection_request':
      case 'connection_accepted':
        return <UserPlus className="w-5 h-5 text-brand-600" />;
      case 'session_scheduled':
      case 'session_reminder':
        return <Calendar className="w-5 h-5 text-purpleBrand-600" />;
      case 'new_message':
        return <MessageSquare className="w-5 h-5 text-blue-600" />;
      case 'review_received':
        return <Sparkles className="w-5 h-5 text-amber-500" />;
      default:
        return <Award className="w-5 h-5 text-emerald-600" />;
    }
  };

  return (
    <div className="space-y-6 pb-16 animate-fade-in max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">
            Notifications & Updates
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Real-time peer requests, session invitations, and feedback alerts.
          </p>
        </div>

        <button
          onClick={handleMarkAllRead}
          className="px-4 py-2 rounded-xl border border-slate-200 text-xs font-bold text-slate-600 hover:bg-slate-100 transition flex items-center gap-1.5"
        >
          <CheckCheck className="w-4 h-4 text-brand-600" />
          <span>Mark all as read</span>
        </button>
      </div>

      {loading ? (
        <div className="p-16 text-center text-slate-400 text-sm">Loading notifications...</div>
      ) : notifications.length === 0 ? (
        <div className="p-16 text-center rounded-3xl bg-white border border-slate-100 space-y-3">
          <Bell className="w-10 h-10 text-slate-300 mx-auto" />
          <h3 className="font-bold text-slate-700">All caught up!</h3>
          <p className="text-xs text-slate-400">No new alerts at this time.</p>
        </div>
      ) : (
        <div className="space-y-3">
          {notifications.map((n) => {
            const timeStr = new Date(n.created_at).toLocaleString([], {
              dateStyle: 'medium',
              timeStyle: 'short'
            });

            return (
              <div
                key={n.id}
                onClick={() => handleItemClick(n)}
                className={`p-4 sm:p-5 rounded-3xl border transition cursor-pointer flex items-start gap-4 ${
                  n.is_read
                    ? 'bg-white border-slate-100 hover:border-slate-200'
                    : 'bg-brand-50/40 border-brand-200 shadow-2xs hover:bg-brand-50/70'
                }`}
              >
                <div className="w-10 h-10 rounded-2xl bg-white shadow-2xs flex items-center justify-center shrink-0 border border-slate-100">
                  {getIcon(n.type)}
                </div>

                <div className="flex-1 space-y-1">
                  <div className="flex items-center justify-between">
                    <h4 className="font-bold text-xs sm:text-sm text-slate-900">{n.title}</h4>
                    <span className="text-[11px] text-slate-400 font-medium">{timeStr}</span>
                  </div>
                  <p className="text-xs text-slate-600 leading-relaxed">{n.content}</p>
                </div>

                {!n.is_read && (
                  <span className="w-2.5 h-2.5 rounded-full bg-brand-500 shrink-0 mt-2" />
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
