import React, { useState, useEffect } from 'react';
import {
  Sparkles, Search, BookOpen, Users, Calendar, Award,
  ArrowRight, Video, CheckCircle, Clock, Star, Plus, Shield
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { AvatarBadge } from '../components/AvatarBadge';
import { VerificationBadge } from '../components/VerificationBadge';
import { MatchScoreCard } from '../components/MatchScoreCard';
import { ConnectModal } from '../components/ConnectModal';
import {
  profileApi, matchingApi, connectionApi, sessionApi, subjectApi
} from '../services/api';

export const DashboardPage = ({
  onNavigate,
  onSelectSubject,
  onViewPeerProfile,
  onJoinSession
}) => {
  const { user } = useAuth();
  const [profileData, setProfileData] = useState(null);
  const [recommendations, setRecommendations] = useState([]);
  const [upcomingSessions, setUpcomingSessions] = useState([]);
  const [connectionsData, setConnectionsData] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState([]);
  const [searching, setSearching] = useState(false);
  const [loading, setLoading] = useState(true);

  // Connect modal state
  const [connectModalOpen, setConnectModalOpen] = useState(false);
  const [selectedPeerToConnect, setSelectedPeerToConnect] = useState(null);

  const loadDashboardData = async () => {
    try {
      setLoading(true);
      const [prof, recs, sess, conns] = await Promise.all([
        profileApi.getMyProfile(),
        matchingApi.getRecommendations(4),
        sessionApi.getSessions(),
        connectionApi.getConnections()
      ]);
      setProfileData(prof);
      setRecommendations(recs || []);
      // Filter upcoming sessions
      const upcoming = (sess || []).filter(s => s.status === 'scheduled');
      setUpcomingSessions(upcoming);
      setConnectionsData(conns);
    } catch (err) {
      console.error('Error loading dashboard:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadDashboardData();
  }, [user]);

  const handleSearch = async (e) => {
    e.preventDefault();
    if (!searchQuery.trim()) return;
    setSearching(true);
    try {
      const results = await subjectApi.getSubjects({ q: searchQuery.trim() });
      setSearchResults(results);
    } catch (e) {
      console.error(e);
    } finally {
      setSearching(false);
    }
  };

  const handleAcceptRequest = async (requestId) => {
    try {
      await connectionApi.acceptRequest(requestId);
      loadDashboardData();
    } catch (e) {
      alert(e.message);
    }
  };

  const handleRejectRequest = async (requestId) => {
    try {
      await connectionApi.rejectRequest(requestId);
      loadDashboardData();
    } catch (e) {
      alert(e.message);
    }
  };

  return (
    <div className="space-y-8 pb-16 animate-fade-in max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      {/* Welcome Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-brand-700 via-brand-600 to-emerald-600 text-white p-6 sm:p-8 shadow-xl shadow-brand-900/10">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="flex items-center gap-4 sm:gap-5">
            <AvatarBadge avatarId={user?.avatar_id} size="xl" />
            <div className="space-y-1">
              <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-white/20 text-white text-[11px] font-bold">
                <span>🌱</span>
                <span>Active Peer Student</span>
              </div>
              <h1 className="text-2xl sm:text-3xl font-black tracking-tight">
                Welcome back, {user?.full_name?.split(' ')[0]}!
              </h1>
              <p className="text-xs sm:text-sm text-brand-100 max-w-xl">
                {user?.college} • {user?.course} • Semester {user?.semester}
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={() => onNavigate('subjects')}
              className="px-4 py-2.5 rounded-xl bg-white text-brand-800 hover:bg-brand-50 font-bold text-xs shadow-sm transition flex items-center gap-2"
            >
              <Search className="w-3.5 h-3.5" />
              <span>Find Peer Mentors</span>
            </button>
            <button
              onClick={() => onNavigate('profile')}
              className="px-4 py-2.5 rounded-xl bg-brand-800/60 hover:bg-brand-900/60 text-white font-bold text-xs border border-white/20 transition"
            >
              Edit My Profile
            </button>
          </div>
        </div>

        {/* Decorative backdrop shapes */}
        <div className="absolute -right-8 -top-8 w-48 h-48 bg-white/10 rounded-full blur-2xl pointer-events-none" />
      </div>

      {/* Quick Search Bar */}
      <div className="bg-white rounded-3xl p-5 shadow-sm border border-slate-100">
        <form onSubmit={handleSearch} className="flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="w-5 h-5 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search any subject e.g. Data Structures, DBMS, Linear Algebra, React..."
              className="w-full pl-11 pr-4 py-3 rounded-2xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500"
            />
          </div>
          <button
            type="submit"
            className="px-6 py-3 rounded-2xl bg-brand-600 hover:bg-brand-700 text-white font-bold text-xs shadow-sm transition"
          >
            {searching ? 'Searching...' : 'Explore Subject'}
          </button>
        </form>

        {searchResults.length > 0 && (
          <div className="mt-4 pt-4 border-t border-slate-100 space-y-2">
            <p className="text-xs font-bold text-slate-500">Search Results:</p>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {searchResults.map((s) => (
                <div
                  key={s.id}
                  onClick={() => onSelectSubject(s)}
                  className="p-3 rounded-2xl border border-slate-100 bg-slate-50 hover:bg-brand-50/50 hover:border-brand-200 cursor-pointer transition flex items-center justify-between"
                >
                  <div>
                    <span className="font-bold text-xs text-slate-800">{s.name}</span>
                    <span className="block text-[10px] text-slate-400">{s.category} • Sem {s.semester_recommended}</span>
                  </div>
                  <span className="text-xs text-brand-600 font-bold">Find Mentors →</span>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Statistics Row */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white p-5 rounded-3xl border border-slate-100 shadow-2xs space-y-1">
          <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400">Can Teach</span>
          <div className="text-2xl font-black text-slate-800">{profileData?.skills_taught?.length || 0}</div>
          <span className="text-[11px] text-brand-600 font-medium">Subjects sharing mastery</span>
        </div>

        <div className="bg-white p-5 rounded-3xl border border-slate-100 shadow-2xs space-y-1">
          <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400">Want to Learn</span>
          <div className="text-2xl font-black text-slate-800">{profileData?.learning_goals?.length || 0}</div>
          <span className="text-[11px] text-purpleBrand-600 font-medium">Active learning goals</span>
        </div>

        <div className="bg-white p-5 rounded-3xl border border-slate-100 shadow-2xs space-y-1">
          <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400">Sessions Completed</span>
          <div className="text-2xl font-black text-slate-800">{profileData?.completed_sessions_count || 0}</div>
          <span className="text-[11px] text-emerald-600 font-medium">1-on-1 collaborative hours</span>
        </div>

        <div className="bg-white p-5 rounded-3xl border border-slate-100 shadow-2xs space-y-1">
          <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400">Peer Trust Rating</span>
          <div className="flex items-center gap-1.5 text-2xl font-black text-slate-800">
            <span>{profileData?.rating_avg || '5.0'}</span>
            <Star className="w-5 h-5 fill-amber-400 text-amber-400" />
          </div>
          <span className="text-[11px] text-slate-500 font-medium">{profileData?.total_reviews || 0} peer reviews</span>
        </div>
      </div>

      {/* Main 2-Column Content */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left Column: Recommended Mentors & Upcoming Sessions */}
        <div className="lg:col-span-2 space-y-8">
          {/* Incoming Requests Banner (if any) */}
          {connectionsData?.incoming_pending?.length > 0 && (
            <div className="p-5 rounded-3xl bg-purpleBrand-50 border border-purpleBrand-200/80 shadow-sm space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-purpleBrand-600 animate-ping" />
                  <h3 className="text-sm font-bold text-purpleBrand-900">
                    Incoming Connection Requests ({connectionsData.incoming_pending.length})
                  </h3>
                </div>
                <button
                  onClick={() => onNavigate('connections')}
                  className="text-xs font-bold text-purpleBrand-700 hover:underline"
                >
                  View All
                </button>
              </div>

              <div className="space-y-2">
                {connectionsData.incoming_pending.slice(0, 2).map((req) => (
                  <div
                    key={req.id}
                    className="p-3.5 rounded-2xl bg-white border border-purpleBrand-100 flex items-center justify-between gap-3"
                  >
                    <div className="flex items-center gap-3">
                      <AvatarBadge avatarId={req.sender_avatar} size="sm" />
                      <div>
                        <span className="text-xs font-bold text-slate-800">{req.sender_name}</span>
                        <span className="block text-[11px] text-slate-500">{req.sender_college}</span>
                        <p className="text-[11px] text-slate-600 italic mt-0.5 line-clamp-1">"{req.message}"</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => handleAcceptRequest(req.id)}
                        className="px-3 py-1.5 rounded-xl bg-brand-600 text-white text-xs font-bold hover:bg-brand-700 transition"
                      >
                        Accept
                      </button>
                      <button
                        onClick={() => handleRejectRequest(req.id)}
                        className="px-3 py-1.5 rounded-xl bg-slate-100 text-slate-600 text-xs font-bold hover:bg-slate-200 transition"
                      >
                        Decline
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Recommended Peer Mentors */}
          <div className="bg-white rounded-3xl p-6 border border-slate-100 shadow-sm space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-lg font-black text-slate-900 flex items-center gap-2">
                  <Sparkles className="w-5 h-5 text-brand-600" />
                  <span>Recommended Peer Mentors</span>
                </h2>
                <p className="text-xs text-slate-500">
                  Calculated based on your active learning goals & compatibility
                </p>
              </div>
              <button
                onClick={() => onNavigate('subjects')}
                className="text-xs font-bold text-brand-600 hover:text-brand-700 flex items-center gap-1"
              >
                <span>Browse All</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            {recommendations.length === 0 ? (
              <div className="p-8 text-center rounded-2xl bg-slate-50 border border-slate-100 space-y-2">
                <p className="text-sm font-semibold text-slate-700">No mentor recommendations yet</p>
                <p className="text-xs text-slate-500 max-w-sm mx-auto">
                  Add subjects you want to learn to your profile so our matching engine can recommend peers!
                </p>
                <button
                  onClick={() => onNavigate('profile')}
                  className="mt-2 px-4 py-2 rounded-xl bg-brand-600 text-white text-xs font-bold"
                >
                  Add Learning Goals
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {recommendations.map((cand) => (
                  <div
                    key={cand.user_id}
                    className="p-4 rounded-2xl border border-slate-100 bg-white hover:border-slate-200 hover:shadow-md transition space-y-3 flex flex-col justify-between"
                  >
                    <div>
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex items-center gap-3">
                          <AvatarBadge avatarId={cand.avatar_id} size="md" />
                          <div>
                            <button
                              onClick={() => onViewPeerProfile(cand.user_id)}
                              className="text-xs font-bold text-slate-800 hover:text-brand-600 text-left transition"
                            >
                              {cand.full_name}
                            </button>
                            <span className="block text-[10px] text-slate-400 truncate max-w-[140px]">
                              {cand.college}
                            </span>
                            <div className="flex items-center gap-1 mt-0.5">
                              <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
                              <span className="text-[11px] font-bold text-slate-700">{cand.rating_avg}</span>
                              <span className="text-[10px] text-slate-400">({cand.completed_sessions_count} sessions)</span>
                            </div>
                          </div>
                        </div>
                        <VerificationBadge status={cand.verification_status} size="xs" />
                      </div>

                      <div className="mt-3">
                        <MatchScoreCard
                          percentage={cand.estimated_match_percentage}
                          rank={cand.rank}
                          breakdown={cand.score_breakdown}
                        />
                      </div>
                    </div>

                    <div className="pt-2 flex items-center justify-between border-t border-slate-100">
                      <span className="text-[11px] text-slate-500 truncate max-w-[150px]">
                        {cand.availability}
                      </span>
                      {cand.connection_status === 'accepted' ? (
                        <button
                          onClick={() => onNavigate('chat')}
                          className="px-3 py-1.5 rounded-xl bg-purpleBrand-50 text-purpleBrand-700 font-bold text-xs hover:bg-purpleBrand-100 transition"
                        >
                          Chat Now
                        </button>
                      ) : cand.connection_status === 'pending_sent' ? (
                        <span className="text-[11px] font-bold text-amber-600 bg-amber-50 px-2.5 py-1 rounded-xl">
                          Request Pending
                        </span>
                      ) : (
                        <button
                          onClick={() => {
                            setSelectedPeerToConnect(cand);
                            setConnectModalOpen(true);
                          }}
                          className="px-3.5 py-1.5 rounded-xl bg-brand-600 text-white font-bold text-xs hover:bg-brand-700 transition"
                        >
                          Connect
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Upcoming Sessions */}
          <div className="bg-white rounded-3xl p-6 border border-slate-100 shadow-sm space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-lg font-black text-slate-900 flex items-center gap-2">
                  <Calendar className="w-5 h-5 text-purpleBrand-600" />
                  <span>Upcoming Learning Sessions</span>
                </h2>
                <p className="text-xs text-slate-500">Scheduled 1-on-1 peer sessions</p>
              </div>
              <button
                onClick={() => onNavigate('sessions')}
                className="text-xs font-bold text-brand-600 hover:underline"
              >
                View Calendar
              </button>
            </div>

            {upcomingSessions.length === 0 ? (
              <div className="p-6 text-center rounded-2xl bg-slate-50 text-slate-500 text-xs">
                No upcoming sessions scheduled. Connect with a peer to schedule a 1-on-1!
              </div>
            ) : (
              <div className="space-y-3">
                {upcomingSessions.map((sess) => {
                  const peerName = sess.is_host ? sess.learner_name : sess.host_name;
                  const peerAvatar = sess.is_host ? sess.learner_avatar : sess.host_avatar;
                  const dateStr = new Date(sess.scheduled_time).toLocaleString([], {
                    dateStyle: 'medium',
                    timeStyle: 'short'
                  });

                  return (
                    <div
                      key={sess.id}
                      className="p-4 rounded-2xl border border-slate-100 bg-white hover:border-slate-200 transition flex flex-col sm:flex-row sm:items-center justify-between gap-4"
                    >
                      <div className="flex items-center gap-3.5">
                        <AvatarBadge avatarId={peerAvatar} size="md" />
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="text-xs font-bold px-2 py-0.5 rounded-md bg-brand-50 text-brand-700">
                              {sess.subject_name}
                            </span>
                            <span className="text-[11px] font-semibold text-slate-400">
                              {sess.duration_minutes} min
                            </span>
                          </div>
                          <h4 className="font-bold text-sm text-slate-800 mt-1">{sess.title}</h4>
                          <p className="text-xs text-slate-500">
                            With {peerName} • <span className="text-brand-600 font-medium">{dateStr}</span>
                          </p>
                        </div>
                      </div>

                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => onJoinSession(sess)}
                          className="px-4 py-2 rounded-xl bg-brand-600 hover:bg-brand-700 text-white font-bold text-xs flex items-center gap-1.5 shadow-sm transition"
                        >
                          <Video className="w-4 h-4" />
                          <span>Join Video Call</span>
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>

        {/* Right Column: Learning Progress, Badges, Connected Peers */}
        <div className="space-y-8">
          {/* Learning Progress: Teaching vs Learning */}
          <div className="bg-white rounded-3xl p-6 border border-slate-100 shadow-sm space-y-4">
            <h3 className="text-sm font-bold text-slate-800 flex items-center justify-between">
              <span>My Learning Balance</span>
              <span className="text-xs font-semibold text-brand-600">Grow Together</span>
            </h3>

            <div className="space-y-3">
              <div>
                <div className="flex items-center justify-between text-xs mb-1">
                  <span className="font-semibold text-slate-600">Subjects I Teach:</span>
                  <span className="font-bold text-brand-700">{profileData?.skills_taught?.length || 0} subjects</span>
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {profileData?.skills_taught?.map(s => (
                    <span key={s.id} className="text-[11px] font-semibold px-2.5 py-1 rounded-xl bg-brand-50 text-brand-700 border border-brand-100">
                      {s.subject_name} ({s.proficiency_level})
                    </span>
                  ))}
                  {(!profileData?.skills_taught || profileData.skills_taught.length === 0) && (
                    <span className="text-xs text-slate-400 italic">None listed yet</span>
                  )}
                </div>
              </div>

              <div className="pt-2 border-t border-slate-100">
                <div className="flex items-center justify-between text-xs mb-1">
                  <span className="font-semibold text-slate-600">Subjects I Learn:</span>
                  <span className="font-bold text-purpleBrand-700">{profileData?.learning_goals?.length || 0} subjects</span>
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {profileData?.learning_goals?.map(g => (
                    <span key={g.id} className="text-[11px] font-semibold px-2.5 py-1 rounded-xl bg-purpleBrand-50 text-purpleBrand-700 border border-purpleBrand-100">
                      {g.subject_name} ({g.urgency})
                    </span>
                  ))}
                  {(!profileData?.learning_goals || profileData.learning_goals.length === 0) && (
                    <span className="text-xs text-slate-400 italic">None listed yet</span>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* Gamification: Badges Showcase */}
          <div className="bg-white rounded-3xl p-6 border border-slate-100 shadow-sm space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-slate-800 flex items-center gap-1.5">
                <Award className="w-4 h-4 text-amber-500" />
                <span>Achievement Badges</span>
              </h3>
              <span className="text-[11px] text-slate-400 font-semibold">
                {profileData?.badges?.length || 0} Earned
              </span>
            </div>

            <div className="grid grid-cols-2 gap-2.5">
              {profileData?.badges?.map((b) => (
                <div
                  key={b.id}
                  className="p-3 rounded-2xl bg-slate-50 border border-slate-100 flex items-center gap-2.5"
                  title={b.description}
                >
                  <span className="text-2xl">{b.badge_icon || '🌟'}</span>
                  <div className="truncate">
                    <span className="block text-xs font-bold text-slate-800 truncate">{b.badge_title}</span>
                    <span className="block text-[10px] text-slate-400 truncate">{b.description}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Connected Peers Quick Access */}
          <div className="bg-white rounded-3xl p-6 border border-slate-100 shadow-sm space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-slate-800">Recently Connected Peers</h3>
              <button
                onClick={() => onNavigate('connections')}
                className="text-xs font-bold text-brand-600 hover:underline"
              >
                All ({connectionsData?.total_connections || 0})
              </button>
            </div>

            {connectionsData?.accepted_peers?.length === 0 ? (
              <p className="text-xs text-slate-400 italic text-center py-4">No connected peers yet.</p>
            ) : (
              <div className="space-y-2.5">
                {connectionsData?.accepted_peers?.slice(0, 4).map((p) => (
                  <div
                    key={p.peer_id}
                    className="p-2.5 rounded-2xl bg-slate-50 border border-slate-100 flex items-center justify-between"
                  >
                    <div className="flex items-center gap-2.5">
                      <AvatarBadge avatarId={p.avatar_id} size="sm" />
                      <div>
                        <span className="text-xs font-bold text-slate-800">{p.full_name}</span>
                        <span className="block text-[10px] text-slate-400 truncate max-w-[110px]">{p.course}</span>
                      </div>
                    </div>
                    <button
                      onClick={() => onNavigate('chat')}
                      className="px-3 py-1 rounded-xl bg-white border border-slate-200 text-xs font-bold text-slate-700 hover:bg-brand-50 hover:text-brand-700 hover:border-brand-300 transition"
                    >
                      Chat
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      <ConnectModal
        isOpen={connectModalOpen}
        onClose={() => setConnectModalOpen(false)}
        targetUser={selectedPeerToConnect}
        onSuccess={() => loadDashboardData()}
      />
    </div>
  );
};
