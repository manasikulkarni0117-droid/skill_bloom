import React, { useState, useEffect } from 'react';
import {
  Award, Upload, Trash2, ExternalLink, ShieldCheck,
  FileText, Download, Lock, Eye, AlertCircle, Plus
} from 'lucide-react';
import { portfolioApi, profileApi } from '../services/api';
import { VerificationBadge } from '../components/VerificationBadge';
import { UploadEvidenceModal } from '../components/UploadEvidenceModal';

export const PortfolioPage = () => {
  const [items, setItems] = useState([]);
  const [privacy, setPrivacy] = useState('connections_only');
  const [loading, setLoading] = useState(true);
  const [uploadModalOpen, setUploadModalOpen] = useState(false);

  const loadPortfolio = async () => {
    try {
      setLoading(true);
      const [list, myProf] = await Promise.all([
        portfolioApi.getMyPortfolio(),
        profileApi.getMyProfile()
      ]);
      setItems(list || []);
      setPrivacy(myProf.documents_privacy || 'connections_only');
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadPortfolio();
  }, []);

  const handlePrivacyChange = async (newVal) => {
    try {
      setPrivacy(newVal);
      await profileApi.updateMyProfile({ documents_privacy: newVal });
    } catch (e) {
      alert(e.message);
    }
  };

  const handleDelete = async (id) => {
    if (!confirm('Are you sure you want to delete this certificate/project evidence?')) return;
    try {
      await portfolioApi.deleteItem(id);
      loadPortfolio();
    } catch (e) {
      alert(e.message);
    }
  };

  return (
    <div className="space-y-8 pb-16 animate-fade-in max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">
            Academic Certificates & Project Portfolio
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Build student trust by backing your peer mentoring skills with real proof.
          </p>
        </div>

        <button
          onClick={() => setUploadModalOpen(true)}
          className="inline-flex items-center gap-2 px-5 py-2.5 rounded-2xl bg-brand-600 hover:bg-brand-700 text-white font-bold text-xs shadow-sm transition"
        >
          <Upload className="w-4 h-4" />
          <span>Upload Evidence</span>
        </button>
      </div>

      {/* Privacy Control Card */}
      <div className="bg-white rounded-3xl p-5 border border-slate-100 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-purpleBrand-50 text-purpleBrand-600 flex items-center justify-center">
            <Lock className="w-5 h-5" />
          </div>
          <div>
            <span className="text-xs font-bold text-slate-800">Document Privacy Setting</span>
            <p className="text-[11px] text-slate-500">Control who can inspect your uploaded certificates and GitHub links</p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {['connections_only', 'public', 'private'].map((mode) => (
            <button
              key={mode}
              onClick={() => handlePrivacyChange(mode)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold capitalize transition ${
                privacy === mode
                  ? 'bg-purpleBrand-600 text-white shadow-2xs'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {mode === 'connections_only' ? 'Connected Peers Only' : mode}
            </button>
          ))}
        </div>
      </div>

      {/* Verification Transparency Callout */}
      <div className="p-4 rounded-3xl bg-amber-50/70 border border-amber-200/80 flex items-start gap-3 text-xs text-amber-900">
        <AlertCircle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
        <div className="space-y-1">
          <span className="font-bold">Transparent Verification Standards</span>
          <p className="text-amber-800 leading-relaxed text-[11px]">
            Skill Bloom distinguishes between <strong>Certificate Uploaded</strong>, <strong>Assessment Passed</strong>, <strong>Project Reviewed</strong>, and <strong>Institution Verified</strong>. Uploading files grants "Certificate Uploaded" status. Official "Institution Verified" badges are awarded exclusively through authenticated college validation.
          </p>
        </div>
      </div>

      {/* Portfolio Items Grid */}
      {loading ? (
        <div className="p-16 text-center text-slate-400 text-sm">Loading evidence vault...</div>
      ) : items.length === 0 ? (
        <div className="p-16 text-center rounded-3xl bg-white border border-slate-100 space-y-3">
          <Award className="w-12 h-12 text-slate-300 mx-auto" />
          <h3 className="font-bold text-slate-700">No portfolio items uploaded yet</h3>
          <p className="text-xs text-slate-400 max-w-sm mx-auto">
            Upload certificates from NPTEL, Coursera, or college courses, or link GitHub capstones to boost your matching rank!
          </p>
          <button
            onClick={() => setUploadModalOpen(true)}
            className="mt-2 px-4 py-2 rounded-xl bg-brand-600 text-white font-bold text-xs"
          >
            Add First Evidence
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {items.map((item) => (
            <div
              key={item.id}
              className="p-5 rounded-3xl bg-white border border-slate-100 shadow-2xs hover:shadow-md transition space-y-4 flex flex-col justify-between"
            >
              <div className="space-y-2.5">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 px-2 py-0.5 bg-slate-100 rounded-md">
                    {item.item_type}
                  </span>
                  <VerificationBadge status={item.verification_status} size="xs" />
                </div>

                <h3 className="font-bold text-sm text-slate-900 line-clamp-2">
                  {item.title}
                </h3>

                {item.issuing_organization && (
                  <p className="text-xs text-slate-500 font-medium">
                    Issued by: {item.issuing_organization}
                  </p>
                )}

                {item.subject_name && (
                  <span className="inline-block text-[11px] font-semibold text-brand-700 bg-brand-50 px-2.5 py-0.5 rounded-lg">
                    Subject: {item.subject_name}
                  </span>
                )}

                {item.description && (
                  <p className="text-xs text-slate-600 italic line-clamp-3 leading-relaxed">
                    "{item.description}"
                  </p>
                )}
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
                <div className="flex items-center gap-3 text-xs">
                  {item.file_path && (
                    <a
                      href={portfolioApi.getDownloadUrl(item.id)}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1 font-bold text-brand-600 hover:text-brand-700"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>{item.file_type || 'PDF'}</span>
                    </a>
                  )}

                  {item.github_url && (
                    <a
                      href={item.github_url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1 font-bold text-purpleBrand-600 hover:text-purpleBrand-700"
                    >
                      <ExternalLink className="w-3.5 h-3.5" />
                      <span>Repo</span>
                    </a>
                  )}
                </div>

                <button
                  onClick={() => handleDelete(item.id)}
                  className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition"
                  title="Delete evidence"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      <UploadEvidenceModal
        isOpen={uploadModalOpen}
        onClose={() => setUploadModalOpen(false)}
        onSuccess={() => loadPortfolio()}
      />
    </div>
  );
};
