import React, { createContext, useContext, useState, useEffect } from 'react';
import { authApi, setToken, getToken, removeToken, setStoredUser, getStoredUser } from '../services/api';

const AuthContext = createContext();

export const DEMO_USERS = [
  { email: 'test@demo.edu', name: 'Dev Test Student', avatar: 'avatar-owl', role: 'Tester / CS 4th Sem' },
  { email: 'aarav@demo.edu', name: 'Aarav Sharma', avatar: 'avatar-coder', role: 'DSA & Python Expert' },
  { email: 'priya@demo.edu', name: 'Priya Patel', avatar: 'avatar-wizard', role: 'Math & DBMS Mentor' },
  { email: 'rohan@demo.edu', name: 'Rohan Verma', avatar: 'avatar-astronaut', role: 'Web Dev & React Peer' },
  { email: 'ananya@demo.edu', name: 'Ananya Gupta', avatar: 'avatar-fox', role: 'OS & Networks Specialist' },
];

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(getStoredUser());
  const [loading, setLoading] = useState(true);

  const fetchCurrentUser = async () => {
    try {
      if (getToken()) {
        const profile = await authApi.getMe();
        setUser(profile);
        setStoredUser(profile);
      } else {
        setUser(null);
      }
    } catch (err) {
      console.warn('Failed to restore session:', err);
      removeToken();
      setUser(null);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchCurrentUser();

    const handleLogoutEvent = () => {
      setUser(null);
    };
    window.addEventListener('auth-logout', handleLogoutEvent);
    return () => window.removeEventListener('auth-logout', handleLogoutEvent);
  }, []);

  const login = async (email, password) => {
    const res = await authApi.login({ email, password });
    setToken(res.access_token);
    const profile = await authApi.getMe();
    setUser(profile);
    setStoredUser(profile);
    return profile;
  };

  const register = async (userData) => {
    const res = await authApi.register(userData);
    setToken(res.access_token);
    const profile = await authApi.getMe();
    setUser(profile);
    setStoredUser(profile);
    return profile;
  };

  const logout = async () => {
    try {
      await authApi.logout();
    } catch (e) {
      // ignore
    }
    removeToken();
    setUser(null);
  };

  const switchAccount = async (email) => {
    return login(email, 'password123');
  };

  const refreshProfile = async () => {
    if (getToken()) {
      const profile = await authApi.getMe();
      setUser(profile);
      setStoredUser(profile);
      return profile;
    }
  };

  return (
    <AuthContext.Provider value={{
      user,
      loading,
      login,
      register,
      logout,
      switchAccount,
      refreshProfile,
      isAuthenticated: !!user,
    }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
