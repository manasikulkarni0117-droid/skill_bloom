import React, { useState } from 'react';
import { Info, ChevronDown, ChevronUp, Sparkles, Check } from 'lucide-react';

export const MatchScoreCard = ({ percentage = 85, rank = 1, breakdown = null }) => {
  const [showDetails, setShowDetails] = useState(false);

  // Gradient based on score tier
  const getColorScheme = (score) => {
    if (score >= 85) return {
      bar: 'bg-emerald-500',
      text: 'text-emerald-700',
      bg: 'bg-emerald-50',
      border: 'border-emerald-200'
    };
    if (score >= 70) return {
      bar: 'bg-teal-500',
      text: 'text-teal-700',
      bg: 'bg-teal-50',
      border: 'border-teal-200'
    };
    return {
      bar: 'bg-indigo-500',
      text: 'text-indigo-700',
      bg: 'bg-indigo-50',
      border: 'border-indigo-200'
    };
  };

  const scheme = getColorScheme(percentage);

  return (
    <div className={`p-3.5 rounded-2xl border ${scheme.border} ${scheme.bg} transition-all`}>
      <div className="flex items-center justify-between gap-3">
        <div>
          <div className="flex items-center gap-1.5">
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-500">
              Compatibility Match
            </span>
            <span
              title="Estimated rule-based score based on proficiency, verified evidence, reviews, and learning schedule. Not a guarantee of teaching ability."
              className="cursor-help text-slate-400 hover:text-slate-600"
            >
              <Info className="w-3.5 h-3.5" />
            </span>
          </div>

          <div className="flex items-baseline gap-2 mt-0.5">
            <span className={`text-2xl font-black ${scheme.text}`}>
              {percentage}%
            </span>
            <span className="text-[11px] font-medium text-slate-500">
              Estimated Match Score
            </span>
          </div>
        </div>

        {rank && (
          <div className="text-right">
            <span className="inline-flex items-center justify-center px-2.5 py-1 rounded-xl text-xs font-bold bg-white text-slate-700 border border-slate-200 shadow-2xs">
              Rank #{rank}
            </span>
          </div>
        )}
      </div>

      {/* Progress Bar */}
      <div className="w-full bg-white/70 h-2 rounded-full mt-2.5 overflow-hidden">
        <div
          className={`h-full rounded-full transition-all duration-700 ${scheme.bar}`}
          style={{ width: `${percentage}%` }}
        />
      </div>

      <div className="flex items-center justify-between mt-2 pt-2 border-t border-slate-200/50 text-[11px] text-slate-500">
        <span className="italic">
          *Compatibility estimate, not a performance guarantee.
        </span>
        {breakdown && (
          <button
            type="button"
            onClick={() => setShowDetails(!showDetails)}
            className="flex items-center gap-1 font-semibold text-slate-700 hover:text-slate-900 transition-colors"
          >
            <span>{showDetails ? 'Hide' : 'Why this score?'}</span>
            {showDetails ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
          </button>
        )}
      </div>

      {/* Breakdown details */}
      {showDetails && breakdown && (
        <div className="mt-3 pt-3 border-t border-slate-200/60 text-xs space-y-1.5 bg-white/80 p-3 rounded-xl border border-slate-100 animate-fade-in">
          <div className="flex items-center justify-between text-slate-600">
            <span>Subject Proficiency:</span>
            <span className="font-semibold text-slate-800">+{breakdown.proficiency_points} pts</span>
          </div>
          <div className="flex items-center justify-between text-slate-600">
            <span>Verified Evidence & Assessments:</span>
            <span className="font-semibold text-slate-800">+{breakdown.verification_points} pts</span>
          </div>
          <div className="flex items-center justify-between text-slate-600">
            <span>Peer Ratings & Teaching Feedback:</span>
            <span className="font-semibold text-slate-800">+{breakdown.feedback_points} pts</span>
          </div>
          <div className="flex items-center justify-between text-slate-600">
            <span>Completed Peer Sessions:</span>
            <span className="font-semibold text-slate-800">+{breakdown.sessions_points} pts</span>
          </div>
          <div className="flex items-center justify-between text-slate-600">
            <span>Language Compatibility:</span>
            <span className="font-semibold text-slate-800">+{breakdown.language_match_points} pts</span>
          </div>
          <div className="flex items-center justify-between text-slate-600">
            <span>Availability Overlap:</span>
            <span className="font-semibold text-slate-800">+{breakdown.availability_match_points} pts</span>
          </div>
          {breakdown.college_proximity_points > 0 && (
            <div className="flex items-center justify-between text-emerald-700 font-medium">
              <span>Same College Synergy:</span>
              <span>+{breakdown.college_proximity_points} pts</span>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
