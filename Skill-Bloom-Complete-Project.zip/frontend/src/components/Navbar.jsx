import React, { useState, useEffect } from 'react';
import {
  BookOpen, Users, MessageSquare, Video, Calendar,
  Award, Bell, Settings, LogOut, ChevronDown, User,
  Menu, X, Sparkles, Shield
} from 'lucide-react';
import { useAuth, DEMO_USERS } from '../context/AuthContext';
import { AvatarBadge } from './AvatarBadge';
import { connectionApi, chatApi, notificationApi } from '../services/api';

export const Navbar = ({ currentTab, onNavigate }) => {
  const { user, logout, switchAccount, isAuthenticated } = useAuth();
  const [userDropdownOpen, setUserDropdownOpen] = useState(false);
  const [demoDropdownOpen, setDemoDropdownOpen] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // Live badge counts
  const [pendingRequestsCount, setPendingRequestsCount] = useState(0);
  const [unreadNotificationsCount, setUnreadNotificationsCount] = useState(0);
  const [unreadMessagesCount, setUnreadMessagesCount] = useState(0);

  const fetchBadgeCounts = async () => {
    if (!isAuthenticated) return;
    try {
      // Connections
      const conns = await connectionApi.getConnections();
      setPendingRequestsCount(conns.incoming_pending?.length || 0);

      // Notifications
      const notifRes = await notificationApi.getUnreadCount();
      setUnreadNotificationsCount(notifRes.unread_count || 0);

      // Chat unread
      const convs = await chatApi.getConversations();
      const totalUnread = convs.reduce((acc, c) => acc + (c.unread_count || 0), 0);
      setUnreadMessagesCount(totalUnread);
    } catch (e) {
      // ignore
    }
  };

  useEffect(() => {
    fetchBadgeCounts();
    const interval = setInterval(fetchBadgeCounts, 12000);
    return () => clearInterval(interval);
  }, [isAuthenticated, user]);

  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: Sparkles },
    { id: 'subjects', label: 'Explore Subjects', icon: BookOpen },
    { id: 'connections', label: 'Connections', icon: Users, badge: pendingRequestsCount },
    { id: 'chat', label: 'Private Chat', icon: MessageSquare, badge: unreadMessagesCount },
    { id: 'sessions', label: 'Sessions', icon: Calendar },
    { id: 'portfolio', label: 'Portfolio & Evidence', icon: Award },
  ];

  const handleNavClick = (tabId) => {
    onNavigate(tabId);
    setMobileMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-40 bg-white/90 backdrop-blur-md border-b border-slate-200/80 shadow-2xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => handleNavClick(isAuthenticated ? 'dashboard' : 'landing')}
              className="flex items-center gap-2.5 text-left group"
            >
              <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-brand-600 to-emerald-400 flex items-center justify-center text-white shadow-md shadow-brand-500/20 group-hover:scale-105 transition-transform">
                <span className="text-xl">🌱</span>
              </div>
              <div>
                <span className="text-lg font-black tracking-tight text-slate-900 group-hover:text-brand-600 transition-colors">
                  Skill Bloom
                </span>
                <span className="hidden sm:block text-[10px] font-semibold text-slate-400 uppercase tracking-widest">
                  Peer-to-Peer College Learning
                </span>
              </div>
            </button>
          </div>

          {/* Desktop Navigation */}
          {isAuthenticated && (
            <nav className="hidden lg:flex items-center gap-1">
              {navItems.map((item) => {
                const IconComponent = item.icon;
                const isActive = currentTab === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => handleNavClick(item.id)}
                    className={`relative flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-semibold transition-all ${
                      isActive
                        ? 'bg-brand-50 text-brand-700 shadow-2xs'
                        : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100/70'
                    }`}
                  >
                    <IconComponent className={`w-4 h-4 ${isActive ? 'text-brand-600' : 'text-slate-400'}`} />
                    <span>{item.label}</span>
                    {item.badge > 0 && (
                      <span className="inline-flex items-center justify-center px-1.5 py-0.5 text-[10px] font-bold rounded-full bg-rose-500 text-white animate-pulse">
                        {item.badge}
                      </span>
                    )}
                  </button>
                );
              })}
            </nav>
          )}

          {/* Right actions */}
          <div className="flex items-center gap-2.5">
            {/* Quick Demo Switcher */}
            <div className="relative">
              <button
                type="button"
                onClick={() => setDemoDropdownOpen(!demoDropdownOpen)}
                className="hidden md:flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl text-xs font-semibold bg-purpleBrand-50 text-purpleBrand-700 border border-purpleBrand-200 hover:bg-purpleBrand-100 transition shadow-2xs"
                title="Switch demo student accounts to test peer interactions"
              >
                <span>🎭</span>
                <span>Demo Student</span>
                <ChevronDown className="w-3.5 h-3.5 text-purpleBrand-500" />
              </button>

              {demoDropdownOpen && (
                <div className="absolute right-0 mt-2 w-64 bg-white rounded-2xl shadow-xl border border-slate-100 p-2 z-50 animate-fade-in">
                  <div className="px-2 py-1.5 text-[11px] font-bold uppercase text-slate-400 border-b border-slate-100 mb-1">
                    Instant Switch Demo Peer
                  </div>
                  {DEMO_USERS.map((u) => (
                    <button
                      key={u.email}
                      type="button"
                      onClick={() => {
                        switchAccount(u.email);
                        setDemoDropdownOpen(false);
                      }}
                      className={`w-full flex items-center gap-2.5 px-2.5 py-2 rounded-xl text-left text-xs transition ${
                        user?.email === u.email
                          ? 'bg-brand-50 text-brand-700 font-bold'
                          : 'text-slate-700 hover:bg-slate-50'
                      }`}
                    >
                      <AvatarBadge avatarId={u.avatar} size="xs" />
                      <div className="truncate">
                        <div className="truncate font-semibold">{u.name}</div>
                        <div className="text-[10px] text-slate-400 truncate">{u.role}</div>
                      </div>
                    </button>
                  ))}
                </div>
              )}
            </div>

            {isAuthenticated ? (
              <>
                {/* Notifications Bell */}
                <button
                  type="button"
                  onClick={() => handleNavClick('notifications')}
                  className="relative p-2 rounded-xl text-slate-500 hover:text-slate-800 hover:bg-slate-100 transition"
                  title="Notifications"
                >
                  <Bell className="w-5 h-5" />
                  {unreadNotificationsCount > 0 && (
                    <span className="absolute top-1.5 right-1.5 w-2.5 h-2.5 rounded-full bg-rose-500 ring-2 ring-white" />
                  )}
                </button>

                {/* User menu */}
                <div className="relative">
                  <button
                    type="button"
                    onClick={() => setUserDropdownOpen(!userDropdownOpen)}
                    className="flex items-center gap-2 p-1 pl-1.5 pr-2 rounded-2xl hover:bg-slate-100 transition border border-slate-200/60"
                  >
                    <AvatarBadge avatarId={user?.avatar_id} size="sm" />
                    <span className="hidden sm:inline text-xs font-bold text-slate-800 max-w-[100px] truncate">
                      {user?.full_name?.split(' ')[0]}
                    </span>
                    <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
                  </button>

                  {userDropdownOpen && (
                    <div className="absolute right-0 mt-2 w-56 bg-white rounded-2xl shadow-xl border border-slate-100 p-2 z-50 animate-fade-in">
                      <div className="px-3 py-2 border-b border-slate-100 mb-1">
                        <p className="text-xs font-bold text-slate-800 truncate">{user?.full_name}</p>
                        <p className="text-[10px] text-slate-400 truncate">{user?.email}</p>
                        <p className="text-[10px] font-semibold text-brand-600 truncate mt-0.5">{user?.college}</p>
                      </div>

                      <button
                        type="button"
                        onClick={() => {
                          handleNavClick('profile');
                          setUserDropdownOpen(false);
                        }}
                        className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-semibold text-slate-700 hover:bg-slate-50 text-left"
                      >
                        <User className="w-4 h-4 text-slate-400" />
                        <span>My Student Profile</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => {
                          handleNavClick('settings');
                          setUserDropdownOpen(false);
                        }}
                        className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-semibold text-slate-700 hover:bg-slate-50 text-left"
                      >
                        <Settings className="w-4 h-4 text-slate-400" />
                        <span>Settings & Privacy</span>
                      </button>

                      <div className="my-1 border-t border-slate-100" />

                      <button
                        type="button"
                        onClick={() => {
                          logout();
                          setUserDropdownOpen(false);
                          handleNavClick('landing');
                        }}
                        className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-semibold text-rose-600 hover:bg-rose-50 text-left"
                      >
                        <LogOut className="w-4 h-4 text-rose-500" />
                        <span>Sign Out</span>
                      </button>
                    </div>
                  )}
                </div>
              </>
            ) : (
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => handleNavClick('auth')}
                  className="px-3.5 py-1.5 rounded-xl text-xs font-bold text-slate-700 hover:bg-slate-100 transition"
                >
                  Log In
                </button>
                <button
                  type="button"
                  onClick={() => handleNavClick('auth')}
                  className="px-4 py-2 rounded-xl text-xs font-bold text-white bg-brand-600 hover:bg-brand-700 shadow-sm transition"
                >
                  Get Started
                </button>
              </div>
            )}

            {/* Mobile menu trigger */}
            {isAuthenticated && (
              <button
                type="button"
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="lg:hidden p-2 rounded-xl text-slate-600 hover:bg-slate-100"
              >
                {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
              </button>
            )}
          </div>
        </div>

        {/* Mobile Navigation Drawer */}
        {isAuthenticated && mobileMenuOpen && (
          <div className="lg:hidden py-3 border-t border-slate-100 animate-fade-in space-y-1">
            {navItems.map((item) => {
              const IconComponent = item.icon;
              const isActive = currentTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => handleNavClick(item.id)}
                  className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-semibold ${
                    isActive ? 'bg-brand-50 text-brand-700' : 'text-slate-600 hover:bg-slate-50'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <IconComponent className="w-4 h-4" />
                    <span>{item.label}</span>
                  </div>
                  {item.badge > 0 && (
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-500 text-white">
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        )}
      </div>
    </header>
  );
};
