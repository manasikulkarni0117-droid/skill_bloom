import React from 'react';
import { X, Check } from 'lucide-react';
import { AVATAR_MAP, AvatarBadge } from './AvatarBadge';

export const AvatarPickerModal = ({ isOpen, onClose, selectedAvatar, onSelect }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-sm animate-fade-in">
      <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-slate-100">
        <div className="flex items-center justify-between pb-4 border-b border-slate-100">
          <div>
            <h3 className="text-xl font-bold text-slate-800">Choose Your Learning Avatar</h3>
            <p className="text-xs text-slate-500 mt-0.5">Express your student personality with an illustrated peer icon</p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="grid grid-cols-3 sm:grid-cols-4 gap-3.5 my-6 max-h-80 overflow-y-auto p-1">
          {Object.entries(AVATAR_MAP).map(([id, meta]) => {
            const isSelected = selectedAvatar === id;
            return (
              <button
                key={id}
                type="button"
                onClick={() => onSelect(id)}
                className={`relative flex flex-col items-center p-3 rounded-2xl border-2 transition-all ${
                  isSelected
                    ? 'border-brand-500 bg-brand-50/60 shadow-sm scale-105'
                    : 'border-slate-100 hover:border-slate-200 hover:bg-slate-50'
                }`}
              >
                <AvatarBadge avatarId={id} size="lg" />
                <span className="text-xs font-semibold text-slate-700 mt-2 truncate w-full text-center">
                  {meta.label}
                </span>
                {isSelected && (
                  <div className="absolute top-1.5 right-1.5 w-5 h-5 rounded-full bg-brand-500 text-white flex items-center justify-center shadow">
                    <Check className="w-3 h-3 stroke-[3]" />
                  </div>
                )}
              </button>
            );
          })}
        </div>

        <div className="flex justify-end pt-3 border-t border-slate-100">
          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2.5 rounded-xl font-semibold bg-brand-600 hover:bg-brand-700 text-white shadow-sm transition-colors text-sm"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
