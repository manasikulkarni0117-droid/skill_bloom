import React from 'react';
import { ShieldCheck, Award, CheckCircle2, FileText, HelpCircle } from 'lucide-react';

export const VerificationBadge = ({ status = 'Unverified', size = 'sm' }) => {
  const configs = {
    'Institution Verified': {
      label: 'Institution Verified',
      icon: ShieldCheck,
      bgColor: 'bg-blue-50 text-blue-700 border-blue-200',
      iconColor: 'text-blue-600',
      tooltip: 'Officially verified through academic institution assessment or official university transcript validation.',
    },
    'Assessment Passed': {
      label: 'Assessment Passed',
      icon: Award,
      bgColor: 'bg-emerald-50 text-emerald-700 border-emerald-200',
      iconColor: 'text-emerald-600',
      tooltip: 'Passed standardized peer assessment exam with documented score.',
    },
    'Project Reviewed': {
      label: 'Project Reviewed',
      icon: CheckCircle2,
      bgColor: 'bg-purple-50 text-purple-700 border-purple-200',
      iconColor: 'text-purple-600',
      tooltip: 'Project implementation and source code repository evaluated.',
    },
    'Certificate Uploaded': {
      label: 'Certificate Uploaded',
      icon: FileText,
      bgColor: 'bg-amber-50 text-amber-700 border-amber-200',
      iconColor: 'text-amber-600',
      tooltip: 'Certificate document uploaded by student. (Not yet institution verified).',
    },
    'Unverified': {
      label: 'Self-Reported',
      icon: HelpCircle,
      bgColor: 'bg-slate-100 text-slate-600 border-slate-200',
      iconColor: 'text-slate-400',
      tooltip: 'Self-stated student skill without uploaded third-party verification.',
    },
  };

  const config = configs[status] || configs['Unverified'];
  const IconComponent = config.icon;

  const sizeClasses = size === 'xs'
    ? 'text-[10px] px-1.5 py-0.5 gap-1'
    : 'text-xs px-2.5 py-1 gap-1.5';

  return (
    <span
      className={`inline-flex items-center font-medium rounded-full border shadow-2xs select-none ${config.bgColor} ${sizeClasses}`}
      title={config.tooltip}
    >
      <IconComponent className={size === 'xs' ? 'w-3 h-3' : 'w-3.5 h-3.5'} />
      <span>{config.label}</span>
    </span>
  );
};
