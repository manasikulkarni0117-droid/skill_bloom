import React from 'react';

export const AVATAR_MAP = {
  'avatar-owl': { emoji: '🦉', label: 'Wise Owl', gradient: 'from-emerald-500 to-teal-700' },
  'avatar-fox': { emoji: '🦊', label: 'Clever Fox', gradient: 'from-amber-500 to-orange-600' },
  'avatar-coder': { emoji: '💻', label: 'Tech Prodigy', gradient: 'from-blue-600 to-indigo-700' },
  'avatar-astronaut': { emoji: '🚀', label: 'Explorer', gradient: 'from-purple-600 to-indigo-900' },
  'avatar-panda': { emoji: '🐼', label: 'Zen Panda', gradient: 'from-teal-500 to-emerald-700' },
  'avatar-robot': { emoji: '🤖', label: 'AI Builder', gradient: 'from-cyan-500 to-blue-600' },
  'avatar-lion': { emoji: '🦁', label: 'Brave Mentor', gradient: 'from-yellow-500 to-amber-700' },
  'avatar-wizard': { emoji: '🧙', label: 'Math Wizard', gradient: 'from-fuchsia-600 to-purple-800' },
  'avatar-cat': { emoji: '🐱', label: 'Focus Cat', gradient: 'from-rose-400 to-pink-600' },
  'avatar-koala': { emoji: '🐨', label: 'Calm Learner', gradient: 'from-slate-500 to-zinc-700' },
  'avatar-rabbit': { emoji: '🐰', label: 'Speed Learner', gradient: 'from-emerald-400 to-green-600' },
  'avatar-bee': { emoji: '🐝', label: 'Active Bee', gradient: 'from-amber-400 to-yellow-600' },
};

export const AvatarBadge = ({ avatarId = 'avatar-owl', size = 'md', className = '', showBorder = true }) => {
  const meta = AVATAR_MAP[avatarId] || AVATAR_MAP['avatar-owl'];

  const sizeClasses = {
    xs: 'w-7 h-7 text-sm',
    sm: 'w-9 h-9 text-base',
    md: 'w-11 h-11 text-xl',
    lg: 'w-14 h-14 text-2xl',
    xl: 'w-20 h-20 text-4xl',
    '2xl': 'w-28 h-28 text-6xl',
  };

  return (
    <div
      className={`inline-flex items-center justify-center rounded-2xl bg-gradient-to-br ${meta.gradient} shadow-sm select-none ${showBorder ? 'ring-2 ring-white/80 shadow-md' : ''} ${sizeClasses[size] || sizeClasses.md} ${className}`}
      title={meta.label}
    >
      <span className="transform hover:scale-110 transition-transform duration-200">
        {meta.emoji}
      </span>
    </div>
  );
};
