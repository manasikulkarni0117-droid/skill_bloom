import React, { useState } from 'react';
import { X, Star, ThumbsUp, CheckCircle, Clock } from 'lucide-react';
import { sessionApi } from '../services/api';

export const ReviewModal = ({ isOpen, onClose, session, onSuccess }) => {
  const [rating, setRating] = useState(5);
  const [clarity, setClarity] = useState(5);
  const [helpfulness, setHelpfulness] = useState(5);
  const [punctuality, setPunctuality] = useState(5);
  const [feedback, setFeedback] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  if (!isOpen || !session) return null;

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    try {
      await sessionApi.submitReview({
        session_id: session.id,
        rating: parseFloat(rating),
        teaching_clarity: clarity,
        helpfulness: helpfulness,
        punctuality: punctuality,
        feedback: feedback.trim(),
      });
      if (onSuccess) onSuccess();
      onClose();
    } catch (err) {
      setError(err.message || 'Failed to submit review');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-sm animate-fade-in">
      <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-100 max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between pb-4 border-b border-slate-100">
          <div>
            <h3 className="font-bold text-slate-800">Leave Peer Session Feedback</h3>
            <p className="text-xs text-slate-500">{session.title}</p>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-full text-slate-400 hover:text-slate-600 hover:bg-slate-100"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {error && (
          <div className="my-3 p-3 rounded-xl bg-rose-50 text-rose-600 text-xs border border-rose-200">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4 my-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1 text-center">
              Overall Experience Rating
            </label>
            <div className="flex items-center justify-center gap-2 py-2">
              {[1, 2, 3, 4, 5].map((star) => (
                <button
                  key={star}
                  type="button"
                  onClick={() => setRating(star)}
                  className="p-1 text-amber-400 hover:scale-125 transition-transform"
                >
                  <Star
                    className={`w-8 h-8 ${star <= rating ? 'fill-amber-400 text-amber-400' : 'text-slate-200'}`}
                  />
                </button>
              ))}
            </div>
            <p className="text-center text-xs font-medium text-slate-500">
              {rating === 5 ? 'Exceptional peer mentor!' : rating === 4 ? 'Very helpful session' : 'Decent session'}
            </p>
          </div>

          <div className="space-y-3 bg-slate-50 p-3.5 rounded-2xl border border-slate-100">
            <div className="flex items-center justify-between text-xs">
              <span className="font-medium text-slate-600">Teaching Clarity:</span>
              <div className="flex gap-1">
                {[1, 2, 3, 4, 5].map(v => (
                  <button
                    key={v}
                    type="button"
                    onClick={() => setClarity(v)}
                    className={`w-6 h-6 rounded-md text-xs font-bold ${clarity === v ? 'bg-brand-600 text-white' : 'bg-white border text-slate-600'}`}
                  >
                    {v}
                  </button>
                ))}
              </div>
            </div>

            <div className="flex items-center justify-between text-xs">
              <span className="font-medium text-slate-600">Helpfulness & Patience:</span>
              <div className="flex gap-1">
                {[1, 2, 3, 4, 5].map(v => (
                  <button
                    key={v}
                    type="button"
                    onClick={() => setHelpfulness(v)}
                    className={`w-6 h-6 rounded-md text-xs font-bold ${helpfulness === v ? 'bg-brand-600 text-white' : 'bg-white border text-slate-600'}`}
                  >
                    {v}
                  </button>
                ))}
              </div>
            </div>

            <div className="flex items-center justify-between text-xs">
              <span className="font-medium text-slate-600">Punctuality:</span>
              <div className="flex gap-1">
                {[1, 2, 3, 4, 5].map(v => (
                  <button
                    key={v}
                    type="button"
                    onClick={() => setPunctuality(v)}
                    className={`w-6 h-6 rounded-md text-xs font-bold ${punctuality === v ? 'bg-brand-600 text-white' : 'bg-white border text-slate-600'}`}
                  >
                    {v}
                  </button>
                ))}
              </div>
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Constructive Peer Feedback
            </label>
            <textarea
              rows={3}
              value={feedback}
              onChange={(e) => setFeedback(e.target.value)}
              placeholder="What did they explain well? What could be improved?"
              className="w-full text-sm p-3 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-brand-500"
              required
              minLength={5}
            />
          </div>

          <div className="flex justify-end gap-2.5 pt-2 border-t border-slate-100">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-sm font-semibold text-slate-600 hover:bg-slate-100"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={loading}
              className="px-5 py-2.5 rounded-xl text-sm font-semibold text-white bg-brand-600 hover:bg-brand-700 shadow-sm disabled:opacity-50"
            >
              {loading ? 'Submitting...' : 'Submit Feedback'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
