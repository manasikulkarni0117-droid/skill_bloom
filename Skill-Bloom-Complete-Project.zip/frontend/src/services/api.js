// Skill Bloom Centralized API Service

const API_BASE = '/api';

// Token storage helpers
export const getToken = () => localStorage.getItem('sb_token');
export const setToken = (token) => localStorage.setItem('sb_token', token);
export const removeToken = () => {
  localStorage.removeItem('sb_token');
  localStorage.removeItem('sb_user');
};

export const getStoredUser = () => {
  try {
    const raw = localStorage.getItem('sb_user');
    return raw ? JSON.parse(raw) : null;
  } catch (e) {
    return null;
  }
};

export const setStoredUser = (user) => {
  localStorage.setItem('sb_user', JSON.stringify(user));
};

// Generic fetch wrapper with auth header injection
async function request(endpoint, options = {}) {
  const headers = { ...options.headers };
  const token = getToken();

  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  // If not FormData, default to application/json
  if (!(options.body instanceof FormData) && !headers['Content-Type']) {
    headers['Content-Type'] = 'application/json';
  }

  const response = await fetch(`${API_BASE}${endpoint}`, {
    ...options,
    headers,
  });

  if (response.status === 401) {
    // Only remove token if not logging in/registering
    if (!endpoint.includes('/auth/login') && !endpoint.includes('/auth/register')) {
      removeToken();
      window.dispatchEvent(new Event('auth-logout'));
    }
  }

  const contentType = response.headers.get('content-type');
  let data = null;
  if (contentType && contentType.includes('application/json')) {
    data = await response.json();
  } else {
    data = await response.text();
  }

  if (!response.ok) {
    const errorMsg = data?.detail || data?.message || 'An unexpected error occurred';
    throw new Error(errorMsg);
  }

  return data;
}

// Auth API
export const authApi = {
  getAvatars: () => request('/auth/avatars'),
  register: (payload) => request('/auth/register', { method: 'POST', body: JSON.stringify(payload) }),
  login: (payload) => request('/auth/login', { method: 'POST', body: JSON.stringify(payload) }),
  getMe: () => request('/auth/me'),
  logout: () => request('/auth/logout', { method: 'POST' }),
};

// Profiles API
export const profileApi = {
  getMyProfile: () => request('/profiles/me'),
  updateMyProfile: (payload) => request('/profiles/me', { method: 'PUT', body: JSON.stringify(payload) }),
  getUserProfile: (userId) => request(`/profiles/${userId}`),
  addTeachingSkill: (payload) => request('/profiles/skills', { method: 'POST', body: JSON.stringify(payload) }),
  removeTeachingSkill: (skillId) => request(`/profiles/skills/${skillId}`, { method: 'DELETE' }),
  addLearningGoal: (payload) => request('/profiles/learning-goals', { method: 'POST', body: JSON.stringify(payload) }),
  removeLearningGoal: (goalId) => request(`/profiles/learning-goals/${goalId}`, { method: 'DELETE' }),
};

// Subjects API
export const subjectApi = {
  getSubjects: (params = {}) => {
    const query = new URLSearchParams();
    if (params.q) query.append('q', params.q);
    if (params.category && params.category !== 'All') query.append('category', params.category);
    if (params.semester) query.append('semester', params.semester);
    const qs = query.toString();
    return request(`/subjects${qs ? `?${qs}` : ''}`);
  },
  getCategories: () => request('/subjects/categories'),
  getSubjectDetail: (id) => request(`/subjects/${id}`),
  createCustomSubject: (payload) => request('/subjects', { method: 'POST', body: JSON.stringify(payload) }),
};

// Matching API
export const matchingApi = {
  getRankedMentors: (subjectId, filters = {}) => {
    const query = new URLSearchParams();
    if (filters.proficiency && filters.proficiency !== 'All') query.append('proficiency', filters.proficiency);
    if (filters.course) query.append('course', filters.course);
    if (filters.language) query.append('language', filters.language);
    if (filters.minRating) query.append('min_rating', filters.minRating);
    if (filters.availability) query.append('availability', filters.availability);
    const qs = query.toString();
    return request(`/matching/subject/${subjectId}${qs ? `?${qs}` : ''}`);
  },
  getRecommendations: (limit = 6) => request(`/matching/recommendations?limit=${limit}`),
};

// Connections API
export const connectionApi = {
  sendRequest: (receiverId, message) => request('/connections/request', {
    method: 'POST',
    body: JSON.stringify({ receiver_id: receiverId, message }),
  }),
  getConnections: () => request('/connections'),
  acceptRequest: (requestId) => request(`/connections/${requestId}/accept`, { method: 'PUT' }),
  rejectRequest: (requestId) => request(`/connections/${requestId}/reject`, { method: 'PUT' }),
  cancelRequest: (requestId) => request(`/connections/${requestId}/cancel`, { method: 'DELETE' }),
  disconnect: (peerId) => request(`/connections/disconnect/${peerId}`, { method: 'DELETE' }),
  blockOrReport: (targetId, action, reason) => request('/connections/block-report', {
    method: 'POST',
    body: JSON.stringify({ target_id: targetId, action, reason }),
  }),
};

// Chat API
export const chatApi = {
  getConversations: () => request('/chat/conversations'),
  getMessages: (peerId) => request(`/chat/messages/${peerId}`),
  sendMessage: (receiverId, content) => request('/chat/send', {
    method: 'POST',
    body: JSON.stringify({ receiver_id: receiverId, content }),
  }),
};

// Sessions API
export const sessionApi = {
  getSessions: () => request('/sessions'),
  getSessionDetail: (sessionId) => request(`/sessions/${sessionId}`),
  scheduleSession: (payload) => request('/sessions', { method: 'POST', body: JSON.stringify(payload) }),
  completeSession: (sessionId) => request(`/sessions/${sessionId}/complete`, { method: 'PUT' }),
  cancelSession: (sessionId) => request(`/sessions/${sessionId}/cancel`, { method: 'PUT' }),
  submitReview: (payload) => request('/sessions/reviews', { method: 'POST', body: JSON.stringify(payload) }),
};

// Portfolio API
export const portfolioApi = {
  getMyPortfolio: () => request('/portfolio'),
  uploadItem: (formData) => request('/portfolio/upload', {
    method: 'POST',
    body: formData,
  }),
  deleteItem: (itemId) => request(`/portfolio/${itemId}`, { method: 'DELETE' }),
  getDownloadUrl: (itemId) => `${API_BASE}/portfolio/download/${itemId}`,
};

// Notifications API
export const notificationApi = {
  getNotifications: () => request('/notifications'),
  getUnreadCount: () => request('/notifications/unread-count'),
  markRead: (notifId) => request(`/notifications/${notifId}/read`, { method: 'PUT' }),
  markAllRead: () => request('/notifications/read-all', { method: 'PUT' }),
};
