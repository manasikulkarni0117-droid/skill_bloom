@echo off
setlocal enabledelayedexpansion

echo ================================================================
echo        Skill Bloom - GitHub Repository Upload Script
echo ================================================================
echo.

:: 1. Check if Git is installed
where git >nul 2>nul
if %ERRORLEVEL% neq 0 (
    echo [ERROR] Git is not installed on your system or not added to PATH.
    echo Please install Git from https://git-scm.com/downloads and try again.
    pause
    exit /b 1
)

echo [1/5] Git is installed. Proceeding...
echo.

:: 2. Check Git username and email
git config user.name >nul 2>nul
if %ERRORLEVEL% neq 0 (
    echo Git user configuration not found.
    set /p GIT_NAME="Enter your GitHub Name: "
    set /p GIT_EMAIL="Enter your GitHub Email: "
    git config --global user.name "!GIT_NAME!"
    git config --global user.email "!GIT_EMAIL!"
    echo Configured Git user: !GIT_NAME! ^<!GIT_EMAIL!^>
    echo.
)

:: 3. Initialize Git repository if needed
if not exist ".git" (
    echo [2/5] Initializing new Git repository...
    git init
) else (
    echo [2/5] Git repository already initialized.
)
echo.

:: 4. Add files and Commit
echo [3/5] Staging files (respecting .gitignore)...
git add .
echo.

set /p COMMIT_MSG="Enter commit message (Press Enter for default): "
if "!COMMIT_MSG!"=="" (
    set COMMIT_MSG=Initial commit: Skill Bloom Peer-to-Peer College Learning Platform
)

echo Committing files...
git commit -m "!COMMIT_MSG!"
echo.

:: 5. Set branch to main
git branch -M main

:: 6. Remote Repository Setup
echo [4/5] GitHub Remote Repository Setup
git remote get-url origin >nul 2>nul
if %ERRORLEVEL% equ 0 (
    for /f "delims=" %%i in ('git remote get-url origin') do set CURRENT_REMOTE=%%i
    echo Current remote origin is: !CURRENT_REMOTE!
    set /p CHANGE_REMOTE="Do you want to change it? (y/n, default: n): "
    if /i "!CHANGE_REMOTE!"=="y" (
        set /p REPO_URL="Enter your GitHub repository URL (e.g. https://github.com/username/Skill-Bloom.git): "
        git remote set-url origin !REPO_URL!
    )
) else (
    echo.
    echo Please create a new empty repository on GitHub: https://github.com/new
    echo (Do NOT check 'Add README', 'Add .gitignore', or 'Choose a license' on GitHub)
    echo.
    set /p REPO_URL="Enter your GitHub repository URL (e.g. https://github.com/username/Skill-Bloom.git): "
    if "!REPO_URL!"=="" (
        echo [ERROR] Repository URL cannot be empty.
        pause
        exit /b 1
    )
    git remote add origin !REPO_URL!
)
echo.

:: 7. Push to GitHub
echo [5/5] Pushing files to GitHub main branch...
echo.
git push -u origin main

if %ERRORLEVEL% equ 0 (
    echo.
    echo ================================================================
    echo [SUCCESS] Your Skill Bloom project is successfully uploaded to GitHub!
    echo ================================================================
) else (
    echo.
    echo ================================================================
    echo [NOTE] Push encountered an issue. Possible reasons:
    echo 1. You may need to authenticate with GitHub in the browser/token.
    echo 2. The remote repository already has commits. In that case, run:
    echo    git pull origin main --rebase
    echo    git push -u origin main
    echo ================================================================
)

echo.
pause
